import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { sound } from '../utils/audio.ts';

export type NotificationType = 'bet_won' | 'bet_lost' | 'bet_settled' | 'deposit_approved' | 'deposit_pending' | 'info';

export interface NotificationItem {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  amount?: number;
  meta?: Record<string, any>;
  timestamp: string; // ISO string for easy serialization
  read: boolean;
}

export interface ToastItem {
  id: string;
  notification: NotificationItem;
  durationMs: number;
  expiresAt: number;
}

interface BetSettledParams {
  gameTitle: string;
  betAmount: number;
  payoutAmount: number;
  multiplier: number;
  summary?: string;
  mode?: string;
}

interface DepositApprovedParams {
  amount: number | string;
  method: string;
  transactionReference?: string;
  txnId?: string;
}

interface NotificationContextType {
  notifications: NotificationItem[];
  activeToasts: ToastItem[];
  unreadCount: number;
  notifyBetSettled: (params: BetSettledParams) => void;
  notifyDepositApproved: (params: DepositApprovedParams) => void;
  addNotification: (item: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>) => void;
  dismissToast: (id: string) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  clearNotification: (id: string) => void;
  clearAll: () => void;
  triggerMockBetSettled: (won?: boolean) => void;
  triggerMockDepositApproved: (amount?: number, method?: string) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

const STORAGE_KEY = 'bigwin_notifications_v1';

export const NotificationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (_) {}
    return [
      {
        id: 'init-1',
        type: 'deposit_approved',
        title: '💰 Deposit Approved!',
        message: '৳1,500.00 deposit via bKash has been verified and credited to your wallet.',
        amount: 1500,
        timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
        read: false,
      },
      {
        id: 'init-2',
        type: 'bet_won',
        title: '🎯 Bet Won: Aviator Flight',
        message: 'Round settled at 3.45x multiplier with ৳690.00 payout (+৳490.00 profit)!',
        amount: 690,
        timestamp: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
        read: true,
      }
    ];
  });

  const [activeToasts, setActiveToasts] = useState<ToastItem[]>([]);

  // Persist notifications
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(notifications.slice(0, 40)));
    } catch (_) {}
  }, [notifications]);

  // Toast expiry timer loop
  useEffect(() => {
    if (activeToasts.length === 0) return;
    const interval = setInterval(() => {
      const now = Date.now();
      setActiveToasts(prev => prev.filter(t => t.expiresAt > now));
    }, 200);
    return () => clearInterval(interval);
  }, [activeToasts]);

  const dismissToast = useCallback((id: string) => {
    setActiveToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const addNotification = useCallback((item: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>) => {
    const id = `notif-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const newNotif: NotificationItem = {
      ...item,
      id,
      timestamp: new Date().toISOString(),
      read: false,
    };

    setNotifications(prev => [newNotif, ...prev.slice(0, 49)]);

    // Push toast with duration
    const durationMs = 5000;
    setActiveToasts(prev => [
      {
        id,
        notification: newNotif,
        durationMs,
        expiresAt: Date.now() + durationMs,
      },
      ...prev.slice(0, 3) // maximum 4 concurrent toasts
    ]);

    return id;
  }, []);

  const notifyBetSettled = useCallback((params: BetSettledParams) => {
    const { gameTitle, betAmount, payoutAmount, multiplier, summary, mode } = params;
    const isWin = payoutAmount > 0;
    const net = payoutAmount - betAmount;
    const isDemo = mode === 'demo';

    if (isWin) {
      sound.win();
      addNotification({
        type: 'bet_won',
        title: `🎯 Bet Won: ${gameTitle}`,
        message: `${isDemo ? '[Demo] ' : ''}Settled at ${multiplier.toFixed(2)}x payout of ৳${payoutAmount.toFixed(2)} (+৳${net.toFixed(2)} net). ${summary || ''}`,
        amount: payoutAmount,
        meta: { gameTitle, betAmount, payoutAmount, multiplier, mode },
      });
    } else {
      sound.notification();
      addNotification({
        type: 'bet_lost',
        title: `🎲 Bet Settled: ${gameTitle}`,
        message: `${isDemo ? '[Demo] ' : ''}Round settled at ${multiplier.toFixed(2)}x. Loss: -৳${betAmount.toFixed(2)}. ${summary || ''}`,
        amount: -betAmount,
        meta: { gameTitle, betAmount, payoutAmount, multiplier, mode },
      });
    }
  }, [addNotification]);

  const notifyDepositApproved = useCallback((params: DepositApprovedParams) => {
    const { amount, method, transactionReference, txnId } = params;
    const parsedAmount = typeof amount === 'number' ? amount : parseFloat(amount) || 0;

    sound.bigWin();
    addNotification({
      type: 'deposit_approved',
      title: '💰 Deposit Approved!',
      message: `Your deposit of ৳${parsedAmount.toFixed(2)} via ${method.toUpperCase()} (Ref: ${transactionReference || txnId || 'VERIFIED'}) has been approved and credited to your wallet balance.`,
      amount: parsedAmount,
      meta: { amount: parsedAmount, method, transactionReference, txnId },
    });
  }, [addNotification]);

  // Test triggers for mock notifications
  const triggerMockBetSettled = useCallback((won: boolean = true) => {
    if (won) {
      notifyBetSettled({
        gameTitle: 'Aviator Super Flight',
        betAmount: 200,
        payoutAmount: 760,
        multiplier: 3.8,
        summary: 'Cashed out at 3.80x (+৳560.00 profit)',
      });
    } else {
      notifyBetSettled({
        gameTitle: 'Dragon Tiger Sic Bo',
        betAmount: 150,
        payoutAmount: 0,
        multiplier: 0,
        summary: 'Dice rolled [3, 2, 1] — Total 6 (Small)',
      });
    }
  }, [notifyBetSettled]);

  const triggerMockDepositApproved = useCallback((amount: number = 1000, method: string = 'bKash') => {
    const randomTrx = '8K' + Math.random().toString(36).substring(2, 8).toUpperCase();
    notifyDepositApproved({
      amount,
      method,
      transactionReference: randomTrx,
      txnId: `DEP-${Date.now().toString().slice(-6)}`,
    });
  }, [notifyDepositApproved]);

  const markAsRead = useCallback((id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  }, []);

  const markAllAsRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }, []);

  const clearNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
    setActiveToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
    setActiveToasts([]);
  }, []);

  // Listen to window-level custom events
  useEffect(() => {
    const handleCustomNotify = (e: any) => {
      const data = e.detail;
      if (!data) return;
      if (data.type === 'bet_settled') {
        notifyBetSettled(data);
      } else if (data.type === 'deposit_approved') {
        notifyDepositApproved(data);
      } else if (data.title && data.message) {
        addNotification(data);
      }
    };

    window.addEventListener('bw_toast', handleCustomNotify);
    return () => window.removeEventListener('bw_toast', handleCustomNotify);
  }, [notifyBetSettled, notifyDepositApproved, addNotification]);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        activeToasts,
        unreadCount,
        notifyBetSettled,
        notifyDepositApproved,
        addNotification,
        dismissToast,
        markAsRead,
        markAllAsRead,
        clearNotification,
        clearAll,
        triggerMockBetSettled,
        triggerMockDepositApproved,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};
