import React, { useState, useEffect } from 'react';
import {
  Home, Gamepad2, Gift, Wallet, Users, User, ShieldAlert,
  Globe, LogIn, Lock, BookOpen, Crown, ExternalLink
} from 'lucide-react';
import { GameItem, GAMES_CATALOG } from './data/games.ts';
import { TRANSLATIONS, Language } from './data/translations.ts';
import { HomeView } from './components/views/HomeView.tsx';
import { GamesView } from './components/views/GamesView.tsx';
import { OffersView } from './components/views/OffersView.tsx';
import { WalletView } from './components/views/WalletView.tsx';
import { ReferralView } from './components/views/ReferralView.tsx';
import { ProfileView } from './components/views/ProfileView.tsx';
import { AdminView } from './components/views/AdminView.tsx';
import { GameModal } from './components/games/GameModal.tsx';
import { AuthModal } from './components/auth/AuthModal.tsx';
import { NotificationProvider } from './context/NotificationContext.tsx';
import { ToastContainer } from './components/notifications/ToastContainer.tsx';
import { NotificationMenu } from './components/notifications/NotificationMenu.tsx';

export default function App() {
  const [currentView, setCurrentView] = useState<'home' | 'games' | 'offers' | 'wallet' | 'referral' | 'profile' | 'admin'>('home');
  const [lang, setLang] = useState<Language>('en');
  const [user, setUser] = useState<any>(null);

  // Modals
  const [selectedGame, setSelectedGame] = useState<GameItem | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authInitialTab, setAuthInitialTab] = useState<'login' | 'register'>('login');
  const [showDocsModal, setShowDocsModal] = useState(false);

  const t = TRANSLATIONS[lang];

  // Check URL pathname for /admin route
  useEffect(() => {
    if (window.location.pathname === '/admin') {
      setCurrentView('admin');
    }
  }, []);

  // Fetch initial demo session or load default demo user
  useEffect(() => {
    // Attempt auto-login demo account or check local session
    const savedUserId = localStorage.getItem('bw_user_id') || '2'; // User Rahim Chowdhury default
    fetch(`/api/user/profile/${savedUserId}`)
      .then(r => r.json())
      .then(data => {
        if (data && data.id) {
          setUser(data);
          if (data.language) setLang(data.language as Language);
        }
      })
      .catch(console.error);
  }, []);

  const refreshUser = () => {
    if (!user) return;
    fetch(`/api/user/profile/${user.id}`)
      .then(r => r.json())
      .then(data => {
        if (data && data.id) setUser(data);
      })
      .catch(console.error);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('bw_user_id');
    setCurrentView('home');
  };

  const handleAuthSuccess = (loggedUser: any) => {
    setUser(loggedUser);
    localStorage.setItem('bw_user_id', loggedUser.id.toString());
    if (loggedUser.language) setLang(loggedUser.language as Language);
  };

  const toggleLanguage = () => {
    const nextLang: Language = lang === 'en' ? 'bn' : 'en';
    setLang(nextLang);
    if (user) {
      fetch(`/api/user/profile/${user.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ language: nextLang }),
      }).catch(console.error);
    }
  };

  return (
    <NotificationProvider>
      <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans">
        {/* Real-Time Toast Notifications Alert System */}
        <ToastContainer />

        {/* Top Bar Contract (One row, 3 zones separated by gap-8) */}
        <header className="sticky top-0 z-40 bg-[#080d1e]/95 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-8 px-4 sm:px-8 py-3.5">
          {/* Zone 1: Single text element wordmark */}
          <button
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-2 tracking-tight text-white whitespace-nowrap shrink-0 group text-left"
          >
            <Crown className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="text-xl font-extrabold tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500">
              BIGWIN999
            </span>
          </button>

          {/* Zone 2: 4-5 single-line clean text navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-300">
            <button
              onClick={() => setCurrentView('home')}
              className={`hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 ${
                currentView === 'home' ? 'text-amber-400 font-bold' : ''
              }`}
            >
              {t.home}
            </button>
            <button
              onClick={() => setCurrentView('games')}
              className={`hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 ${
                currentView === 'games' ? 'text-amber-400 font-bold' : ''
              }`}
            >
              {t.games}
            </button>
            <button
              onClick={() => setCurrentView('offers')}
              className={`hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 ${
                currentView === 'offers' ? 'text-amber-400 font-bold' : ''
              }`}
            >
              {t.offers}
            </button>
            <button
              onClick={() => setCurrentView('wallet')}
              className={`hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 ${
                currentView === 'wallet' ? 'text-amber-400 font-bold' : ''
              }`}
            >
              {t.wallet}
            </button>
            <button
              onClick={() => setCurrentView('referral')}
              className={`hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 ${
                currentView === 'referral' ? 'text-amber-400 font-bold' : ''
              }`}
            >
              {t.referEarn}
            </button>
          </nav>

          {/* Zone 3: 1 primary action & controls */}
          <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
            {/* Live Notifications Bell Menu */}
            <NotificationMenu />

            {/* Language toggle */}
            <button
              onClick={toggleLanguage}
              className="px-2.5 py-1.5 bg-slate-900 border border-slate-700/80 rounded-lg text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1 transition-colors whitespace-nowrap shrink-0"
              title="Toggle English / Bengali"
            >
              <Globe className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'en' ? 'BN' : 'EN'}</span>
            </button>

            {/* Docs / Technical Architecture button */}
            <button
              onClick={() => setShowDocsModal(true)}
              className="hidden lg:flex px-2.5 py-1.5 bg-slate-900 border border-slate-700/80 rounded-lg text-xs font-semibold text-slate-300 hover:text-white items-center gap-1 transition-colors whitespace-nowrap shrink-0"
              title="Technical Docs & Setup"
            >
              <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
              <span>Docs</span>
            </button>

            {/* Admin shortcut */}
            <button
              onClick={() => setCurrentView('admin')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors whitespace-nowrap shrink-0 ${
                currentView === 'admin'
                  ? 'bg-amber-500 text-slate-950 border-amber-500'
                  : 'bg-slate-900/90 text-amber-400 border-amber-500/30 hover:border-amber-400'
              }`}
            >
              Admin Portal
            </button>

            {/* User Account / Balance or Login */}
            {user ? (
              <button
                onClick={() => setCurrentView('profile')}
                className="flex items-center gap-2 pl-3 pr-2 py-1 bg-[#0f172a] hover:bg-slate-800 border border-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                <div className="text-right">
                  <div className="text-[11px] font-bold text-amber-400 font-mono leading-none">
                    ৳{parseFloat(user.walletBalance || '0').toFixed(2)}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate max-w-[80px]">
                    {user.name.split(' ')[0]}
                  </div>
                </div>
                <div className="w-7 h-7 rounded-full bg-amber-500 text-slate-950 font-extrabold text-xs flex items-center justify-center">
                  {user.name ? user.name[0].toUpperCase() : 'U'}
                </div>
              </button>
            ) : (
              <button
                onClick={() => { setAuthInitialTab('login'); setShowAuthModal(true); }}
                className="px-4 py-2 text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 rounded-lg shadow-md transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>{t.login}</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Viewport Content */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-4 sm:px-8 pt-6 pb-20 md:pb-12">
        {currentView === 'home' && (
          <HomeView
            onSelectGame={(g) => setSelectedGame(g)}
            onNavigate={(v) => setCurrentView(v as any)}
            user={user}
            onOpenAuth={(tab) => { setAuthInitialTab(tab); setShowAuthModal(true); }}
            lang={lang}
          />
        )}

        {currentView === 'games' && (
          <GamesView
            onSelectGame={(g) => setSelectedGame(g)}
            lang={lang}
          />
        )}

        {currentView === 'offers' && (
          <OffersView
            onNavigate={(v) => setCurrentView(v as any)}
            lang={lang}
          />
        )}

        {currentView === 'wallet' && (
          <WalletView
            user={user}
            onRefreshUser={refreshUser}
            lang={lang}
          />
        )}

        {currentView === 'referral' && (
          <ReferralView
            user={user}
            lang={lang}
          />
        )}

        {currentView === 'profile' && (
          <ProfileView
            user={user}
            onUpdateUser={(updated) => setUser(updated)}
            onLogout={handleLogout}
            lang={lang}
            onToggleLang={(l) => setLang(l)}
          />
        )}

        {currentView === 'admin' && (
          <AdminView />
        )}
      </main>

      {/* Mobile Bottom Navigation (≤ 15% viewport height cap) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#070b1a]/95 backdrop-blur-lg border-t border-slate-800 py-1.5 px-3 flex items-center justify-around">
        <button
          onClick={() => setCurrentView('home')}
          className={`flex flex-col items-center gap-0.5 text-[10px] ${
            currentView === 'home' ? 'text-amber-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Home className="w-4 h-4" />
          <span>Home</span>
        </button>

        <button
          onClick={() => setCurrentView('games')}
          className={`flex flex-col items-center gap-0.5 text-[10px] ${
            currentView === 'games' ? 'text-amber-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Gamepad2 className="w-4 h-4" />
          <span>Games</span>
        </button>

        <button
          onClick={() => setCurrentView('offers')}
          className={`flex flex-col items-center gap-0.5 text-[10px] ${
            currentView === 'offers' ? 'text-amber-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Gift className="w-4 h-4" />
          <span>Offers</span>
        </button>

        <button
          onClick={() => setCurrentView('wallet')}
          className={`flex flex-col items-center gap-0.5 text-[10px] ${
            currentView === 'wallet' ? 'text-amber-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Wallet className="w-4 h-4" />
          <span>Wallet</span>
        </button>

        <button
          onClick={() => setCurrentView('profile')}
          className={`flex flex-col items-center gap-0.5 text-[10px] ${
            currentView === 'profile' ? 'text-amber-400 font-bold' : 'text-slate-400'
          }`}
        >
          <User className="w-4 h-4" />
          <span>Profile</span>
        </button>
      </nav>

      {/* Footer */}
      <footer className="bg-[#050812] border-t border-slate-800/80 py-8 text-xs text-slate-500">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-slate-300">BIGWIN999</span>
            <span aria-hidden="true">·</span>
            <span>Premier Gaming & Entertainment</span>
            <span aria-hidden="true">·</span>
            <span>© 2026 BIGWIN999 Ltd.</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <button onClick={() => setCurrentView('offers')} className="hover:text-slate-200">Bonus Policy</button>
            <button onClick={() => setCurrentView('referral')} className="hover:text-slate-200">Affiliates</button>
            <button onClick={() => setShowDocsModal(true)} className="hover:text-cyan-400">System Architecture</button>
            <button onClick={() => setCurrentView('admin')} className="hover:text-amber-400">Admin</button>
          </div>
        </div>
      </footer>

      {/* Game Modal */}
      {selectedGame && (
        <GameModal
          game={selectedGame}
          user={user}
          onClose={() => setSelectedGame(null)}
          onRefreshBalances={refreshUser}
          lang={lang}
        />
      )}

      {/* Auth Modal */}
      {showAuthModal && (
        <AuthModal
          initialTab={authInitialTab}
          onClose={() => setShowAuthModal(false)}
          onSuccess={handleAuthSuccess}
          lang={lang}
        />
      )}

      {/* Deployment & Technical Documentation Modal */}
      {showDocsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
          <div className="bg-[#0b1226] border border-cyan-500/40 rounded-2xl p-6 sm:p-8 max-w-3xl w-full max-h-[90vh] overflow-y-auto space-y-6 shadow-2xl my-auto text-xs text-slate-300">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-cyan-400" />
                  <span>BIGWIN999 Production Deployment & Operations Guide</span>
                </h3>
                <p className="text-slate-400 mt-0.5">Database schema, server-side wallet architecture, HTTPS, and legal requirements</p>
              </div>
              <button onClick={() => setShowDocsModal(false)} className="p-1 text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <h4 className="font-bold text-amber-400 text-sm mb-1">1. PostgreSQL Relational Database Schema</h4>
                <p className="leading-relaxed">
                  Provisioned on Google Cloud SQL (Developer Edition, asia-southeast1). Drizzle ORM schema defined at <code>src/db/schema.ts</code> with 7 core tables:
                </p>
                <ul className="list-disc list-inside mt-1 space-y-0.5 text-slate-400">
                  <li><code>users</code>: Phone, bcrypt password hash, user ID, wallet, bonus, demo credits, language.</li>
                  <li><code>transactions</code>: Deposits, withdrawals, bets, wins, TrxID references, admin verification notes.</li>
                  <li><code>payment_accounts</code>: Configurable bKash, Nagad, Rocket numbers, types, and limits.</li>
                  <li><code>promotions</code>: Tiered deposit bonuses, wagering multipliers, validity dates.</li>
                  <li><code>referrals</code>: Unique referral codes, commission tracking, fraud prevention.</li>
                  <li><code>audit_logs</code>: Immutable administrator actions, target accounts, timestamps, IP logging.</li>
                  <li><code>game_history</code>: Round results, RTP telemetry, multipliers.</li>
                </ul>
              </div>

              <div>
                <h4 className="font-bold text-amber-400 text-sm mb-1">2. Server-Side Wallet Calculations & Anti-Duplicate Guarantees</h4>
                <p className="leading-relaxed">
                  All balance additions, deductions, and adjustments execute through transactional endpoints on the backend API.
                  Manual bKash/Nagad/Rocket deposits require unique TrxID references; duplicate TrxIDs are rejected at the database query level to prevent double-crediting.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-amber-400 text-sm mb-1">3. Environment Variables Template (.env)</h4>
                <pre className="p-3 bg-slate-950 rounded border border-slate-800 font-mono text-[11px] text-cyan-300 overflow-x-auto">
{`PORT=3000
SQL_HOST=127.0.0.1
SQL_USER=postgres
SQL_PASSWORD=password
SQL_DB_NAME=postgres
ADMIN_PIN=your_secure_admin_pin
APP_URL=https://bigwin999.com`}
                </pre>
              </div>

              <div>
                <h4 className="font-bold text-amber-400 text-sm mb-1">4. Hosting, Domain Connection & HTTPS</h4>
                <p className="leading-relaxed">
                  Run production build via <code>npm run build</code> and launch full-stack Node server with <code>npm start</code> (running <code>server.ts</code> on port 3000). For custom domain connections:
                </p>
                <ol className="list-decimal list-inside mt-1 space-y-0.5 text-slate-400">
                  <li>Point DNS A/AAAA records to your Cloud Run or server IP address.</li>
                  <li>Enable automatic TLS/SSL certificates via Let's Encrypt or Google Cloud Managed Certificates.</li>
                  <li>Enforce HTTP to HTTPS redirects and configure HSTS headers.</li>
                </ol>
              </div>

              <div>
                <h4 className="font-bold text-amber-400 text-sm mb-1">5. Backup & Recovery Instructions</h4>
                <p className="leading-relaxed">
                  Automated Cloud SQL backups run daily. To perform manual pg_dump:
                  <code className="block p-2 bg-slate-950 rounded mt-1 font-mono text-[11px] text-emerald-400">
                    pg_dump -h $SQL_HOST -U $SQL_USER -d $SQL_DB_NAME -F c -b -v -f bigwin999_backup.dump
                  </code>
                </p>
              </div>

              <div className="p-3 bg-slate-900 border border-amber-500/30 rounded-lg text-slate-300">
                <span className="font-bold text-amber-400 block mb-0.5">Jurisdiction & Compliance Reminder:</span>
                Virtual demo mode is active by default. Real-money gaming must be restricted to jurisdictions with applicable licensing, independent fairness testing (e.g. eCOGRA/iTech Labs), and age 18+ KYC verification.
              </div>
            </div>

            <div className="pt-2 text-right">
              <button
                onClick={() => setShowDocsModal(false)}
                className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-lg text-xs"
              >
                Close Documentation
              </button>
            </div>
          </div>
        </div>
      )}
      </div>
    </NotificationProvider>
  );
}
