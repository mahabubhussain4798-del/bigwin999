import React, { useState, useEffect } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
  Area,
  ComposedChart
} from 'recharts';
import { TrendingUp, TrendingDown, Award, Zap, RefreshCw } from 'lucide-react';

interface DayStat {
  day: string;
  date: string;
  totalBet: number;
  totalPayout: number;
  netProfit: number;
  win: number;
  loss: number;
  rounds: number;
}

interface BettingTrendChartProps {
  userId: number;
}

export const BettingTrendChart: React.FC<BettingTrendChartProps> = ({ userId }) => {
  const [data, setData] = useState<DayStat[]>([]);
  const [totalWagered, setTotalWagered] = useState<number>(0);
  const [totalWon, setTotalWon] = useState<number>(0);
  const [overallNet, setOverallNet] = useState<number>(0);
  const [loading, setLoading] = useState(true);

  const loadData = () => {
    if (!userId) return;
    setLoading(true);
    fetch(`/api/user/game-stats/${userId}`)
      .then((r) => r.json())
      .then((res) => {
        if (res.history) {
          setData(res.history);
          setTotalWagered(res.totalWagered || 0);
          setTotalWon(res.totalWon || 0);
          setOverallNet(res.overallNet || 0);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadData();
  }, [userId]);

  // Custom Dark Mode Tooltip
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const item = payload[0].payload as DayStat;
      const isPositive = item.netProfit >= 0;
      return (
        <div className="bg-[#070b1a] border border-slate-700 p-2.5 rounded-lg shadow-xl text-xs font-mono space-y-1">
          <div className="font-bold text-slate-200 border-b border-slate-800 pb-1 flex items-center justify-between gap-3 font-sans">
            <span>{item.day} ({item.date})</span>
            <span className="text-[10px] text-slate-400">{item.rounds} rounds</span>
          </div>

          <div className={`font-bold ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
            Net P&L: {isPositive ? '+' : ''}৳{item.netProfit.toFixed(2)}
          </div>

          <div className="text-[11px] text-slate-400 flex items-center justify-between gap-3">
            <span>Wagered: ৳{item.totalBet}</span>
            <span>Payout: ৳{item.totalPayout}</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-[#0b1226] border border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
      {/* Header with Net Performance Badge */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <div className="flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-amber-400" />
            <h4 className="text-sm font-bold text-white tracking-tight">
              7-Day Betting Win / Loss Trend
            </h4>
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Daily net gaming returns (Total Payout − Total Wagered)
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold flex items-center gap-1 border ${
            overallNet >= 0
              ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
              : 'bg-rose-500/15 border-rose-500/30 text-rose-400'
          }`}>
            {overallNet >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
            <span>Net: {overallNet >= 0 ? '+' : ''}৳{overallNet.toFixed(2)}</span>
          </div>

          <button
            onClick={loadData}
            className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
            title="Refresh statistics"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* 3-Pill KPI Overview */}
      <div className="grid grid-cols-3 gap-2 text-xs font-mono">
        <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800">
          <span className="text-[10px] text-slate-500 font-sans block">7-Day Wagered</span>
          <span className="font-bold text-slate-200">৳{totalWagered.toFixed(2)}</span>
        </div>

        <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800">
          <span className="text-[10px] text-slate-500 font-sans block">7-Day Payout</span>
          <span className="font-bold text-emerald-400">৳{totalWon.toFixed(2)}</span>
        </div>

        <div className="p-2.5 bg-slate-900/60 rounded border border-slate-800">
          <span className="text-[10px] text-slate-500 font-sans block">Win/Loss Return</span>
          <span className={`font-bold ${overallNet >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {totalWagered > 0 ? `${((totalWon / totalWagered) * 100).toFixed(0)}%` : '100%'}
          </span>
        </div>
      </div>

      {/* Recharts Compact Trendline */}
      <div className="h-44 w-full pt-1">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
            <defs>
              <linearGradient id="profileProfitGlow" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10B981" stopOpacity={0.2} />
                <stop offset="95%" stopColor="#10B981" stopOpacity={0.0} />
              </linearGradient>
            </defs>

            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />

            <XAxis
              dataKey="day"
              stroke="#64748b"
              fontSize={10}
              tickLine={false}
              axisLine={{ stroke: '#334155' }}
            />

            <YAxis
              stroke="#64748b"
              fontSize={10}
              tickLine={false}
              axisLine={{ stroke: '#334155' }}
              tickFormatter={(val) => `৳${val}`}
            />

            <Tooltip content={<CustomTooltip />} />

            {/* Zero break-even reference line */}
            <ReferenceLine y={0} stroke="#475569" strokeDasharray="2 2" />

            <Area
              type="monotone"
              dataKey="netProfit"
              fill="url(#profileProfitGlow)"
              stroke="none"
            />

            <Line
              type="monotone"
              dataKey="netProfit"
              name="Net P&L"
              stroke="#10B981"
              strokeWidth={2.5}
              dot={{ r: 3, fill: '#10B981', strokeWidth: 1, stroke: '#070b1a' }}
              activeDot={{ r: 5, fill: '#34D399', stroke: '#FFFFFF', strokeWidth: 2 }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-800/80">
        <span>Break-even baseline: ৳0.00</span>
        <span className="font-mono">Rolling 7-day performance</span>
      </div>
    </div>
  );
};
