import React, { useState } from 'react';
import { X, Lock, Phone, User as UserIcon, KeyRound, HelpCircle, CheckCircle, ArrowRight } from 'lucide-react';
import { TRANSLATIONS, Language } from '../../data/translations.ts';

interface AuthModalProps {
  initialTab?: 'login' | 'register' | 'recover';
  onClose: () => void;
  onSuccess: (user: any) => void;
  lang: Language;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  initialTab = 'login',
  onClose,
  onSuccess,
  lang,
}) => {
  const [tab, setTab] = useState<'login' | 'register' | 'recover'>(initialTab);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [referredBy, setReferredBy] = useState('');
  const [securityQuestion, setSecurityQuestion] = useState('Favorite Game');
  const [securityAnswer, setSecurityAnswer] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const t = TRANSLATIONS[lang];

  // Quick autofill demo accounts
  const autofillDemoUser = () => {
    setPhone('01811223344');
    setPassword('User@123');
    setTab('login');
    setError(null);
  };

  const autofillAdmin = () => {
    setPhone('01700000000');
    setPassword('Admin@999');
    setTab('login');
    setError(null);
  };

  // Submit Handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      if (tab === 'register') {
        const res = await fetch('/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name,
            phone,
            password,
            referredBy,
            securityQuestion,
            securityAnswer,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Registration failed');

        onSuccess(data.user);
        onClose();
      } else if (tab === 'login') {
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phone, password }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Login failed');

        onSuccess(data.user);
        onClose();
      } else if (tab === 'recover') {
        const res = await fetch('/api/auth/recover', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phone, securityAnswer, newPassword }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Recovery failed');

        setSuccessMsg(data.message);
        setTimeout(() => setTab('login'), 1800);
      }
    } catch (err: any) {
      setError(err.message || 'Operation failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-md bg-[#0b1226] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-auto">
        {/* Header */}
        <div className="px-6 py-4 bg-[#070b1a] border-b border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-1.5">
              <span className="text-amber-400 font-extrabold tracking-tight">BIGWIN999</span>
              <span className="text-slate-400 font-normal">·</span>
              <span className="text-slate-300 font-medium">
                {tab === 'login' ? t.login : tab === 'register' ? t.register : 'Reset Password'}
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              {tab === 'register' ? 'Join 100,000+ players & get ৳10K demo credits' : 'Access your gaming wallet and favorites'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-2 p-1.5 bg-slate-900/80 border-b border-slate-800 text-xs font-semibold">
          <button
            type="button"
            onClick={() => { setTab('login'); setError(null); }}
            className={`py-2 rounded-lg transition-colors ${
              tab === 'login' ? 'bg-amber-500 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.login}
          </button>
          <button
            type="button"
            onClick={() => { setTab('register'); setError(null); }}
            className={`py-2 rounded-lg transition-colors ${
              tab === 'register' ? 'bg-amber-500 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.register}
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-xs text-red-400">
              {error}
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-xs text-emerald-400 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {tab === 'register' && (
            <div>
              <label className="text-xs text-slate-300 font-medium mb-1 block">Full Name</label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahim Chowdhury"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
          )}

          <div>
            <label className="text-xs text-slate-300 font-medium mb-1 block">Mobile Number (BD)</label>
            <div className="relative">
              <Phone className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="tel"
                required
                placeholder="01XXXXXXXXX"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {tab !== 'recover' && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs text-slate-300 font-medium">Password</label>
                {tab === 'login' && (
                  <button
                    type="button"
                    onClick={() => { setTab('recover'); setError(null); }}
                    className="text-[11px] text-amber-400 hover:underline"
                  >
                    Forgot Password?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
          )}

          {tab === 'register' && (
            <>
              <div>
                <label className="text-xs text-slate-300 font-medium mb-1 block">Referral Code (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. BW10294"
                  value={referredBy}
                  onChange={(e) => setReferredBy(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white uppercase font-mono placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 font-medium mb-1 block">Security Question (For recovery)</label>
                <select
                  value={securityQuestion}
                  onChange={(e) => setSecurityQuestion(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="Favorite Game">What is your favorite game?</option>
                  <option value="Childhood Nickname">What was your childhood nickname?</option>
                  <option value="Birth City">In which city were you born?</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-300 font-medium mb-1 block">Security Answer</label>
                <div className="relative">
                  <HelpCircle className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    placeholder="Your secret answer"
                    value={securityAnswer}
                    onChange={(e) => setSecurityAnswer(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            </>
          )}

          {tab === 'recover' && (
            <>
              <div>
                <label className="text-xs text-slate-300 font-medium mb-1 block">Security Answer (Favorite Game / Nickname)</label>
                <input
                  type="text"
                  required
                  placeholder="Answer to your security question"
                  value={securityAnswer}
                  onChange={(e) => setSecurityAnswer(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 font-medium mb-1 block">New Password</label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    placeholder="Minimum 6 characters"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            </>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg shadow-lg shadow-amber-500/20 active:scale-98 transition-all flex items-center justify-center gap-1.5"
          >
            <span>{loading ? 'Processing...' : tab === 'login' ? t.login : tab === 'register' ? 'Create Account' : 'Reset Password'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          {/* Quick Demo Credentials helper */}
          <div className="pt-3 border-t border-slate-800 text-center">
            <span className="text-[11px] text-slate-500 block mb-2">Quick test credentials:</span>
            <div className="flex items-center justify-center gap-2">
              <button
                type="button"
                onClick={autofillDemoUser}
                className="text-[11px] px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded border border-slate-700"
              >
                Autofill User (Rahim)
              </button>
              <button
                type="button"
                onClick={autofillAdmin}
                className="text-[11px] px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded border border-slate-700"
              >
                Autofill Admin
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
