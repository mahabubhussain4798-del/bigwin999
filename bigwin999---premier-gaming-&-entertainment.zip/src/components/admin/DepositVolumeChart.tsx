import React, { useState } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Area,
  ComposedChart
} from 'recharts';
import { TrendingUp, Calendar, DollarSign, ArrowUpRight, Filter } from 'lucide-react';

interface DailyDepositPoint {
  date: string;
  fullDate: string;
  amount: number;
  transactions: number;
  bKash: number;
  nagad: number;
  rocket: number;
}

interface DepositVolumeChartProps {
  data: DailyDepositPoint[];
}

export const DepositVolumeChart: React.FC<DepositVolumeChartProps> = ({ data }) => {
  const [viewMode, setViewMode] = useState<'total' | 'breakdown'>('total');

  if (!data || data.length === 0) {
    return (
      <div className="p-8 text-center text-slate-500 bg-[#0b1226] border border-slate-800 rounded-xl">
        No 30-day deposit data available.
      </div>
    );
  }

  // Calculate 30-day metrics
  const total30Days = data.reduce((sum, d) => sum + d.amount, 0);
  const avgDaily = Math.round(total30Days / data.length);
  const peakDay = [...data].sort((a, b) => b.amount - a.amount)[0];
  const lowestDay = [...data].sort((a, b) => a.amount - b.amount)[0];

  // Custom Dark Mode Tooltip
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const point = payload[0].payload as DailyDepositPoint;
      return (
        <div className="bg-[#070b1a] border border-slate-700/80 p-3 rounded-lg shadow-xl text-xs space-y-1.5 font-mono">
          <div className="font-bold text-slate-200 border-b border-slate-800 pb-1 flex items-center justify-between gap-4 font-sans">
            <span>{point.date} ({point.fullDate})</span>
            <span className="text-[11px] text-slate-400">{point.transactions} txns</span>
          </div>

          <div className="text-amber-400 font-bold text-sm">
            Total: ৳{point.amount.toLocaleString()}
          </div>

          <div className="grid grid-cols-3 gap-2 text-[10px] pt-1 text-slate-400 border-t border-slate-800/80">
            <div>
              <span className="text-pink-400 font-semibold block">bKash</span>
              <span>৳{point.bKash.toLocaleString()}</span>
            </div>
            <div>
              <span className="text-orange-400 font-semibold block">Nagad</span>
              <span>৳{point.nagad.toLocaleString()}</span>
            </div>
            <div>
              <span className="text-purple-400 font-semibold block">Rocket</span>
              <span>৳{point.rocket.toLocaleString()}</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-6 bg-[#0b1226] border border-slate-800 rounded-xl space-y-6 shadow-xl">
      {/* Header and Toggle Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-amber-400" />
            <h3 className="text-base font-bold text-white tracking-tight">
              30-Day Daily Deposit Volumes
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time daily incoming payment volume trend across bKash, Nagad, and Rocket
          </p>
        </div>

        {/* View mode toggle */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-lg text-xs font-semibold">
          <button
            onClick={() => setViewMode('total')}
            className={`px-3 py-1.5 rounded transition-colors ${
              viewMode === 'total'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Total Volume
          </button>
          <button
            onClick={() => setViewMode('breakdown')}
            className={`px-3 py-1.5 rounded transition-colors ${
              viewMode === 'breakdown'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Gateway Breakdown
          </button>
        </div>
      </div>

      {/* 4-KPI Summary Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-mono">
        <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 font-sans block">30-Day Total Volume</span>
          <span className="text-base font-bold text-emerald-400">৳{total30Days.toLocaleString()}</span>
        </div>

        <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 font-sans block">Daily Average</span>
          <span className="text-base font-bold text-white">৳{avgDaily.toLocaleString()}</span>
        </div>

        <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 font-sans block">Peak Day ({peakDay?.date})</span>
          <span className="text-base font-bold text-amber-400">৳{peakDay?.amount.toLocaleString()}</span>
        </div>

        <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 font-sans block">Lowest Day ({lowestDay?.date})</span>
          <span className="text-base font-bold text-slate-400">৳{lowestDay?.amount.toLocaleString()}</span>
        </div>
      </div>

      {/* Recharts Interactive Line Chart Container */}
      <div className="h-72 w-full pt-2">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
            <defs>
              <linearGradient id="depositGlow" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.25} />
                <stop offset="95%" stopColor="#F59E0B" stopOpacity={0.0} />
              </linearGradient>
            </defs>

            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />

            <XAxis
              dataKey="date"
              stroke="#64748b"
              fontSize={10}
              tickLine={false}
              axisLine={{ stroke: '#334155' }}
              interval={Math.floor(data.length / 8)}
            />

            <YAxis
              stroke="#64748b"
              fontSize={10}
              tickLine={false}
              axisLine={{ stroke: '#334155' }}
              tickFormatter={(val) => `৳${(val / 1000).toFixed(0)}k`}
            />

            <Tooltip content={<CustomTooltip />} />

            {viewMode === 'total' ? (
              <>
                <Area
                  type="monotone"
                  dataKey="amount"
                  fill="url(#depositGlow)"
                  stroke="none"
                />
                <Line
                  type="monotone"
                  dataKey="amount"
                  name="Total Deposit (৳)"
                  stroke="#F59E0B"
                  strokeWidth={2.5}
                  dot={{ r: 2.5, fill: '#F59E0B', strokeWidth: 1, stroke: '#070b1a' }}
                  activeDot={{ r: 5, fill: '#FBBF24', stroke: '#FFFFFF', strokeWidth: 2 }}
                />
              </>
            ) : (
              <>
                <Line
                  type="monotone"
                  dataKey="bKash"
                  name="bKash (৳)"
                  stroke="#EC4899"
                  strokeWidth={2}
                  dot={{ r: 2, fill: '#EC4899' }}
                />
                <Line
                  type="monotone"
                  dataKey="nagad"
                  name="Nagad (৳)"
                  stroke="#F97316"
                  strokeWidth={2}
                  dot={{ r: 2, fill: '#F97316' }}
                />
                <Line
                  type="monotone"
                  dataKey="rocket"
                  name="Rocket (৳)"
                  stroke="#A855F7"
                  strokeWidth={2}
                  dot={{ r: 2, fill: '#A855F7' }}
                />
                <Legend
                  wrapperStyle={{ paddingTop: '10px', fontSize: '11px' }}
                />
              </>
            )}
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-800">
        <span>Timeline: Last 30 rolling calendar days</span>
        <span className="font-mono">Metric: Settled & Verified Deposits</span>
      </div>
    </div>
  );
};
