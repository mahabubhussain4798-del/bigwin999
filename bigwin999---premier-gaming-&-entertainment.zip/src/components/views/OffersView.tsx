import React, { useState, useEffect } from 'react';
import { Gift, Sparkles, Check, ArrowRight, ShieldCheck, ChevronDown, ChevronUp } from 'lucide-react';
import { TRANSLATIONS, Language } from '../../data/translations.ts';

interface OffersViewProps {
  onNavigate: (view: string) => void;
  lang: Language;
}

export const OffersView: React.FC<OffersViewProps> = ({ onNavigate, lang }) => {
  const [promotionsList, setPromotionsList] = useState<any[]>([]);
  const [expandedTerms, setExpandedTerms] = useState<{ [id: number]: boolean }>({});
  const [loading, setLoading] = useState(true);

  const t = TRANSLATIONS[lang];

  useEffect(() => {
    fetch('/api/promotions')
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data)) setPromotionsList(data);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const toggleTerms = (id: number) => {
    setExpandedTerms(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-6 pb-16 max-w-5xl mx-auto">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-lg text-xs font-bold text-amber-400">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Exclusive Promotions & Deposit Tiers</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
          Boost Your Play with BIGWIN999 Offers
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
          From ৳100 starter boosts to ৳20,000 VIP high roller bonuses, unlock extra playing credits on every deposit.
        </p>
      </div>

      {/* Promo Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {promotionsList.map((promo) => {
          const isExpanded = !!expandedTerms[promo.id];
          return (
            <div
              key={promo.id}
              className="bg-[#0b1226] border border-slate-800 hover:border-amber-500/40 rounded-xl p-5 shadow-lg flex flex-col justify-between transition-all"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded">
                    CODE: {promo.code}
                  </span>
                  <span className="text-xs font-mono text-emerald-400 font-semibold">
                    +{promo.bonusPercent}% Extra
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-white">
                    {lang === 'bn' ? promo.titleBn : promo.title}
                  </h3>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    {lang === 'bn' ? promo.descriptionBn : promo.description}
                  </p>
                </div>

                {/* Key tier statistics */}
                <div className="grid grid-cols-3 gap-2 py-2 border-y border-slate-800/80 text-[11px] font-mono">
                  <div>
                    <span className="text-slate-500 block">Min Deposit</span>
                    <span className="font-bold text-white">৳{promo.minDeposit}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Max Bonus</span>
                    <span className="font-bold text-amber-400">৳{promo.maxBonus}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Wagering</span>
                    <span className="font-bold text-slate-300">{promo.wageringRequirement}x</span>
                  </div>
                </div>

                {/* Terms toggle */}
                <div>
                  <button
                    onClick={() => toggleTerms(promo.id)}
                    className="text-[11px] text-slate-400 hover:text-slate-200 flex items-center gap-1 font-medium"
                  >
                    <span>Full Terms & Conditions</span>
                    {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                  </button>
                  {isExpanded && (
                    <div className="mt-2 p-3 bg-slate-950/70 rounded border border-slate-800 text-[11px] text-slate-400 leading-relaxed space-y-1">
                      <p>{promo.terms}</p>
                      <p className="text-slate-500">Validity: {promo.validityDays} days after activation.</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-4 mt-2">
                <button
                  onClick={() => onNavigate('wallet')}
                  className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg shadow-md active:scale-98 transition-all flex items-center justify-center gap-1.5"
                >
                  <span>Deposit & Claim {promo.code}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* General Bonus T&C Policy */}
      <div className="p-4 bg-slate-900/40 border border-slate-800 rounded-xl text-xs text-slate-400 space-y-2">
        <div className="flex items-center gap-2 font-bold text-slate-200">
          <ShieldCheck className="w-4 h-4 text-amber-400" />
          <span>General Bonus Policy & Fair Gaming Rules</span>
        </div>
        <p className="leading-relaxed">
          1. Bonuses are credited as bonus balances and convert to withdrawable funds upon satisfying turnover requirements.
          2. Only one promotional offer may be claimed per qualifying deposit transaction.
          3. Unverified cash rewards or guaranteed winnings are strictly prohibited under our fair-play charter.
        </p>
      </div>
    </div>
  );
};
