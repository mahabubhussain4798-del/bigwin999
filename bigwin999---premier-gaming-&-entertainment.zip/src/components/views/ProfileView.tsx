import React, { useState } from 'react';
import { User, Phone, ShieldCheck, Key, Globe, LogOut, Check, AlertCircle } from 'lucide-react';
import { TRANSLATIONS, Language } from '../../data/translations.ts';
import { BettingTrendChart } from '../profile/BettingTrendChart.tsx';

interface ProfileViewProps {
  user: any;
  onUpdateUser: (updated: any) => void;
  onLogout: () => void;
  lang: Language;
  onToggleLang: (lang: Language) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  onUpdateUser,
  onLogout,
  lang,
  onToggleLang,
}) => {
  const [name, setName] = useState(user?.name || '');
  const [selectedLanguage, setSelectedLanguage] = useState<Language>(lang);
  const [securityQuestion, setSecurityQuestion] = useState(user?.securityQuestion || 'Favorite Game');
  const [securityAnswer, setSecurityAnswer] = useState('');
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ text: string; error?: boolean } | null>(null);

  const t = TRANSLATIONS[lang];

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    setMsg(null);

    try {
      const res = await fetch(`/api/user/profile/${user.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          language: selectedLanguage,
          securityQuestion,
          securityAnswer: securityAnswer || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Update failed');

      onUpdateUser(data);
      onToggleLang(selectedLanguage);
      setMsg({ text: 'Profile & security preferences saved successfully.' });
    } catch (err: any) {
      setMsg({ text: err.message, error: true });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 pb-16 max-w-3xl mx-auto">
      {/* Profile Overview Card */}
      <div className="p-6 bg-[#0b1226] border border-slate-800 rounded-xl shadow-xl flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-amber-500 to-amber-300 text-slate-950 font-extrabold text-xl flex items-center justify-center shadow-lg">
            {user?.name ? user.name.slice(0, 2).toUpperCase() : 'BW'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white">{user?.name}</h2>
              <span className="text-[10px] font-mono font-bold bg-amber-500/20 border border-amber-500/40 text-amber-300 px-2 py-0.5 rounded">
                {user?.userId}
              </span>
            </div>
            <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
              <span>{user?.phone}</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-400 font-semibold capitalize">{user?.status || 'Active'}</span>
            </div>
          </div>
        </div>

        <button
          onClick={onLogout}
          className="px-4 py-2 bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>{t.logout}</span>
        </button>
      </div>

      {/* 7-Day Betting Win/Loss Trend Chart */}
      {user && <BettingTrendChart userId={user.id} />}

      {/* Profile Edit Form */}
      <div className="bg-[#0b1226] border border-slate-800 rounded-xl p-6 shadow-xl">
        <h3 className="text-base font-bold text-white mb-4">Account Settings & Security</h3>

        <form onSubmit={handleSave} className="space-y-4">
          {msg && (
            <div className={`p-3 rounded-lg text-xs ${msg.error ? 'bg-red-500/10 border border-red-500/30 text-red-400' : 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400'}`}>
              {msg.text}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-slate-300 font-medium mb-1 block">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-xs text-slate-300 font-medium mb-1 block">Language Preference</label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedLanguage('en')}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                    selectedLanguage === 'en'
                      ? 'bg-amber-500 text-slate-950 font-bold border-amber-500'
                      : 'bg-slate-900 text-slate-300 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  English (EN)
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedLanguage('bn')}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                    selectedLanguage === 'bn'
                      ? 'bg-amber-500 text-slate-950 font-bold border-amber-500'
                      : 'bg-slate-900 text-slate-300 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  বাংলা (BN)
                </button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-800">
            <div>
              <label className="text-xs text-slate-300 font-medium mb-1 block">Security Question (For Recovery)</label>
              <select
                value={securityQuestion}
                onChange={(e) => setSecurityQuestion(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              >
                <option value="Favorite Game">What is your favorite game?</option>
                <option value="Childhood Nickname">What was your childhood nickname?</option>
                <option value="Birth City">In which city were you born?</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-slate-300 font-medium mb-1 block">Update Security Answer (Optional)</label>
              <input
                type="text"
                placeholder="Leave blank to keep existing answer"
                value={securityAnswer}
                onChange={(e) => setSecurityAnswer(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="py-2.5 px-6 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg shadow-md transition-all active:scale-98"
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </form>
      </div>

      {/* Account Audit Details */}
      <div className="p-4 bg-slate-900/40 border border-slate-800 rounded-xl space-y-2 text-xs text-slate-400">
        <div className="flex items-center gap-2 font-bold text-slate-300">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Security & Authentication Audit</span>
        </div>
        <p>
          Account ID: <span className="font-mono text-white">{user?.userId}</span> · Registered Phone: <span className="font-mono text-white">{user?.phone}</span> · Status: <span className="text-emerald-400 font-semibold uppercase">{user?.status || 'Active'}</span>
        </p>
      </div>
    </div>
  );
};
