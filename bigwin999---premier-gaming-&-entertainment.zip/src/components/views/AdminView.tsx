import React, { useState, useEffect } from 'react';
import {
  ShieldAlert, Users, ArrowDownToLine, ArrowUpFromLine, Clock,
  DollarSign, Award, Gift, Search, Check, X, Edit, Sliders,
  Lock, RefreshCw, Download, FileText, CheckCircle2, AlertTriangle, ShieldCheck
} from 'lucide-react';
import { DepositVolumeChart } from '../admin/DepositVolumeChart.tsx';
import { useNotifications } from '../../context/NotificationContext.tsx';

export const AdminView: React.FC = () => {
  const { notifyDepositApproved } = useNotifications();
  // Admin auth gate
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(false);
  const [adminPin, setAdminPin] = useState<string>('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Active admin section tab
  const [activeTab, setActiveTab] = useState<'dashboard' | 'users' | 'deposits' | 'withdrawals' | 'payments' | 'promotions' | 'audit'>('dashboard');

  // Stats state (11 required metrics)
  const [stats, setStats] = useState<any>(null);
  const [statsLoading, setStatsLoading] = useState(false);

  // Users management state
  const [usersList, setUsersList] = useState<any[]>([]);
  const [userSearch, setUserSearch] = useState('');
  const [selectedUserForAdjust, setSelectedUserForAdjust] = useState<any | null>(null);
  const [adjustAmount, setAdjustAmount] = useState<string>('100');
  const [adjustReason, setAdjustReason] = useState<string>('');
  const [adjustMsg, setAdjustMsg] = useState<string | null>(null);

  // Deposits & Withdrawals state
  const [depositsList, setDepositsList] = useState<any[]>([]);
  const [withdrawalsList, setWithdrawalsList] = useState<any[]>([]);
  const [actionLoadingId, setActionLoadingId] = useState<number | null>(null);

  // Payment settings state
  const [paymentAccounts, setPaymentAccounts] = useState<any[]>([]);
  const [editingAccount, setEditingAccount] = useState<any | null>(null);

  // Promotions management state
  const [promotionsList, setPromotionsList] = useState<any[]>([]);
  const [editingPromo, setEditingPromo] = useState<any | null>(null);

  // Audit logs state
  const [auditLogsList, setAuditLogsList] = useState<any[]>([]);

  // Authenticate Admin
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin: adminPin }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Authentication failed');

      setIsAdminLoggedIn(true);
      loadAllAdminData();
    } catch (err: any) {
      setLoginError(err.message || 'Invalid Master Admin PIN');
    }
  };

  // Load all admin datasets
  const loadAllAdminData = () => {
    loadStats();
    loadUsers();
    loadDeposits();
    loadWithdrawals();
    loadPaymentAccounts();
    loadPromotions();
    loadAuditLogs();
  };

  const loadStats = () => {
    setStatsLoading(true);
    fetch('/api/admin/stats')
      .then(r => r.json())
      .then(setStats)
      .catch(console.error)
      .finally(() => setStatsLoading(false));
  };

  const loadUsers = () => {
    fetch(`/api/admin/users?search=${encodeURIComponent(userSearch)}`)
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setUsersList(data); })
      .catch(console.error);
  };

  const loadDeposits = () => {
    fetch('/api/admin/deposits')
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setDepositsList(data); })
      .catch(console.error);
  };

  const loadWithdrawals = () => {
    fetch('/api/admin/withdrawals')
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setWithdrawalsList(data); })
      .catch(console.error);
  };

  const loadPaymentAccounts = () => {
    fetch('/api/admin/payment-accounts')
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setPaymentAccounts(data); })
      .catch(console.error);
  };

  const loadPromotions = () => {
    fetch('/api/admin/promotions')
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setPromotionsList(data); })
      .catch(console.error);
  };

  const loadAuditLogs = () => {
    fetch('/api/admin/audit-logs')
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setAuditLogsList(data); })
      .catch(console.error);
  };

  // Adjust Wallet Balance
  const handleAdjustSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserForAdjust) return;
    if (!adjustReason || adjustReason.trim().length < 5) {
      alert('Mandatory reason of at least 5 characters is required for auditing.');
      return;
    }

    try {
      const res = await fetch(`/api/admin/users/${selectedUserForAdjust.id}/adjust-balance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: adjustAmount,
          reason: adjustReason,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Adjustment failed');

      setAdjustMsg(`Successfully adjusted balance. New Balance: ৳${data.newBalance}`);
      setAdjustReason('');
      loadUsers();
      loadStats();
      loadAuditLogs();
      setTimeout(() => setSelectedUserForAdjust(null), 1500);
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Toggle user status (active/suspended)
  const handleToggleUserStatus = async (user: any) => {
    const nextStatus = user.status === 'active' ? 'suspended' : 'active';
    const confirm = window.confirm(`Are you sure you want to change ${user.name}'s account status to ${nextStatus.toUpperCase()}?`);
    if (!confirm) return;

    try {
      const res = await fetch(`/api/admin/users/${user.id}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: nextStatus,
          reason: 'Manual administrator review',
        }),
      });
      if (res.ok) {
        loadUsers();
        loadAuditLogs();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Approve / Reject Deposit
  const handleDepositAction = async (txId: number, action: 'approve' | 'reject') => {
    const note = prompt(`Enter ${action.toUpperCase()} verification note:`, action === 'approve' ? 'Verified against bKash/Nagad statement' : 'Invalid or unconfirmed TrxID reference');
    if (note === null) return;

    setActionLoadingId(txId);
    try {
      const res = await fetch(`/api/admin/deposits/${txId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, adminNote: note }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      if (action === 'approve') {
        const item = depositsList.find(d => d.transaction?.id === txId);
        if (item && item.transaction) {
          notifyDepositApproved({
            amount: parseFloat(item.transaction.amount),
            method: item.transaction.method,
            transactionReference: item.transaction.transactionReference,
            txnId: item.transaction.txnId,
          });
        }
      }

      loadDeposits();
      loadStats();
      loadAuditLogs();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setActionLoadingId(null);
    }
  };

  // Approve / Reject Withdrawal
  const handleWithdrawalAction = async (txId: number, action: 'approve' | 'reject') => {
    const note = prompt(`Enter ${action.toUpperCase()} note:`, action === 'approve' ? 'Dispatched via gateway transfer' : 'Rejected: KYC documentation required');
    if (note === null) return;

    setActionLoadingId(txId);
    try {
      const res = await fetch(`/api/admin/withdrawals/${txId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, adminNote: note }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      loadWithdrawals();
      loadStats();
      loadAuditLogs();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setActionLoadingId(null);
    }
  };

  // Save payment account edit
  const handleSavePaymentAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAccount) return;

    try {
      const res = await fetch(`/api/admin/payment-accounts/${editingAccount.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editingAccount),
      });
      if (res.ok) {
        setEditingAccount(null);
        loadPaymentAccounts();
        loadAuditLogs();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Export Financial CSV Report
  const exportCsvReport = () => {
    const headers = ['Txn ID', 'User ID', 'Type', 'Method', 'Amount', 'Status', 'Reference', 'Created At'];
    const rows = depositsList.concat(withdrawalsList).map(t => {
      const tx = t.transaction || t;
      return [
        tx.txnId,
        tx.userId,
        tx.type,
        tx.method,
        tx.amount,
        tx.status,
        tx.transactionReference || '',
        new Date(tx.createdAt).toISOString()
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `bigwin999_financial_report_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // If not logged in as Admin, show Secure Login Gate
  if (!isAdminLoggedIn) {
    return (
      <div className="max-w-md mx-auto my-12 p-8 bg-[#0b1226] border border-amber-500/30 rounded-2xl shadow-2xl space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 mx-auto rounded-xl bg-amber-500/10 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Lock className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-extrabold text-white">Private Admin Gateway</h2>
          <p className="text-xs text-slate-400">Authorized personnel only. Access logged with IP and timestamp.</p>
        </div>

        <form onSubmit={handleAdminLogin} className="space-y-4">
          {loginError && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-xs text-red-400">
              {loginError}
            </div>
          )}

          <div>
            <label className="text-xs text-slate-300 font-semibold block mb-1">Master Administrator PIN</label>
            <input
              type="password"
              required
              value={adminPin}
              onChange={(e) => setAdminPin(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-center font-mono tracking-widest text-white focus:outline-none focus:border-amber-500"
              placeholder="••••••"
            />
            <p className="text-[11px] text-slate-500 mt-1 text-center">Enter your secure Administrator PIN (set in environment variable <code className="text-amber-400">ADMIN_PIN</code>).</p>
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-extrabold text-xs uppercase tracking-wider rounded-lg shadow-md active:scale-98 transition-all"
          >
            Authenticate & Open Dashboard
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20">
      {/* Top Admin Navigation Header */}
      <div className="p-4 sm:p-6 bg-[#090f22] border border-slate-800 rounded-xl shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-white tracking-tight">BIGWIN999 Control Center</span>
            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 rounded">
              Superadmin Mode
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Cloud SQL PostgreSQL · Server-Side Wallet Calculations · Full Audit Log
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={loadAllAdminData}
            className="p-2 text-slate-400 hover:text-white bg-slate-800/80 rounded-lg text-xs flex items-center gap-1.5 transition-colors"
            title="Refresh All Data"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${statsLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <button
            onClick={exportCsvReport}
            className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV Report</span>
          </button>

          <button
            onClick={() => setIsAdminLoggedIn(false)}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition-colors"
          >
            Exit Admin
          </button>
        </div>
      </div>

      {/* Admin Sub-navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar border-b border-slate-800 pb-2">
        {[
          { id: 'dashboard', label: 'Dashboard Stats', icon: Sliders },
          { id: 'users', label: `Users (${usersList.length})`, icon: Users },
          { id: 'deposits', label: `Deposits (${depositsList.filter(d => d.transaction.status === 'pending').length} Pending)`, icon: ArrowDownToLine },
          { id: 'withdrawals', label: `Withdrawals (${withdrawalsList.filter(w => w.transaction.status === 'pending').length} Pending)`, icon: ArrowUpFromLine },
          { id: 'payments', label: 'Payment Settings', icon: DollarSign },
          { id: 'promotions', label: 'Offers & Campaigns', icon: Gift },
          { id: 'audit', label: 'Audit & Security Logs', icon: FileText },
        ].map(t => {
          const Icon = t.icon;
          const isActive = activeTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 flex items-center gap-1.5 transition-colors ${
                isActive
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
                  : 'bg-[#0b1226] text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. Dashboard Statistics View (All 11 metrics required) */}
      {activeTab === 'dashboard' && stats && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5">
            {/* 1. Total Registered Users */}
            <div className="p-4 bg-[#0b1226] border border-slate-800 rounded-xl">
              <span className="text-[11px] text-slate-400 font-semibold uppercase">Total Users</span>
              <div className="text-2xl font-bold font-mono text-white mt-1">{stats.totalRegisteredUsers}</div>
              <span className="text-[10px] text-slate-500">Registered accounts</span>
            </div>

            {/* 2. Registrations Today */}
            <div className="p-4 bg-[#0b1226] border border-slate-800 rounded-xl">
              <span className="text-[11px] text-slate-400 font-semibold uppercase">New Today</span>
              <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">{stats.registrationsToday}</div>
              <span className="text-[10px] text-slate-500">Registrations past 24h</span>
            </div>

            {/* 3. Total Deposits */}
            <div className="p-4 bg-[#0b1226] border border-slate-800 rounded-xl">
              <span className="text-[11px] text-slate-400 font-semibold uppercase">Total Deposits</span>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">৳{stats.totalDeposits}</div>
              <span className="text-[10px] text-slate-500">All-time approved deposits</span>
            </div>

            {/* 4. Today's Deposits */}
            <div className="p-4 bg-[#0b1226] border border-slate-800 rounded-xl">
              <span className="text-[11px] text-slate-400 font-semibold uppercase">Today's Deposits</span>
              <div className="text-2xl font-bold font-mono text-emerald-300 mt-1">৳{stats.todayDeposits}</div>
              <span className="text-[10px] text-slate-500">Credited today</span>
            </div>

            {/* 5. Total Withdrawals */}
            <div className="p-4 bg-[#0b1226] border border-slate-800 rounded-xl">
              <span className="text-[11px] text-slate-400 font-semibold uppercase">Total Withdrawals</span>
              <div className="text-2xl font-bold font-mono text-amber-400 mt-1">৳{stats.totalWithdrawals}</div>
              <span className="text-[10px] text-slate-500">Completed payouts</span>
            </div>

            {/* 6. Today's Withdrawals */}
            <div className="p-4 bg-[#0b1226] border border-slate-800 rounded-xl">
              <span className="text-[11px] text-slate-400 font-semibold uppercase">Today's Withdrawals</span>
              <div className="text-2xl font-bold font-mono text-amber-300 mt-1">৳{stats.todayWithdrawals}</div>
              <span className="text-[10px] text-slate-500">Dispatched today</span>
            </div>

            {/* 7. Pending Deposit Requests */}
            <div className="p-4 bg-[#0b1226] border border-amber-500/40 rounded-xl">
              <span className="text-[11px] text-amber-400 font-bold uppercase">Pending Deposits</span>
              <div className="text-2xl font-bold font-mono text-amber-300 mt-1">
                {stats.pendingDepositRequestsCount} <span className="text-sm font-normal text-slate-400">(৳{stats.pendingDepositRequestsAmount})</span>
              </div>
              <span className="text-[10px] text-amber-400/80">Requires verification</span>
            </div>

            {/* 8. Pending Withdrawal Requests */}
            <div className="p-4 bg-[#0b1226] border border-purple-500/40 rounded-xl">
              <span className="text-[11px] text-purple-400 font-bold uppercase">Pending Withdrawals</span>
              <div className="text-2xl font-bold font-mono text-purple-300 mt-1">
                {stats.pendingWithdrawalRequestsCount} <span className="text-sm font-normal text-slate-400">(৳{stats.pendingWithdrawalRequestsAmount})</span>
              </div>
              <span className="text-[10px] text-purple-400/80">Awaiting payout</span>
            </div>

            {/* 9. Total Outstanding Wallet Balances */}
            <div className="p-4 bg-[#0b1226] border border-slate-800 rounded-xl">
              <span className="text-[11px] text-slate-400 font-semibold uppercase">Outstanding Balances</span>
              <div className="text-2xl font-bold font-mono text-white mt-1">৳{stats.totalOutstandingWalletBalances}</div>
              <span className="text-[10px] text-slate-500">User real balances sum</span>
            </div>

            {/* 10. Promotional Credits Issued */}
            <div className="p-4 bg-[#0b1226] border border-slate-800 rounded-xl">
              <span className="text-[11px] text-slate-400 font-semibold uppercase">Promo Credits</span>
              <div className="text-2xl font-bold font-mono text-blue-400 mt-1">৳{stats.promotionalCreditsIssued}</div>
              <span className="text-[10px] text-slate-500">Bonuses granted</span>
            </div>

            {/* 11. Referral Rewards Issued */}
            <div className="p-4 bg-[#0b1226] border border-slate-800 rounded-xl">
              <span className="text-[11px] text-slate-400 font-semibold uppercase">Referral Rewards</span>
              <div className="text-2xl font-bold font-mono text-yellow-400 mt-1">৳{stats.referralRewardsIssued}</div>
              <span className="text-[10px] text-slate-500">Affiliate commissions</span>
            </div>

            {/* Quick action card */}
            <div className="p-4 bg-gradient-to-br from-amber-500/20 to-slate-900 border border-amber-500/40 rounded-xl flex flex-col justify-between">
              <span className="text-[11px] text-amber-300 font-bold uppercase">Action Queue</span>
              <button
                onClick={() => setActiveTab('deposits')}
                className="w-full py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded transition-all"
              >
                Review Deposits →
              </button>
            </div>
          </div>

          {/* 30-Day Recharts Daily Deposit Volumes Line Chart */}
          <DepositVolumeChart data={stats.dailyDeposits30Days || []} />

          {/* 7-Day Trend Visual Chart */}
          <div className="p-6 bg-[#0b1226] border border-slate-800 rounded-xl space-y-4">
            <h3 className="text-sm font-bold text-white">7-Day Financial Volume (Deposits vs Withdrawals)</h3>
            <div className="grid grid-cols-7 gap-2 h-44 items-end pt-6 border-b border-slate-800">
              {stats.daysTrend?.map((item: any, idx: number) => {
                const maxVal = Math.max(...stats.daysTrend.map((d: any) => Math.max(d.deposits, d.withdrawals)), 1000);
                const depHeight = Math.min(100, Math.max(10, (item.deposits / maxVal) * 100));
                const wthHeight = Math.min(100, Math.max(10, (item.withdrawals / maxVal) * 100));

                return (
                  <div key={idx} className="flex flex-col items-center h-full justify-end gap-1">
                    <div className="flex items-end gap-1 w-full justify-center h-32">
                      <div
                        style={{ height: `${depHeight}%` }}
                        className="w-3 sm:w-5 bg-emerald-500 rounded-t"
                        title={`Deposits: ৳${item.deposits}`}
                      />
                      <div
                        style={{ height: `${wthHeight}%` }}
                        className="w-3 sm:w-5 bg-amber-500 rounded-t"
                        title={`Withdrawals: ৳${item.withdrawals}`}
                      />
                    </div>
                    <span className="text-[10px] text-slate-400 whitespace-nowrap truncate w-full text-center">
                      {item.date}
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center justify-center gap-6 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 bg-emerald-500 rounded" />
                <span>Deposits (৳)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 bg-amber-500 rounded" />
                <span>Withdrawals (৳)</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Users Management View */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search user by name, phone, user ID..."
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && loadUsers()}
                className="w-full bg-[#0b1226] border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>
            <button
              onClick={loadUsers}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg"
            >
              Search Users
            </button>
          </div>

          <div className="overflow-x-auto bg-[#0b1226] border border-slate-800 rounded-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3">User ID</th>
                  <th className="p-3">Name</th>
                  <th className="p-3">Phone</th>
                  <th className="p-3">Wallet (৳)</th>
                  <th className="p-3">Bonus (৳)</th>
                  <th className="p-3">Demo (৳)</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono">
                {usersList.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-900/40">
                    <td className="p-3 font-bold text-amber-400">{u.userId}</td>
                    <td className="p-3 font-sans font-medium text-white">{u.name}</td>
                    <td className="p-3 text-slate-300">{u.phone}</td>
                    <td className="p-3 font-bold text-emerald-400">৳{parseFloat(u.walletBalance).toFixed(2)}</td>
                    <td className="p-3 text-slate-400">৳{parseFloat(u.bonusBalance).toFixed(2)}</td>
                    <td className="p-3 text-slate-500">৳{parseFloat(u.demoBalance).toFixed(2)}</td>
                    <td className="p-3">
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        u.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                      }`}>
                        {u.status}
                      </span>
                    </td>
                    <td className="p-3 text-right space-x-2 font-sans">
                      <button
                        onClick={() => { setSelectedUserForAdjust(u); setAdjustMsg(null); }}
                        className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded text-xs font-semibold"
                      >
                        Adjust Credits
                      </button>
                      <button
                        onClick={() => handleToggleUserStatus(u)}
                        className={`px-2.5 py-1 rounded text-xs font-semibold border ${
                          u.status === 'active'
                            ? 'bg-red-500/20 text-red-400 border-red-500/40 hover:bg-red-500/30'
                            : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 hover:bg-emerald-500/30'
                        }`}
                      >
                        {u.status === 'active' ? 'Suspend' : 'Activate'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Adjust Balance Modal */}
          {selectedUserForAdjust && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
              <div className="bg-[#0b1226] border border-amber-500/40 rounded-xl p-6 max-w-md w-full space-y-4 shadow-2xl">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white">
                    Adjust Wallet Credits for {selectedUserForAdjust.name}
                  </h3>
                  <button onClick={() => setSelectedUserForAdjust(null)} className="text-slate-400 hover:text-white">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {adjustMsg && (
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded text-xs text-emerald-400">
                    {adjustMsg}
                  </div>
                )}

                <form onSubmit={handleAdjustSubmit} className="space-y-4">
                  <div>
                    <label className="text-xs text-slate-300 font-semibold block mb-1">
                      Adjustment Amount (৳) — Use negative for deduction
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      required
                      value={adjustAmount}
                      onChange={(e) => setAdjustAmount(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-white"
                      placeholder="e.g. 500 or -200"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-slate-300 font-semibold block mb-1">
                      Mandatory Reason (Logged in Financial Audit Trail) <span className="text-red-400">*</span>
                    </label>
                    <textarea
                      required
                      rows={3}
                      value={adjustReason}
                      onChange={(e) => setAdjustReason(e.target.value)}
                      placeholder="e.g. VIP goodwill bonus, correction for gateway downtime ticket #8492"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg shadow-md"
                  >
                    Confirm & Record Audit Log
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. Deposits Review Queue */}
      {activeTab === 'deposits' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Deposit Requests Queue</h3>
            <span className="text-xs text-slate-400">Verify user TrxID against SMS/merchant statement</span>
          </div>

          <div className="overflow-x-auto bg-[#0b1226] border border-slate-800 rounded-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3">Txn ID</th>
                  <th className="p-3">User</th>
                  <th className="p-3">Method</th>
                  <th className="p-3">TrxID / Ref</th>
                  <th className="p-3">Amount</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Date</th>
                  <th className="p-3 text-right">Verification Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono">
                {depositsList.map((item) => {
                  const tx = item.transaction;
                  const u = item.user;
                  return (
                    <tr key={tx.id} className="hover:bg-slate-900/40">
                      <td className="p-3 font-semibold text-slate-300">{tx.txnId}</td>
                      <td className="p-3 font-sans">
                        <div className="font-bold text-white">{u?.name}</div>
                        <div className="text-[10px] text-slate-400">{u?.phone} ({u?.userId})</div>
                      </td>
                      <td className="p-3 font-bold text-slate-200">{tx.method}</td>
                      <td className="p-3 font-extrabold text-amber-400 bg-slate-900/40 px-2 py-1 rounded">
                        {tx.transactionReference}
                      </td>
                      <td className="p-3 font-bold text-emerald-400">৳{tx.amount}</td>
                      <td className="p-3">
                        <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                          tx.status === 'approved' ? 'bg-emerald-500/20 text-emerald-400' : tx.status === 'pending' ? 'bg-amber-500/20 text-amber-400' : 'bg-red-500/20 text-red-400'
                        }`}>
                          {tx.status}
                        </span>
                      </td>
                      <td className="p-3 text-[11px] text-slate-400 font-sans">
                        {new Date(tx.createdAt).toLocaleDateString()} {new Date(tx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="p-3 text-right space-x-1.5 font-sans">
                        {tx.status === 'pending' ? (
                          <>
                            <button
                              onClick={() => handleDepositAction(tx.id, 'approve')}
                              disabled={actionLoadingId === tx.id}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold transition-colors"
                            >
                              Approve & Credit
                            </button>
                            <button
                              onClick={() => handleDepositAction(tx.id, 'reject')}
                              disabled={actionLoadingId === tx.id}
                              className="px-2.5 py-1 bg-red-600/30 hover:bg-red-600/50 text-red-300 border border-red-500/30 rounded text-xs font-bold transition-colors"
                            >
                              Reject
                            </button>
                          </>
                        ) : (
                          <span className="text-[11px] text-slate-500 italic">Action Completed</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. Withdrawals Queue */}
      {activeTab === 'withdrawals' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Withdrawal Processing Queue</h3>
            <span className="text-xs text-slate-400">Dispatch funds via bKash/Nagad/Rocket and mark completed</span>
          </div>

          <div className="overflow-x-auto bg-[#0b1226] border border-slate-800 rounded-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3">Txn ID</th>
                  <th className="p-3">User</th>
                  <th className="p-3">Method</th>
                  <th className="p-3">Target Account</th>
                  <th className="p-3">Amount</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Date</th>
                  <th className="p-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono">
                {withdrawalsList.map((item) => {
                  const tx = item.transaction;
                  const u = item.user;
                  return (
                    <tr key={tx.id} className="hover:bg-slate-900/40">
                      <td className="p-3 font-semibold text-slate-300">{tx.txnId}</td>
                      <td className="p-3 font-sans">
                        <div className="font-bold text-white">{u?.name}</div>
                        <div className="text-[10px] text-slate-400">{u?.phone} ({u?.userId})</div>
                      </td>
                      <td className="p-3 font-bold text-slate-200">{tx.method}</td>
                      <td className="p-3 font-bold text-amber-400">{tx.accountNumber}</td>
                      <td className="p-3 font-bold text-white">৳{tx.amount}</td>
                      <td className="p-3">
                        <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                          tx.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400' : tx.status === 'pending' ? 'bg-purple-500/20 text-purple-400' : 'bg-red-500/20 text-red-400'
                        }`}>
                          {tx.status}
                        </span>
                      </td>
                      <td className="p-3 text-[11px] text-slate-400 font-sans">
                        {new Date(tx.createdAt).toLocaleDateString()}
                      </td>
                      <td className="p-3 text-right space-x-1.5 font-sans">
                        {tx.status === 'pending' ? (
                          <>
                            <button
                              onClick={() => handleWithdrawalAction(tx.id, 'approve')}
                              disabled={actionLoadingId === tx.id}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold transition-colors"
                            >
                              Dispatch & Complete
                            </button>
                            <button
                              onClick={() => handleWithdrawalAction(tx.id, 'reject')}
                              disabled={actionLoadingId === tx.id}
                              className="px-2.5 py-1 bg-red-600/30 hover:bg-red-600/50 text-red-300 border border-red-500/30 rounded text-xs font-bold transition-colors"
                            >
                              Reject & Refund
                            </button>
                          </>
                        ) : (
                          <span className="text-[11px] text-slate-500 italic">Dispatched</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. Payment Gateway Settings */}
      {activeTab === 'payments' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-white">Configurable Payment Gateway Accounts</h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {paymentAccounts.map((acc) => (
              <div key={acc.id} className="p-5 bg-[#0b1226] border border-slate-800 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">{acc.method}</span>
                  <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                    acc.isActive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                  }`}>
                    {acc.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>

                <div className="space-y-1 text-xs">
                  <div className="text-slate-400">
                    Number: <span className="font-mono font-bold text-amber-400">{acc.accountNumber}</span> ({acc.accountType})
                  </div>
                  <div className="text-slate-400">
                    Limits: <span className="font-mono text-slate-200">৳{acc.minDeposit} – ৳{acc.maxDeposit}</span>
                  </div>
                </div>

                <div className="p-2.5 bg-slate-900 rounded border border-slate-800 text-[11px] text-slate-400 line-clamp-3">
                  {acc.instructions}
                </div>

                <button
                  onClick={() => setEditingAccount({ ...acc })}
                  className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs rounded transition-colors"
                >
                  Edit Account Settings
                </button>
              </div>
            ))}
          </div>

          {/* Edit Payment Account Modal */}
          {editingAccount && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
              <div className="bg-[#0b1226] border border-slate-800 rounded-xl p-6 max-w-md w-full space-y-4 shadow-2xl">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white">Edit {editingAccount.method} Settings</h3>
                  <button onClick={() => setEditingAccount(null)} className="text-slate-400 hover:text-white">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={handleSavePaymentAccount} className="space-y-3 text-xs">
                  <div>
                    <label className="text-slate-300 font-semibold block mb-1">Account Number</label>
                    <input
                      type="text"
                      required
                      value={editingAccount.accountNumber}
                      onChange={(e) => setEditingAccount({ ...editingAccount, accountNumber: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 font-semibold block mb-1">Account Type</label>
                    <select
                      value={editingAccount.accountType}
                      onChange={(e) => setEditingAccount({ ...editingAccount, accountType: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white"
                    >
                      <option value="Personal">Personal</option>
                      <option value="Agent">Agent</option>
                      <option value="Merchant">Merchant</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-slate-300 font-semibold block mb-1">Deposit Instructions</label>
                    <textarea
                      rows={3}
                      value={editingAccount.instructions}
                      onChange={(e) => setEditingAccount({ ...editingAccount, instructions: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white"
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-2">
                    <input
                      type="checkbox"
                      id="isActive"
                      checked={editingAccount.isActive}
                      onChange={(e) => setEditingAccount({ ...editingAccount, isActive: e.target.checked })}
                      className="rounded"
                    />
                    <label htmlFor="isActive" className="text-slate-300 font-medium">Gateway is Active</label>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg shadow-md mt-2"
                  >
                    Save Gateway Settings
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 6. Promotional Offers Manager */}
      {activeTab === 'promotions' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-white">Active Promotional Campaigns</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {promotionsList.map((p) => (
              <div key={p.id} className="p-5 bg-[#0b1226] border border-slate-800 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-amber-400 text-xs">CODE: {p.code}</span>
                  <span className="text-xs font-mono text-emerald-400">+{p.bonusPercent}%</span>
                </div>
                <h4 className="font-bold text-white text-sm">{p.title}</h4>
                <div className="text-xs text-slate-400 font-mono">
                  Min: ৳{p.minDeposit} · Max Bonus: ৳{p.maxBonus} · Wagering: {p.wageringRequirement}x
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-2">{p.terms}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 7. Audit & Security Logs */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-white">Financial & Administrative Security Logs</h3>
          <div className="overflow-x-auto bg-[#0b1226] border border-slate-800 rounded-xl">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3">Log ID</th>
                  <th className="p-3">Action</th>
                  <th className="p-3">Target</th>
                  <th className="p-3">Details</th>
                  <th className="p-3">IP Address</th>
                  <th className="p-3">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {auditLogsList.map((l) => (
                  <tr key={l.id} className="hover:bg-slate-900/40">
                    <td className="p-3 text-slate-500">#{l.id}</td>
                    <td className="p-3 font-bold text-amber-400">{l.action}</td>
                    <td className="p-3 text-slate-300">{l.targetType}: {l.targetId}</td>
                    <td className="p-3 text-slate-300 font-sans max-w-xs">{l.details}</td>
                    <td className="p-3 text-slate-500">{l.ipAddress || '127.0.0.1'}</td>
                    <td className="p-3 text-slate-400 text-[11px]">
                      {new Date(l.createdAt).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
