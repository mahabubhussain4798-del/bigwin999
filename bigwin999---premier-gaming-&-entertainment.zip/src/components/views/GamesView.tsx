import React, { useState, useMemo, useRef } from 'react';
import { Search, Play, Filter, Sparkles, AlertCircle, X } from 'lucide-react';
import { GameItem, GAMES_CATALOG, CATEGORIES } from '../../data/games.ts';
import { TRANSLATIONS, Language } from '../../data/translations.ts';

interface GamesViewProps {
  onSelectGame: (game: GameItem) => void;
  lang: Language;
}

const POPULAR_SEARCH_TERMS = [
  'Aviator', 'Tiger', '777', 'Sic Bo', 'Blackjack', 'Roulette', 'Mines', 'Plinko', 'Rocket', 'Dice'
];

export const GamesView: React.FC<GamesViewProps> = ({ onSelectGame, lang }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedVolatility, setSelectedVolatility] = useState<string>('all');
  const inputRef = useRef<HTMLInputElement | null>(null);

  const t = TRANSLATIONS[lang];

  // Quick filter game catalog by title (and optionally category/volatility)
  const filteredGames = useMemo(() => {
    const query = searchTerm.toLowerCase().trim();
    return GAMES_CATALOG.filter((g) => {
      // 1. Title search filter
      if (query && !g.title.toLowerCase().includes(query)) {
        return false;
      }
      // 2. Category filter
      if (selectedCategory !== 'all' && g.category !== selectedCategory) {
        return false;
      }
      // 3. Volatility filter
      if (selectedVolatility !== 'all' && g.volatility !== selectedVolatility) {
        return false;
      }
      return true;
    });
  }, [selectedCategory, selectedVolatility, searchTerm]);

  const clearSearch = () => {
    setSearchTerm('');
    if (inputRef.current) inputRef.current.focus();
  };

  const handleQuickTagClick = (tag: string) => {
    setSearchTerm(tag);
    if (inputRef.current) inputRef.current.focus();
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Title & Stats */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Games Catalog ({GAMES_CATALOG.length})
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Browse our full certified library of airplane crash games, 5-reel video slots, live Sic Bo, and table classics.
          </p>
        </div>

        {/* Dedicated Search Input Bar */}
        <div className="w-full md:w-96 space-y-2">
          <div className="relative">
            <Search className="w-4 h-4 text-amber-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              ref={inputRef}
              type="text"
              placeholder="Search by game title (e.g. Aviator, Tiger 777)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Escape') {
                  clearSearch();
                }
              }}
              className="w-full bg-[#0b1226] border border-slate-700/80 hover:border-slate-600 focus:border-amber-500 rounded-xl pl-9 pr-16 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-amber-500/50 shadow-inner transition-all font-medium"
            />
            {searchTerm ? (
              <div className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
                <button
                  onClick={clearSearch}
                  className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
                  title="Clear search"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
                <span className="text-[10px] text-slate-500 font-mono hidden sm:inline">ESC</span>
              </div>
            ) : (
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-500 font-mono hidden sm:inline">
                Title
              </span>
            )}
          </div>

          {/* Quick search suggestion tags */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            <span className="text-[10px] text-slate-500 font-medium shrink-0">Popular:</span>
            {POPULAR_SEARCH_TERMS.map((term) => (
              <button
                key={term}
                onClick={() => handleQuickTagClick(term)}
                className={`text-[10px] px-2 py-0.5 rounded transition-colors whitespace-nowrap shrink-0 ${
                  searchTerm.toLowerCase() === term.toLowerCase()
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {term}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Category Tabs (Functional segmented filter controls) */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-2">
        {CATEGORIES.map((cat) => {
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-2 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 transition-colors ${
                isActive
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/10'
                  : 'bg-[#0b1226] text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800/80'
              }`}
            >
              {lang === 'bn' ? cat.labelBn : cat.labelEn}
            </button>
          );
        })}
      </div>

      {/* Volatility & Active Search Results Bar */}
      <div className="flex items-center justify-between text-xs text-slate-400 pb-1 border-b border-slate-800/80 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <span>Volatility:</span>
          {['all', 'Low', 'Medium', 'High', 'Extreme', 'Adjustable'].map((v) => (
            <button
              key={v}
              onClick={() => setSelectedVolatility(v)}
              className={`px-2 py-0.5 rounded text-[11px] transition-colors ${
                selectedVolatility === v
                  ? 'bg-slate-700 text-white font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {v === 'all' ? 'All' : v}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          {searchTerm && (
            <div className="flex items-center gap-1 text-[11px] text-amber-400 font-medium">
              <span>Filter: "{searchTerm}"</span>
              <button
                onClick={clearSearch}
                className="text-slate-400 hover:text-white underline ml-1"
              >
                Clear
              </button>
              <span aria-hidden="true" className="text-slate-700">·</span>
            </div>
          )}
          <div className="font-mono text-slate-400">
            Showing <span className="font-bold text-white">{filteredGames.length}</span> games
          </div>
        </div>
      </div>

      {/* Games Catalog Grid */}
      {filteredGames.length === 0 ? (
        <div className="p-12 text-center bg-[#0b1226] border border-slate-800 rounded-xl space-y-3">
          <AlertCircle className="w-8 h-8 text-amber-400 mx-auto" />
          <h3 className="text-sm font-bold text-white">No game titles match "{searchTerm}"</h3>
          <p className="text-xs text-slate-400">
            Try searching for another title like "Aviator", "Tiger", "Sic Bo", "Blackjack", or clear filters.
          </p>
          <div className="flex items-center justify-center gap-2 pt-2">
            <button
              onClick={clearSearch}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition-colors"
            >
              Clear Search
            </button>
            <button
              onClick={() => { setSearchTerm(''); setSelectedCategory('all'); setSelectedVolatility('all'); }}
              className="px-4 py-2 bg-slate-800 text-slate-200 text-xs rounded-lg hover:bg-slate-700 font-semibold"
            >
              Reset All Filters
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3.5">
          {filteredGames.map((game) => (
            <div
              key={game.id}
              className="group bg-[#0b1226] border border-slate-800 hover:border-amber-500/50 rounded-xl overflow-hidden transition-all duration-200 hover:-translate-y-1 shadow-md flex flex-col justify-between"
            >
              {/* Thumbnail */}
              <div className="relative aspect-video w-full bg-slate-900 overflow-hidden">
                {game.imageUrl ? (
                  <img
                    src={game.imageUrl}
                    alt={game.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-900 to-[#070b1a] text-3xl select-none">
                    {game.category === 'crash' ? '✈️' : game.category === 'slots' ? '🎰' : game.category === 'dice' ? '🎲' : '♠️'}
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0b1226] via-transparent to-transparent opacity-80" />

                {/* Badge if available */}
                {game.badge && (
                  <span className="absolute top-2 right-2 text-[9px] font-bold text-amber-300 bg-amber-500/20 border border-amber-500/40 px-1.5 py-0.5 rounded backdrop-blur-sm">
                    {game.badge}
                  </span>
                )}
              </div>

              {/* Info */}
              <div className="p-3 flex-1 flex flex-col justify-between space-y-2">
                <div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-0.5">
                    <span className="truncate max-w-[90px]">{game.provider}</span>
                    <span className="text-emerald-400 font-mono font-medium">{game.rtp}</span>
                  </div>
                  <h3 className="text-xs font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-1">
                    {game.title}
                  </h3>
                </div>

                <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between gap-1">
                  <div className="text-[10px] text-slate-400 font-mono">
                    Max: <span className="text-amber-400 font-semibold">{game.maxMultiplier}</span>
                  </div>
                  <button
                    onClick={() => onSelectGame(game)}
                    className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[11px] rounded active:scale-95 transition-all flex items-center gap-1 shadow-sm"
                  >
                    <Play className="w-2.5 h-2.5 fill-current" />
                    <span>Play</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
