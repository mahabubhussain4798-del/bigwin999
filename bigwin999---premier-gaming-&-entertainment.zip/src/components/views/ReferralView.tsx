import React, { useState, useEffect } from 'react';
import { Users, Copy, Check, Share2, Award, ShieldAlert, Gift, ArrowRight } from 'lucide-react';
import { TRANSLATIONS, Language } from '../../data/translations.ts';

interface ReferralViewProps {
  user: any;
  lang: Language;
}

export const ReferralView: React.FC<ReferralViewProps> = ({ user, lang }) => {
  const [stats, setStats] = useState<any>({
    referralCode: user?.referralCode || 'BW999',
    referralLink: `https://bigwin999.com/register?ref=${user?.referralCode || 'BW999'}`,
    totalInvited: 0,
    activeCount: 0,
    totalEarned: '0.00',
    pendingEarned: '0.00',
    history: [],
  });
  const [copied, setCopied] = useState(false);

  const t = TRANSLATIONS[lang];

  useEffect(() => {
    if (!user) return;
    fetch(`/api/referrals/${user.id}`)
      .then(r => r.json())
      .then(data => {
        if (data.referralCode) setStats(data);
      })
      .catch(console.error);
  }, [user]);

  const copyLink = () => {
    navigator.clipboard.writeText(stats.referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareWhatsApp = () => {
    const text = encodeURIComponent(`Join BIGWIN999 with my referral link and get ৳10,000 demo credits + up to ৳20,000 deposit match! ${stats.referralLink}`);
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const shareTelegram = () => {
    const text = encodeURIComponent(`Play 100+ games on BIGWIN999: ${stats.referralLink}`);
    window.open(`https://t.me/share/url?url=${encodeURIComponent(stats.referralLink)}&text=${text}`, '_blank');
  };

  return (
    <div className="space-y-6 pb-16 max-w-4xl mx-auto">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-lg text-xs font-bold text-amber-400">
          <Gift className="w-3.5 h-3.5" />
          <span>Earn Passive Commission & Bonuses</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
          Refer & Earn with BIGWIN999
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-lg mx-auto">
          Share your referral code with friends. Earn up to ৳100 per active depositing player with transparent tracking.
        </p>
      </div>

      {/* Referral Link & Code Box */}
      <div className="p-6 bg-gradient-to-br from-[#0c1630] to-[#070b1a] border border-amber-500/40 rounded-xl shadow-xl space-y-4">
        <div>
          <label className="text-xs text-slate-400 font-semibold block mb-2">{t.referralLink}</label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={stats.referralLink}
              className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-amber-300 select-all"
            />
            <button
              onClick={copyLink}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg active:scale-95 transition-all flex items-center gap-1.5 shrink-0"
            >
              {copied ? <Check className="w-4 h-4 text-slate-950" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? t.copied : t.copyLink}</span>
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between flex-wrap gap-3 pt-2 border-t border-slate-800">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Your Code:</span>
            <span className="font-mono font-bold text-base text-white px-2 py-0.5 bg-slate-900 border border-slate-700 rounded">
              {stats.referralCode}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={shareWhatsApp}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Share WhatsApp</span>
            </button>
            <button
              onClick={shareTelegram}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Telegram</span>
            </button>
          </div>
        </div>
      </div>

      {/* Referral Statistics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 bg-[#0b1226] border border-slate-800 rounded-xl">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">{t.totalInvited}</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">{stats.totalInvited}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Players Registered</div>
        </div>

        <div className="p-4 bg-[#0b1226] border border-slate-800 rounded-xl">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">{t.activePlayers}</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">{stats.activeCount}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Verified & Qualified</div>
        </div>

        <div className="p-4 bg-[#0b1226] border border-slate-800 rounded-xl">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">{t.totalEarned}</div>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-1">৳{stats.totalEarned}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Credited to Balance</div>
        </div>

        <div className="p-4 bg-[#0b1226] border border-slate-800 rounded-xl">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">Pending Rewards</div>
          <div className="text-2xl font-bold font-mono text-slate-300 mt-1">৳{stats.pendingEarned}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Awaiting Deposit</div>
        </div>
      </div>

      {/* Referrals History Table */}
      <div className="bg-[#0b1226] border border-slate-800 rounded-xl p-5 space-y-3">
        <h3 className="text-sm font-bold text-white">Referral Registration Tracking</h3>
        {stats.history.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-500">
            You haven't referred any players yet. Share your unique link above to start earning rewards!
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-800 rounded-lg overflow-hidden">
              <thead className="bg-slate-900 text-slate-400 text-[10px] uppercase border-b border-slate-800 font-semibold">
                <tr>
                  <th className="p-2.5">User ID</th>
                  <th className="p-2.5">Join Date</th>
                  <th className="p-2.5">Potential Reward</th>
                  <th className="p-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono">
                {stats.history.map((r: any) => (
                  <tr key={r.id} className="hover:bg-slate-900/40">
                    <td className="p-2.5 text-slate-300">User #{r.referredUserId}</td>
                    <td className="p-2.5 text-slate-400">{new Date(r.createdAt).toLocaleDateString()}</td>
                    <td className="p-2.5 font-bold text-amber-400">৳{r.rewardAmount}</td>
                    <td className="p-2.5">
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        r.status === 'rewarded' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                      }`}>
                        {r.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Transparent Campaign Terms & Anti-Fraud Notice */}
      <div className="p-4 bg-slate-900/40 border border-slate-800 rounded-xl flex items-start gap-3 text-xs text-slate-400">
        <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1 leading-relaxed">
          <strong className="text-slate-200">Anti-Fraud & Integrity Terms:</strong>
          <p>
            Referral rewards are activated once the referred user completes identity verification and makes their first qualifying deposit. Self-referrals, multiple accounts, automated bot traffic, or simulated transactions result in immediate disqualification and account forfeiture. We do not advertise unverified cash rewards as guaranteed.
          </p>
        </div>
      </div>
    </div>
  );
};
