import React from 'react';
import { Play, TrendingUp, ShieldCheck, ArrowRight, Sparkles, Zap, Award, Gift, RefreshCw } from 'lucide-react';
import { GameItem, GAMES_CATALOG } from '../../data/games.ts';
import { TRANSLATIONS, Language } from '../../data/translations.ts';

interface HomeViewProps {
  onSelectGame: (game: GameItem) => void;
  onNavigate: (view: string) => void;
  user: any;
  onOpenAuth: (tab: 'login' | 'register') => void;
  lang: Language;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onSelectGame,
  onNavigate,
  user,
  onOpenAuth,
  lang,
}) => {
  const t = TRANSLATIONS[lang];

  // Featured curated spotlight games
  const aviator = GAMES_CATALOG.find(g => g.id === 'aviator-x')!;
  const tigerSlots = GAMES_CATALOG.find(g => g.id === 'golden-tiger-777')!;
  const sicBo = GAMES_CATALOG.find(g => g.id === 'royal-sic-bo')!;
  const blackjack = GAMES_CATALOG.find(g => g.id === 'blackjack-gold-999')!;
  const roulette = GAMES_CATALOG.find(g => g.id === 'roulette-european-gold')!;
  const mines = GAMES_CATALOG.find(g => g.id === 'mines-gold-sweeper')!;

  const spotlightGames = [aviator, tigerSlots, sicBo, blackjack, roulette, mines].filter(Boolean);

  return (
    <div className="space-y-10 pb-16">
      {/* Hero Showcase Section */}
      <section className="relative rounded-2xl overflow-hidden border border-slate-800 bg-[#070d1e] shadow-2xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch min-h-[420px]">
          {/* Text Col */}
          <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-center space-y-6 z-10">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
              <Sparkles className="w-4 h-4" />
              <span>Bangladesh's Premier Verified Gaming Platform</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight [text-wrap:balance]">
              Experience the Thrill of <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500">BIGWIN999</span>
            </h1>

            <p className="text-sm sm:text-base text-slate-300 max-w-xl leading-relaxed">
              Play over 100+ high-RTP crash flights, five-reel jackpot slots, live Sic Bo, and traditional card games. Enjoy instant deposits via bKash, Nagad, and Rocket with verified fair-play technology.
            </p>

            <div className="flex items-center gap-3 flex-wrap pt-2">
              <button
                onClick={() => onSelectGame(aviator)}
                className="px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-extrabold text-xs uppercase tracking-wider rounded-lg shadow-lg shadow-amber-500/20 active:scale-98 transition-all flex items-center gap-2"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Play Aviator X Now</span>
              </button>

              <button
                onClick={() => onNavigate('games')}
                className="px-6 py-3 bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700/80 font-bold text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center gap-1.5"
              >
                <span>Browse 100+ Games</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Quick value indicators */}
            <div className="pt-4 border-t border-slate-800/80 flex items-center gap-6 text-xs text-slate-400 flex-wrap">
              <div>
                <span className="font-bold text-white font-mono">100+</span> Games Catalog
              </div>
              <span aria-hidden="true" className="text-slate-700">·</span>
              <div>
                <span className="font-bold text-emerald-400 font-mono">97.4%</span> Average RTP
              </div>
              <span aria-hidden="true" className="text-slate-700">·</span>
              <div>
                <span className="font-bold text-amber-400 font-mono">24/7</span> Instant bKash/Nagad
              </div>
            </div>
          </div>

          {/* Image Col */}
          <div className="lg:col-span-5 relative min-h-[260px] lg:min-h-full overflow-hidden bg-slate-950">
            <img
              src="/src/assets/images/bigwin_hero_banner_1793024693103.jpg"
              alt="BIGWIN999 luxury gaming table"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center brightness-90 contrast-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#070d1e] via-transparent to-transparent lg:bg-gradient-to-r lg:from-[#070d1e] lg:via-transparent" />
          </div>
        </div>
      </section>

      {/* Promotions Banner Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div
          onClick={() => onNavigate('offers')}
          className="cursor-pointer p-4 rounded-xl bg-gradient-to-br from-[#0c1630] to-[#080d1e] border border-amber-500/30 hover:border-amber-400/60 transition-all shadow-md group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Starter Bonus</span>
            <Gift className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-base font-extrabold text-white">৳100 Deposit — 10% Bonus</div>
          <p className="text-xs text-slate-400 mt-1">Kickstart with instant extra gaming credits.</p>
        </div>

        <div
          onClick={() => onNavigate('offers')}
          className="cursor-pointer p-4 rounded-xl bg-gradient-to-br from-[#12142e] to-[#090b1c] border border-emerald-500/30 hover:border-emerald-400/60 transition-all shadow-md group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Power Boost</span>
            <Zap className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-base font-extrabold text-white">৳300 Deposit — 30% Bonus</div>
          <p className="text-xs text-slate-400 mt-1">Triple excitement with 30% matching credits.</p>
        </div>

        <div
          onClick={() => onNavigate('offers')}
          className="cursor-pointer p-4 rounded-xl bg-gradient-to-br from-[#1d122e] to-[#090714] border border-purple-500/30 hover:border-purple-400/60 transition-all shadow-md group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-purple-400 uppercase tracking-wider">Mega Royal</span>
            <Award className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-base font-extrabold text-white">৳20,000 Deposit — 100% Match</div>
          <p className="text-xs text-slate-400 mt-1">Double your bankroll up to ৳20,000 instantly.</p>
        </div>
      </section>

      {/* Featured Spotlight Games */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">Featured Hot Games</h2>
            <p className="text-xs text-slate-400">Playable demo mode with ৳10,000 reloadable virtual credits</p>
          </div>
          <button
            onClick={() => onNavigate('games')}
            className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1 transition-colors"
          >
            <span>View All (100)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {spotlightGames.map((game) => (
            <div
              key={game.id}
              className="group bg-[#0b1226] border border-slate-800 hover:border-amber-500/50 rounded-xl overflow-hidden transition-all duration-200 hover:-translate-y-0.5 shadow-lg flex flex-col"
            >
              <div className="relative h-40 w-full overflow-hidden bg-slate-900">
                {game.imageUrl ? (
                  <img
                    src={game.imageUrl}
                    alt={game.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-950 text-4xl select-none">
                    {game.category === 'crash' ? '✈️' : game.category === 'slots' ? '🎰' : game.category === 'dice' ? '🎲' : '♠️'}
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0b1226] via-transparent to-transparent" />

                {game.badge && (
                  <span className="absolute top-2.5 right-2.5 text-[10px] font-bold text-amber-300 bg-amber-500/20 border border-amber-500/40 px-2 py-0.5 rounded shadow">
                    {game.badge}
                  </span>
                )}
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                    <span>{game.provider}</span>
                    <span className="text-emerald-400 font-mono font-semibold">RTP {game.rtp}</span>
                  </div>
                  <h3 className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors">
                    {game.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                    {game.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
                  <div className="text-[11px] text-slate-400 font-mono">
                    Min: <span className="text-white font-semibold">৳{game.minBet}</span> · Max: <span className="text-amber-400 font-semibold">{game.maxMultiplier}</span>
                  </div>
                  <button
                    onClick={() => onSelectGame(game)}
                    className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg active:scale-95 transition-all flex items-center gap-1 shadow-sm"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>Play Demo</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Payment Rails Section */}
      <section className="p-6 bg-[#080e1f] border border-slate-800 rounded-xl space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <h3 className="text-base font-bold text-white">Supported Payment Rails in Bangladesh</h3>
            <p className="text-xs text-slate-400">Zero deposit fees with manual verification and complete financial audit log</p>
          </div>
          <button
            onClick={() => onNavigate('wallet')}
            className="text-xs font-bold text-amber-400 hover:text-amber-300"
          >
            Deposit & Withdraw Funds →
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-pink-500/10 border border-pink-500/30 flex items-center justify-center text-pink-400 font-bold text-sm">
              bKash
            </div>
            <div>
              <div className="text-xs font-bold text-white">bKash Send Money</div>
              <div className="text-[11px] text-slate-400">Personal & Agent verification</div>
            </div>
          </div>

          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400 font-bold text-sm">
              Nagad
            </div>
            <div>
              <div className="text-xs font-bold text-white">Nagad Cash In</div>
              <div className="text-[11px] text-slate-400">Instant SMS confirmation</div>
            </div>
          </div>

          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 font-bold text-sm">
              Rocket
            </div>
            <div>
              <div className="text-xs font-bold text-white">Rocket Mobile Banking</div>
              <div className="text-[11px] text-slate-400">12-digit wallet transfers</div>
            </div>
          </div>
        </div>
      </section>

      {/* Compliance & Responsible Gaming footer card */}
      <section className="p-4 bg-slate-900/40 border border-slate-800/80 rounded-xl flex items-start gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <strong className="text-slate-200">Legal Compliance & Fair Play:</strong> BIGWIN999 uses certified pseudo-random number generators (PRNG) for all gameplay outcomes. Demo credits are purely virtual and carry no real monetary obligation. Any conversion to real-money participation is contingent upon jurisdiction approval, age 18+ identity verification, and anti-fraud auditing.
        </div>
      </section>
    </div>
  );
};
