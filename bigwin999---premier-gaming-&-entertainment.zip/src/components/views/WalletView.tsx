import React, { useState, useEffect } from 'react';
import { Wallet, ArrowDownToLine, ArrowUpFromLine, History, Copy, Check, AlertCircle, RefreshCw, ShieldCheck, Sparkles } from 'lucide-react';
import { TRANSLATIONS, Language } from '../../data/translations.ts';
import { useNotifications } from '../../context/NotificationContext.tsx';

interface WalletViewProps {
  user: any;
  onRefreshUser: () => void;
  lang: Language;
}

export const WalletView: React.FC<WalletViewProps> = ({ user, onRefreshUser, lang }) => {
  const { notifyDepositApproved } = useNotifications();
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw' | 'history'>('deposit');
  const [paymentAccounts, setPaymentAccounts] = useState<any[]>([]);
  const [transactionsList, setTransactionsList] = useState<any[]>([]);
  const [selectedMethod, setSelectedMethod] = useState<'bKash' | 'Nagad' | 'Rocket'>('bKash');

  // Deposit form state
  const [depositAmount, setDepositAmount] = useState<string>('500');
  const [depositTrxId, setDepositTrxId] = useState<string>('');
  const [depositSenderPhone, setDepositSenderPhone] = useState<string>('');
  const [depositLoading, setDepositLoading] = useState(false);
  const [simulatingApproval, setSimulatingApproval] = useState(false);
  const [depositMsg, setDepositMsg] = useState<{ text: string; error?: boolean; tx?: any } | null>(null);

  // Withdrawal form state
  const [withdrawAmount, setWithdrawAmount] = useState<string>('500');
  const [withdrawAccount, setWithdrawAccount] = useState<string>('');
  const [withdrawLoading, setWithdrawLoading] = useState(false);
  const [withdrawMsg, setWithdrawMsg] = useState<{ text: string; error?: boolean } | null>(null);

  // Copy helper
  const [copiedAccount, setCopiedAccount] = useState<string | null>(null);

  const t = TRANSLATIONS[lang];

  // Fetch payment accounts
  useEffect(() => {
    fetch('/api/payment-accounts')
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data)) setPaymentAccounts(data);
      })
      .catch(console.error);
  }, []);

  // Fetch user transactions
  const loadTransactions = () => {
    if (!user) return;
    fetch(`/api/wallet/transactions/${user.id}`)
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data)) setTransactionsList(data);
      })
      .catch(console.error);
  };

  useEffect(() => {
    loadTransactions();
  }, [user]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedAccount(text);
    setTimeout(() => setCopiedAccount(null), 2000);
  };

  const currentAccount = paymentAccounts.find(a => a.method === selectedMethod);

  // Reset Demo Balance
  const handleResetDemo = async () => {
    if (!user) return;
    try {
      const res = await fetch('/api/user/reset-demo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id }),
      });
      if (res.ok) {
        onRefreshUser();
        alert('Demo balance restored to ৳10,000.00');
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Submit Deposit
  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      alert('Please log in first to deposit.');
      return;
    }

    setDepositLoading(true);
    setDepositMsg(null);

    try {
      const res = await fetch('/api/wallet/deposit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          method: selectedMethod,
          amount: depositAmount,
          accountNumber: depositSenderPhone || user.phone,
          transactionReference: depositTrxId,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Deposit submission failed');

      setDepositMsg({ text: data.message, tx: data.transaction });
      setDepositTrxId('');
      loadTransactions();
      onRefreshUser();
    } catch (err: any) {
      setDepositMsg({ text: err.message, error: true });
    } finally {
      setDepositLoading(false);
    }
  };

  // Instant simulation of admin approving the submitted deposit
  const handleSimulateApproval = async (tx: any) => {
    if (!tx || !tx.id) return;
    setSimulatingApproval(true);
    try {
      const res = await fetch(`/api/admin/deposits/${tx.id}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'approve',
          adminNote: 'Verified & approved via instant demo sandbox',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to approve deposit');

      // Trigger the Toast notification
      notifyDepositApproved({
        amount: parseFloat(tx.amount),
        method: tx.method,
        transactionReference: tx.transactionReference,
        txnId: tx.txnId,
      });

      setDepositMsg({
        text: `Deposit verified! ৳${parseFloat(tx.amount).toFixed(2)} has been credited to your balance.`,
        error: false,
      });

      onRefreshUser();
      loadTransactions();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSimulatingApproval(false);
    }
  };

  // Submit Withdrawal
  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      alert('Please log in first to withdraw.');
      return;
    }

    setWithdrawLoading(true);
    setWithdrawMsg(null);

    try {
      const res = await fetch('/api/wallet/withdraw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          method: selectedMethod,
          amount: withdrawAmount,
          accountNumber: withdrawAccount,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Withdrawal submission failed');

      setWithdrawMsg({ text: data.message });
      setWithdrawAccount('');
      loadTransactions();
      onRefreshUser();
    } catch (err: any) {
      setWithdrawMsg({ text: err.message, error: true });
    } finally {
      setWithdrawLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-16 max-w-4xl mx-auto">
      {/* Wallet Balance Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Main Balance */}
        <div className="p-5 bg-gradient-to-br from-[#0c1630] to-[#070b1a] border border-amber-500/40 rounded-xl shadow-lg relative overflow-hidden">
          <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>{t.walletBalance}</span>
            <Wallet className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-3xl font-extrabold text-white font-mono">
            ৳{parseFloat(user?.walletBalance || '0').toFixed(2)}
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Real balance available for games or withdrawal</p>
        </div>

        {/* Bonus Balance */}
        <div className="p-5 bg-gradient-to-br from-[#12142e] to-[#080a1c] border border-slate-800 rounded-xl shadow-lg">
          <div className="text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-1">
            {t.bonusBalance}
          </div>
          <div className="text-3xl font-extrabold text-white font-mono">
            ৳{parseFloat(user?.bonusBalance || '0').toFixed(2)}
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Promotional credits subject to turnover rules</p>
        </div>

        {/* Demo Credits */}
        <div className="p-5 bg-gradient-to-br from-[#0a1b2a] to-[#050e17] border border-slate-800 rounded-xl shadow-lg flex flex-col justify-between">
          <div>
            <div className="text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-1 flex items-center justify-between">
              <span>{t.demoBalance}</span>
              <button
                onClick={handleResetDemo}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-normal underline"
                title="Reload to ৳10,000"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Reload</span>
              </button>
            </div>
            <div className="text-3xl font-extrabold text-white font-mono">
              ৳{parseFloat(user?.demoBalance || '10000').toFixed(2)}
            </div>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">Risk-free virtual tokens for demo practice</p>
        </div>
      </div>

      {/* Tabs for Deposit / Withdraw / History */}
      <div className="bg-[#0b1226] border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        <div className="grid grid-cols-3 border-b border-slate-800 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('deposit')}
            className={`py-3.5 flex items-center justify-center gap-1.5 transition-colors ${
              activeTab === 'deposit'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <ArrowDownToLine className="w-4 h-4" />
            <span>{t.deposit}</span>
          </button>

          <button
            onClick={() => setActiveTab('withdraw')}
            className={`py-3.5 flex items-center justify-center gap-1.5 transition-colors ${
              activeTab === 'withdraw'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <ArrowUpFromLine className="w-4 h-4" />
            <span>{t.withdraw}</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`py-3.5 flex items-center justify-center gap-1.5 transition-colors ${
              activeTab === 'history'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Transactions ({transactionsList.length})</span>
          </button>
        </div>

        {/* Deposit Section */}
        {activeTab === 'deposit' && (
          <div className="p-6 space-y-6">
            {/* Payment Method Selector */}
            <div>
              <label className="text-xs text-slate-300 font-bold block mb-2">Select Payment Gateway:</label>
              <div className="grid grid-cols-3 gap-3">
                {(['bKash', 'Nagad', 'Rocket'] as const).map(m => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setSelectedMethod(m)}
                    className={`p-3 rounded-lg border text-center transition-all ${
                      selectedMethod === m
                        ? 'border-amber-400 bg-amber-500/10 text-amber-300 ring-1 ring-amber-400'
                        : 'border-slate-800 bg-slate-900 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-bold text-sm">{m}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Send Money</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Official Payment Account Instructions Box */}
            {currentAccount && (
              <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-lg space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="text-xs text-slate-400">
                    Official <span className="font-bold text-white">{currentAccount.method}</span> ({currentAccount.accountType}) Number:
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-mono font-bold text-amber-400">{currentAccount.accountNumber}</span>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(currentAccount.accountNumber)}
                      className="p-1 text-slate-400 hover:text-white transition-colors"
                      title="Copy Number"
                    >
                      {copiedAccount === currentAccount.accountNumber ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="text-xs text-slate-300 leading-relaxed bg-[#0a1024] p-3 rounded border border-slate-800">
                  <span className="font-semibold text-amber-400 block mb-1">Transfer Instructions:</span>
                  {currentAccount.instructions}
                </div>
              </div>
            )}

            {/* Deposit Request Form */}
            <form onSubmit={handleDepositSubmit} className="space-y-4">
              {depositMsg && (
                <div className={`p-3.5 rounded-xl text-xs space-y-2.5 ${depositMsg.error ? 'bg-red-500/10 border border-red-500/30 text-red-400' : 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'}`}>
                  <div className="leading-relaxed">{depositMsg.text}</div>
                  {depositMsg.tx && (
                    <div className="pt-2 border-t border-emerald-500/20 flex items-center justify-between gap-3 flex-wrap">
                      <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Test notification system:</span>
                      </span>
                      <button
                        type="button"
                        onClick={() => handleSimulateApproval(depositMsg.tx)}
                        disabled={simulatingApproval}
                        className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold transition-all shadow-md flex items-center gap-1.5"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>{simulatingApproval ? 'Approving...' : 'Simulate Instant Admin Approval'}</span>
                      </button>
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-300 font-medium mb-1 block">{t.amountLabel}</label>
                  <input
                    type="number"
                    min={100}
                    max={25000}
                    required
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-500"
                  />
                  <div className="flex items-center gap-1.5 mt-2">
                    {[100, 300, 500, 1000, 2000, 5000].map(amt => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setDepositAmount(amt.toString())}
                        className="text-[10px] px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-mono"
                      >
                        ৳{amt}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs text-slate-300 font-medium mb-1 block">{t.senderPhoneLabel}</label>
                  <input
                    type="tel"
                    required
                    placeholder="01XXXXXXXXX"
                    value={depositSenderPhone}
                    onChange={(e) => setDepositSenderPhone(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-300 font-medium mb-1 block">
                  {t.trxIdLabel} <span className="text-amber-400 font-bold">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 9K7X8M2L (From SMS/App receipt)"
                  value={depositTrxId}
                  onChange={(e) => setDepositTrxId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-white uppercase placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Our financial verification engine checks TrxID records against gateway statements to prevent duplicates.
                </p>
              </div>

              <button
                type="submit"
                disabled={depositLoading}
                className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg shadow-md active:scale-98 transition-all disabled:opacity-50"
              >
                {depositLoading ? 'Verifying submission...' : t.submitDeposit}
              </button>
            </form>
          </div>
        )}

        {/* Withdrawal Section */}
        {activeTab === 'withdraw' && (
          <div className="p-6 space-y-6">
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg text-xs text-amber-300 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                Withdrawals are processed directly to your personal bKash, Nagad, or Rocket account within 15–30 minutes. Minimum withdrawal amount is ৳500.
              </span>
            </div>

            <form onSubmit={handleWithdrawSubmit} className="space-y-4">
              {withdrawMsg && (
                <div className={`p-3 rounded-lg text-xs ${withdrawMsg.error ? 'bg-red-500/10 border border-red-500/30 text-red-400' : 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400'}`}>
                  {withdrawMsg.text}
                </div>
              )}

              <div>
                <label className="text-xs text-slate-300 font-bold block mb-2">Withdrawal Method:</label>
                <div className="grid grid-cols-3 gap-3">
                  {(['bKash', 'Nagad', 'Rocket'] as const).map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setSelectedMethod(m)}
                      className={`p-3 rounded-lg border text-center transition-all ${
                        selectedMethod === m
                          ? 'border-amber-400 bg-amber-500/10 text-amber-300 ring-1 ring-amber-400'
                          : 'border-slate-800 bg-slate-900 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-bold text-sm">{m}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Personal Account</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-300 font-medium mb-1 block">{t.withdrawAmount}</label>
                  <input
                    type="number"
                    min={500}
                    max={50000}
                    required
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-500"
                  />
                  <div className="text-[11px] text-slate-500 mt-1">
                    Available Balance: <span className="text-emerald-400 font-mono font-bold">৳{parseFloat(user?.walletBalance || '0').toFixed(2)}</span>
                  </div>
                </div>

                <div>
                  <label className="text-xs text-slate-300 font-medium mb-1 block">{t.recipientNumber}</label>
                  <input
                    type="tel"
                    required
                    placeholder="01XXXXXXXXX"
                    value={withdrawAccount}
                    onChange={(e) => setWithdrawAccount(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={withdrawLoading}
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-emerald-400 hover:from-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg shadow-md active:scale-98 transition-all disabled:opacity-50"
              >
                {withdrawLoading ? 'Submitting request...' : t.submitWithdraw}
              </button>
            </form>
          </div>
        )}

        {/* Transactions History Section */}
        {activeTab === 'history' && (
          <div className="p-4 sm:p-6 space-y-3">
            {transactionsList.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs">
                No transactions found. Deposit funds or claim offers to start playing.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border border-slate-800 rounded-lg overflow-hidden">
                  <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] font-semibold border-b border-slate-800">
                    <tr>
                      <th className="p-3">Txn ID</th>
                      <th className="p-3">Type</th>
                      <th className="p-3">Method</th>
                      <th className="p-3">Amount</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 font-mono">
                    {transactionsList.map((tx) => (
                      <tr key={tx.id} className="hover:bg-slate-900/40">
                        <td className="p-3 font-semibold text-slate-300">{tx.txnId}</td>
                        <td className="p-3 capitalize font-sans">{tx.type}</td>
                        <td className="p-3">{tx.method}</td>
                        <td className={`p-3 font-bold ${tx.type === 'deposit' || tx.type === 'win' || tx.type === 'bonus' ? 'text-emerald-400' : 'text-slate-300'}`}>
                          {tx.type === 'deposit' || tx.type === 'win' || tx.type === 'bonus' ? '+' : '-'}৳{tx.amount}
                        </td>
                        <td className="p-3">
                          <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                            tx.status === 'approved' || tx.status === 'completed'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : tx.status === 'pending'
                              ? 'bg-amber-500/20 text-amber-400'
                              : 'bg-red-500/20 text-red-400'
                          }`}>
                            {tx.status}
                          </span>
                        </td>
                        <td className="p-3 text-[11px] text-slate-400">
                          {new Date(tx.createdAt).toLocaleDateString()} {new Date(tx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
