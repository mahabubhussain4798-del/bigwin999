import React, { useState } from 'react';
import { RotateCw, Sparkles, Volume2, VolumeX, Award, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sound } from '../../utils/audio.ts';

interface SlotGameProps {
  userBalance: number;
  demoBalance: number;
  mode: 'demo' | 'real';
  onRecordRound: (bet: number, payout: number, mult: number, summary: string) => Promise<void>;
}

// Reel symbols
const SYMBOLS = [
  { id: '777', label: '777', color: 'text-amber-400', weight: 1, mult: 50 },
  { id: 'tiger', label: '🐅', color: 'text-orange-400', weight: 2, mult: 25 }, // Wild
  { id: 'diamond', label: '💎', color: 'text-cyan-400', weight: 3, mult: 15 }, // Scatter
  { id: 'crown', label: '👑', color: 'text-yellow-400', weight: 4, mult: 10 },
  { id: 'bell', label: '🔔', color: 'text-amber-300', weight: 5, mult: 8 },
  { id: 'cherry', label: '🍒', color: 'text-red-400', weight: 6, mult: 5 },
  { id: 'coin', label: '🪙', color: 'text-yellow-500', weight: 7, mult: 3 },
];

export const SlotMachineGame: React.FC<SlotGameProps> = ({
  userBalance,
  demoBalance,
  mode,
  onRecordRound,
}) => {
  const [spinning, setSpinning] = useState(false);
  const [betAmount, setBetAmount] = useState<number>(50);
  const [reels, setReels] = useState<string[][]>([
    ['777', 'crown', 'bell'],
    ['tiger', 'diamond', 'coin'],
    ['777', '777', '777'],
    ['crown', 'tiger', 'cherry'],
    ['bell', 'coin', 'diamond'],
  ]);
  const [winResult, setWinResult] = useState<{ amount: number; lines: string[] } | null>(null);
  const [autoSpin, setAutoSpin] = useState(false);

  const currentAvailableBalance = mode === 'real' ? userBalance : demoBalance;

  // Pick random symbol based on weighted probability
  const getRandomSymbol = () => {
    const total = SYMBOLS.reduce((sum, s) => sum + s.weight, 0);
    let rand = Math.random() * total;
    for (const s of SYMBOLS) {
      if (rand < s.weight) return s.label;
      rand -= s.weight;
    }
    return '🍒';
  };

  const handleSpin = async () => {
    if (spinning) return;
    if (betAmount > currentAvailableBalance) {
      alert('Insufficient balance for this spin.');
      return;
    }

    setSpinning(true);
    setWinResult(null);
    sound.tick();

    // Generate outcome
    const newReels: string[][] = [
      [getRandomSymbol(), getRandomSymbol(), getRandomSymbol()],
      [getRandomSymbol(), getRandomSymbol(), getRandomSymbol()],
      [getRandomSymbol(), getRandomSymbol(), getRandomSymbol()],
      [getRandomSymbol(), getRandomSymbol(), getRandomSymbol()],
      [getRandomSymbol(), getRandomSymbol(), getRandomSymbol()],
    ];

    // Artificial spin delay
    setTimeout(async () => {
      setReels(newReels);
      setSpinning(false);

      // Check center payline (Row 1 across 5 reels)
      const centerRow = newReels.map(r => r[1]);
      let matchCount = 1;
      const firstSym = centerRow[0];

      for (let i = 1; i < 5; i++) {
        if (centerRow[i] === firstSym || centerRow[i] === '🐅') {
          matchCount++;
        } else {
          break;
        }
      }

      // Check Top & Bottom Rows
      const topRow = newReels.map(r => r[0]);
      const botRow = newReels.map(r => r[2]);

      let totalMultiplier = 0;
      const winningLines: string[] = [];

      if (matchCount >= 3) {
        const symDef = SYMBOLS.find(s => s.label === firstSym) || SYMBOLS[5];
        const mult = matchCount === 5 ? symDef.mult * 3 : matchCount === 4 ? symDef.mult * 1.5 : symDef.mult;
        totalMultiplier += mult;
        winningLines.push(`Center Line: ${matchCount}x ${firstSym} (${mult}x)`);
      }

      // 3 matching diamonds anywhere = Scatter bonus 10x
      const diamondCount = newReels.flat().filter(s => s === '💎').length;
      if (diamondCount >= 3) {
        totalMultiplier += 10;
        winningLines.push(`Diamond Scatter: ${diamondCount} Gems (+10x)`);
      }

      const payout = Math.floor(betAmount * totalMultiplier * 100) / 100;

      if (payout > 0) {
        setWinResult({ amount: payout, lines: winningLines });
        if (totalMultiplier >= 15) {
          sound.bigWin();
          confetti({ particleCount: 70, spread: 80, origin: { y: 0.6 } });
        } else {
          sound.win();
        }
      }

      await onRecordRound(
        betAmount,
        payout,
        totalMultiplier,
        payout > 0 ? `Won ৳${payout.toFixed(2)} on ${winningLines.join(', ')}` : 'Spin completed (No win)'
      );
    }, 700);
  };

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      {/* Header bar */}
      <div className="px-4 py-2.5 bg-[#070d1e] border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-semibold text-slate-200">Golden Tiger 777 Deluxe</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>{mode === 'real' ? 'Real Balance' : 'Demo Credits'}</span>
        </div>
      </div>

      {/* 5-Reel Showcase Display */}
      <div className="p-4 sm:p-6 bg-gradient-to-b from-[#0e1730] to-[#080d1e]">
        <div className="grid grid-cols-5 gap-2 sm:gap-3 max-w-xl mx-auto bg-slate-950/80 p-3 sm:p-4 rounded-xl border border-amber-500/30 shadow-[0_0_30px_rgba(245,158,11,0.1)]">
          {reels.map((col, colIdx) => (
            <div
              key={colIdx}
              className={`flex flex-col gap-2 rounded-lg p-2 bg-[#0d162d] border border-slate-800 text-center transition-all ${
                spinning ? 'blur-[1px] opacity-80 translate-y-1' : ''
              }`}
            >
              {col.map((sym, rowIdx) => (
                <div
                  key={rowIdx}
                  className={`h-14 sm:h-16 flex items-center justify-center rounded text-2xl sm:text-3xl font-bold select-none ${
                    rowIdx === 1
                      ? 'bg-amber-500/10 border border-amber-500/40 text-amber-300 shadow-inner'
                      : 'bg-slate-900/60 text-slate-200'
                  }`}
                >
                  {sym}
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* Win Alert Banner */}
        {winResult && (
          <div className="mt-4 max-w-xl mx-auto p-3 bg-emerald-500/15 border border-emerald-500/40 rounded-lg text-center animate-bounce">
            <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">Winner!</span>
            <span className="text-2xl font-extrabold font-mono text-emerald-300">
              +৳{winResult.amount.toFixed(2)}
            </span>
            <span className="text-xs text-slate-300 block mt-0.5">{winResult.lines.join(' | ')}</span>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="p-4 bg-[#080e1f] border-t border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
        {/* Bet value controls */}
        <div className="sm:col-span-2 space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Bet / Spin:</span>
            <div className="relative flex-1">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-xs font-bold">৳</span>
              <input
                type="number"
                min={10}
                max={5000}
                value={betAmount}
                disabled={spinning}
                onChange={(e) => setBetAmount(Math.max(10, parseInt(e.target.value, 10) || 10))}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-7 pr-3 py-2 text-sm font-mono text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            {[10, 25, 50, 100, 250, 500, 1000].map(val => (
              <button
                key={val}
                onClick={() => setBetAmount(val)}
                disabled={spinning}
                className={`text-xs px-2.5 py-1 rounded transition-colors ${
                  betAmount === val
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                }`}
              >
                ৳{val}
              </button>
            ))}
          </div>
        </div>

        {/* Spin Button */}
        <div>
          <button
            onClick={handleSpin}
            disabled={spinning}
            className="w-full py-4 bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-extrabold text-base rounded-lg shadow-lg shadow-amber-500/20 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            <RotateCw className={`w-5 h-5 ${spinning ? 'animate-spin' : ''}`} />
            <span>{spinning ? 'SPINNING...' : 'SPIN REELS'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
