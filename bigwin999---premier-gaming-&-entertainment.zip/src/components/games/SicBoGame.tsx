import React, { useState } from 'react';
import { Dices, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sound } from '../../utils/audio.ts';

interface SicBoGameProps {
  userBalance: number;
  demoBalance: number;
  mode: 'demo' | 'real';
  onRecordRound: (bet: number, payout: number, mult: number, summary: string) => Promise<void>;
}

export const SicBoGame: React.FC<SicBoGameProps> = ({
  userBalance,
  demoBalance,
  mode,
  onRecordRound,
}) => {
  const [dice, setDice] = useState<number[]>([4, 5, 6]);
  const [rolling, setRolling] = useState(false);
  const [chipValue, setChipValue] = useState<number>(50);
  const [selectedBets, setSelectedBets] = useState<{ [key: string]: number }>({});
  const [lastWin, setLastWin] = useState<number | null>(null);

  const currentAvailableBalance = mode === 'real' ? userBalance : demoBalance;
  const totalBet = Object.values(selectedBets).reduce((sum, b) => sum + b, 0);

  const toggleBet = (betKey: string) => {
    sound.chip();
    setSelectedBets(prev => {
      const cur = prev[betKey] || 0;
      return { ...prev, [betKey]: cur + chipValue };
    });
  };

  const clearBets = () => {
    sound.chip();
    setSelectedBets({});
  };

  const handleRoll = async () => {
    if (totalBet <= 0) {
      alert('Please place chips on at least one betting area.');
      return;
    }
    if (totalBet > currentAvailableBalance) {
      alert('Insufficient balance for total bets placed.');
      return;
    }

    setRolling(true);
    setLastWin(null);
    sound.tick();

    setTimeout(async () => {
      const d1 = Math.floor(Math.random() * 6) + 1;
      const d2 = Math.floor(Math.random() * 6) + 1;
      const d3 = Math.floor(Math.random() * 6) + 1;
      const newDice = [d1, d2, d3];
      const sum = d1 + d2 + d3;
      const isTriple = d1 === d2 && d2 === d3;

      setDice(newDice);
      setRolling(false);

      let totalPayout = 0;
      const wonAreas: string[] = [];

      // Small (4-10, loses on triples)
      if (selectedBets['small'] && sum >= 4 && sum <= 10 && !isTriple) {
        const p = selectedBets['small'] * 2;
        totalPayout += p;
        wonAreas.push('Small (1:1)');
      }

      // Big (11-17, loses on triples)
      if (selectedBets['big'] && sum >= 11 && sum <= 17 && !isTriple) {
        const p = selectedBets['big'] * 2;
        totalPayout += p;
        wonAreas.push('Big (1:1)');
      }

      // Any Triple (30:1)
      if (selectedBets['any_triple'] && isTriple) {
        const p = selectedBets['any_triple'] * 31;
        totalPayout += p;
        wonAreas.push('Any Triple (30:1)');
      }

      // Specific sum bets
      const sumKey = `sum_${sum}`;
      if (selectedBets[sumKey]) {
        const mult = (sum === 4 || sum === 17) ? 60 : (sum === 5 || sum === 16) ? 30 : (sum === 6 || sum === 15) ? 18 : 12;
        const p = selectedBets[sumKey] * (mult + 1);
        totalPayout += p;
        wonAreas.push(`Sum ${sum} (${mult}:1)`);
      }

      setLastWin(totalPayout);

      if (totalPayout > 0) {
        sound.win();
        if (totalPayout >= totalBet * 3) {
          confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
        }
      } else {
        sound.crash();
      }

      await onRecordRound(
        totalBet,
        totalPayout,
        totalPayout > 0 ? (totalPayout / totalBet) : 0,
        `Dice: [${d1}, ${d2}, ${d3}] Sum ${sum}. ${totalPayout > 0 ? `Won ৳${totalPayout.toFixed(2)} on ${wonAreas.join(', ')}` : 'No win'}`
      );
    }, 800);
  };

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      <div className="px-4 py-2.5 bg-[#070d1e] border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Dices className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-semibold text-slate-200">Royal Sic Bo Gold</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>{mode === 'real' ? 'Real Balance' : 'Demo Credits'}</span>
        </div>
      </div>

      <div className="p-4 sm:p-6 bg-gradient-to-b from-[#0e1730] to-[#080d1e] text-center">
        <div className="flex items-center justify-center gap-4 py-4">
          {dice.map((val, idx) => (
            <div
              key={idx}
              className={`w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gradient-to-br from-red-600 to-red-800 text-white font-extrabold text-2xl sm:text-3xl flex items-center justify-center shadow-lg border-2 border-amber-400/60 transform transition-all select-none ${
                rolling ? 'animate-bounce' : 'shadow-[0_4px_15px_rgba(239,68,68,0.4)]'
              }`}
            >
              {val}
            </div>
          ))}
        </div>
        <div className="text-sm font-mono text-slate-300">
          Total Sum: <span className="font-bold text-amber-400">{dice[0] + dice[1] + dice[2]}</span>
        </div>

        {lastWin !== null && (
          <div className="mt-2 text-xs font-bold">
            {lastWin > 0 ? (
              <span className="text-emerald-400">Won Payout: +৳{lastWin.toFixed(2)}</span>
            ) : (
              <span className="text-slate-400">No win on this roll</span>
            )}
          </div>
        )}
      </div>

      <div className="p-4 bg-[#080e1f] border-t border-slate-800 space-y-3">
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => toggleBet('small')}
            className={`p-3 rounded-lg border text-center transition-all ${
              selectedBets['small']
                ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-sm'
                : 'bg-slate-900 border-slate-700/80 hover:border-slate-600 text-slate-200'
            }`}
          >
            <div className="text-xs font-bold uppercase">Small (4–10)</div>
            <div className="text-[11px] text-slate-400">Pays 1:1</div>
            {selectedBets['small'] && (
              <div className="mt-1 text-xs font-mono font-bold text-amber-400">
                ৳{selectedBets['small']}
              </div>
            )}
          </button>

          <button
            onClick={() => toggleBet('any_triple')}
            className={`p-3 rounded-lg border text-center transition-all ${
              selectedBets['any_triple']
                ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-sm'
                : 'bg-slate-900 border-slate-700/80 hover:border-slate-600 text-slate-200'
            }`}
          >
            <div className="text-xs font-bold uppercase text-amber-400">Any Triple</div>
            <div className="text-[11px] text-slate-400">Pays 30:1</div>
            {selectedBets['any_triple'] && (
              <div className="mt-1 text-xs font-mono font-bold text-amber-400">
                ৳{selectedBets['any_triple']}
              </div>
            )}
          </button>

          <button
            onClick={() => toggleBet('big')}
            className={`p-3 rounded-lg border text-center transition-all ${
              selectedBets['big']
                ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-sm'
                : 'bg-slate-900 border-slate-700/80 hover:border-slate-600 text-slate-200'
            }`}
          >
            <div className="text-xs font-bold uppercase">Big (11–17)</div>
            <div className="text-[11px] text-slate-400">Pays 1:1</div>
            {selectedBets['big'] && (
              <div className="mt-1 text-xs font-mono font-bold text-amber-400">
                ৳{selectedBets['big']}
              </div>
            )}
          </button>
        </div>

        <div>
          <div className="text-[11px] text-slate-400 mb-1 font-medium">Specific Sum Bets:</div>
          <div className="grid grid-cols-7 gap-1">
            {[4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17].map(s => {
              const k = `sum_${s}`;
              return (
                <button
                  key={s}
                  onClick={() => toggleBet(k)}
                  className={`p-1.5 rounded text-center border text-xs font-mono transition-all ${
                    selectedBets[k]
                      ? 'bg-amber-500/30 border-amber-500 text-amber-300'
                      : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <span className="font-bold">{s}</span>
                  {selectedBets[k] && <div className="text-[10px] text-amber-400 font-bold">৳{selectedBets[k]}</div>}
                </button>
              );
            })}
          </div>
        </div>

        <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-slate-400">Chip:</span>
            {[10, 50, 100, 500, 1000].map(c => (
              <button
                key={c}
                onClick={() => setChipValue(c)}
                className={`w-8 h-8 rounded-full text-xs font-mono font-bold flex items-center justify-center transition-all ${
                  chipValue === c
                    ? 'bg-amber-500 text-slate-950 scale-105 shadow-md'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {c}
              </button>
            ))}
            <button
              onClick={clearBets}
              className="text-xs px-2 py-1 text-slate-400 hover:text-red-400 ml-2"
            >
              Clear
            </button>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-slate-300">
              Total: <span className="text-amber-400 font-bold">৳{totalBet}</span>
            </span>
            <button
              onClick={handleRoll}
              disabled={rolling || totalBet === 0}
              className="px-6 py-2.5 bg-gradient-to-r from-red-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-extrabold text-xs tracking-wider uppercase rounded-lg shadow-md transition-all active:scale-98 disabled:opacity-50"
            >
              {rolling ? 'SHAKING...' : 'ROLL DICE'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
