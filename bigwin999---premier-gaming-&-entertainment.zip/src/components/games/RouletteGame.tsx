import React, { useState, useRef, useEffect } from 'react';
import { Circle, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sound } from '../../utils/audio.ts';

// European numbers order on the cylinder
const WHEEL_NUMBERS = [
  0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10,
  5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26
];

const RED_NUMBERS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];

interface RouletteGameProps {
  userBalance: number;
  demoBalance: number;
  mode: 'demo' | 'real';
  onRecordRound: (bet: number, payout: number, mult: number, summary: string) => Promise<void>;
}

export const RouletteGame: React.FC<RouletteGameProps> = ({
  userBalance,
  demoBalance,
  mode,
  onRecordRound,
}) => {
  const [spinning, setSpinning] = useState(false);
  const [chip, setChip] = useState<number>(50);
  const [bets, setBets] = useState<{ [key: string]: number }>({});
  const [winningNumber, setWinningNumber] = useState<number | null>(null);
  const [rotationAngle, setRotationAngle] = useState<number>(0);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const currentAvailableBalance = mode === 'real' ? userBalance : demoBalance;
  const totalBet = Object.values(bets).reduce((a, b) => a + b, 0);

  const placeBet = (area: string) => {
    sound.chip();
    setBets(prev => ({ ...prev, [area]: (prev[area] || 0) + chip }));
  };

  const clearBets = () => {
    sound.chip();
    setBets({});
  };

  const spinWheel = async () => {
    if (totalBet <= 0) {
      alert('Please place chips on the table first.');
      return;
    }
    if (totalBet > currentAvailableBalance) {
      alert('Insufficient balance.');
      return;
    }

    setSpinning(true);
    setWinningNumber(null);
    sound.tick();

    const landedNum = WHEEL_NUMBERS[Math.floor(Math.random() * WHEEL_NUMBERS.length)];
    const numIdx = WHEEL_NUMBERS.indexOf(landedNum);
    const sliceRad = (2 * Math.PI) / WHEEL_NUMBERS.length;
    const targetAngle = 5 * 2 * Math.PI + (numIdx * sliceRad);

    const startTime = performance.now();
    const duration = 2400;

    const animateWheel = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / duration);
      // easeOutCubic
      const ease = 1 - Math.pow(1 - progress, 3);
      setRotationAngle(targetAngle * ease);

      if (progress < 1) {
        requestAnimationFrame(animateWheel);
      } else {
        setSpinning(false);
        setWinningNumber(landedNum);

        // Calculate payout
        let wonPayout = 0;
        const wins: string[] = [];

        // Red / Black
        const isRed = RED_NUMBERS.includes(landedNum);
        if (bets['red'] && isRed && landedNum !== 0) {
          wonPayout += bets['red'] * 2;
          wins.push('Red (1:1)');
        }
        if (bets['black'] && !isRed && landedNum !== 0) {
          wonPayout += bets['black'] * 2;
          wins.push('Black (1:1)');
        }

        // Even / Odd
        if (bets['even'] && landedNum % 2 === 0 && landedNum !== 0) {
          wonPayout += bets['even'] * 2;
          wins.push('Even (1:1)');
        }
        if (bets['odd'] && landedNum % 2 === 1 && landedNum !== 0) {
          wonPayout += bets['odd'] * 2;
          wins.push('Odd (1:1)');
        }

        // Straight number
        const straightKey = `num_${landedNum}`;
        if (bets[straightKey]) {
          wonPayout += bets[straightKey] * 36;
          wins.push(`Number ${landedNum} (35:1)`);
        }

        if (wonPayout > 0) {
          sound.win();
          confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
        } else {
          sound.crash();
        }

        onRecordRound(
          totalBet,
          wonPayout,
          wonPayout > 0 ? (wonPayout / totalBet) : 0,
          `Landed on ${landedNum} (${landedNum === 0 ? 'Green' : isRed ? 'Red' : 'Black'}). ${wonPayout > 0 ? `Won ৳${wonPayout.toFixed(2)} on ${wins.join(', ')}` : 'No win'}`
        );
      }
    };

    requestAnimationFrame(animateWheel);
  };

  // Render canvas wheel
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    const cx = w / 2;
    const cy = h / 2;
    const radius = Math.min(cx, cy) - 10;

    ctx.clearRect(0, 0, w, h);

    // Save and rotate
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(rotationAngle);

    const sliceAngle = (2 * Math.PI) / WHEEL_NUMBERS.length;

    WHEEL_NUMBERS.forEach((num, i) => {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, radius, i * sliceAngle, (i + 1) * sliceAngle);
      ctx.closePath();

      if (num === 0) {
        ctx.fillStyle = '#059669'; // Green 0
      } else if (RED_NUMBERS.includes(num)) {
        ctx.fillStyle = '#DC2626'; // Red
      } else {
        ctx.fillStyle = '#1E293B'; // Black/Dark
      }
      ctx.fill();
      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Number text
      ctx.save();
      ctx.rotate(i * sliceAngle + sliceAngle / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 9px monospace';
      ctx.fillText(num.toString(), radius - 8, 3);
      ctx.restore();
    });

    // Center hub
    ctx.beginPath();
    ctx.arc(0, 0, radius * 0.35, 0, 2 * Math.PI);
    ctx.fillStyle = '#D97706';
    ctx.fill();
    ctx.strokeStyle = '#FBBF24';
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.restore();

    // Top stationary indicator pin
    ctx.fillStyle = '#F59E0B';
    ctx.beginPath();
    ctx.moveTo(cx, 4);
    ctx.lineTo(cx - 6, 18);
    ctx.lineTo(cx + 6, 18);
    ctx.closePath();
    ctx.fill();
  }, [rotationAngle]);

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      <div className="px-4 py-2.5 bg-[#070d1e] border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Circle className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-semibold text-slate-200">European Roulette Gold</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>{mode === 'real' ? 'Real Balance' : 'Demo Credits'}</span>
        </div>
      </div>

      <div className="p-4 sm:p-6 bg-gradient-to-b from-[#0e1730] to-[#080d1e] grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        {/* Wheel view */}
        <div className="flex flex-col items-center">
          <canvas
            ref={canvasRef}
            width={240}
            height={240}
            className="w-56 h-56 rounded-full shadow-2xl border-4 border-amber-500/40"
          />
          {winningNumber !== null && (
            <div className="mt-3 text-center">
              <span className="text-xs text-slate-400">Winning Pocket:</span>
              <div className={`text-2xl font-bold font-mono ${winningNumber === 0 ? 'text-emerald-400' : RED_NUMBERS.includes(winningNumber) ? 'text-red-400' : 'text-slate-200'}`}>
                {winningNumber} ({winningNumber === 0 ? 'Zero' : RED_NUMBERS.includes(winningNumber) ? 'Red' : 'Black'})
              </div>
            </div>
          )}
        </div>

        {/* Betting layout */}
        <div className="space-y-3">
          <div className="grid grid-cols-4 gap-2">
            <button
              onClick={() => placeBet('red')}
              className={`p-2.5 rounded border text-xs font-bold transition-all ${
                bets['red'] ? 'border-amber-400 shadow-md ring-1 ring-amber-400' : 'border-red-600/60'
              } bg-red-600 text-white`}
            >
              RED (1:1)
              {bets['red'] && <div className="text-[10px] text-amber-300">৳{bets['red']}</div>}
            </button>
            <button
              onClick={() => placeBet('black')}
              className={`p-2.5 rounded border text-xs font-bold transition-all ${
                bets['black'] ? 'border-amber-400 shadow-md ring-1 ring-amber-400' : 'border-slate-700'
              } bg-slate-900 text-white`}
            >
              BLACK (1:1)
              {bets['black'] && <div className="text-[10px] text-amber-300">৳{bets['black']}</div>}
            </button>
            <button
              onClick={() => placeBet('even')}
              className={`p-2.5 rounded border text-xs font-bold transition-all ${
                bets['even'] ? 'border-amber-400 ring-1 ring-amber-400' : 'border-slate-800'
              } bg-slate-800 text-slate-200`}
            >
              EVEN (1:1)
              {bets['even'] && <div className="text-[10px] text-amber-300">৳{bets['even']}</div>}
            </button>
            <button
              onClick={() => placeBet('odd')}
              className={`p-2.5 rounded border text-xs font-bold transition-all ${
                bets['odd'] ? 'border-amber-400 ring-1 ring-amber-400' : 'border-slate-800'
              } bg-slate-800 text-slate-200`}
            >
              ODD (1:1)
              {bets['odd'] && <div className="text-[10px] text-amber-300">৳{bets['odd']}</div>}
            </button>
          </div>

          <div>
            <div className="text-[11px] text-slate-400 mb-1">Straight Up Numbers (35:1):</div>
            <div className="grid grid-cols-6 gap-1 max-h-32 overflow-y-auto p-1 bg-slate-950/60 rounded border border-slate-800">
              {WHEEL_NUMBERS.map(n => {
                const k = `num_${n}`;
                const isR = RED_NUMBERS.includes(n);
                return (
                  <button
                    key={n}
                    onClick={() => placeBet(k)}
                    className={`p-1 rounded text-center text-xs font-mono font-bold border transition-all ${
                      bets[k]
                        ? 'border-amber-400 bg-amber-500/30 text-amber-300'
                        : n === 0
                        ? 'bg-emerald-700 border-emerald-600 text-white'
                        : isR
                        ? 'bg-red-700/80 border-red-600 text-white'
                        : 'bg-slate-800 border-slate-700 text-slate-200'
                    }`}
                  >
                    {n}
                    {bets[k] && <div className="text-[9px] text-amber-400">৳{bets[k]}</div>}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Control row */}
      <div className="p-4 bg-[#080e1f] border-t border-slate-800 flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-slate-400">Chip:</span>
          {[10, 50, 100, 500].map(c => (
            <button
              key={c}
              onClick={() => setChip(c)}
              className={`w-7 h-7 rounded-full text-xs font-mono font-bold flex items-center justify-center ${
                chip === c ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
              }`}
            >
              {c}
            </button>
          ))}
          <button onClick={clearBets} className="text-xs text-slate-400 hover:text-red-400 ml-2">Clear</button>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-slate-300">
            Total Bet: <span className="text-amber-400 font-bold">৳{totalBet}</span>
          </span>
          <button
            onClick={spinWheel}
            disabled={spinning || totalBet === 0}
            className="px-6 py-2.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-extrabold text-xs uppercase tracking-wider rounded-lg shadow-md disabled:opacity-50"
          >
            {spinning ? 'SPINNING...' : 'SPIN WHEEL'}
          </button>
        </div>
      </div>
    </div>
  );
};
