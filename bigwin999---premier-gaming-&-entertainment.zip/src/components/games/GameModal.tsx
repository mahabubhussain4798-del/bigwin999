import React, { useState } from 'react';
import { X, Play, ShieldAlert, Info, History, ShieldCheck } from 'lucide-react';
import { GameItem } from '../../data/games.ts';
import { useNotifications } from '../../context/NotificationContext.tsx';
import { AviatorGame } from './AviatorGame.tsx';
import { SlotMachineGame } from './SlotMachineGame.tsx';
import { SicBoGame } from './SicBoGame.tsx';
import { BlackjackGame } from './BlackjackGame.tsx';
import { RouletteGame } from './RouletteGame.tsx';
import { MinesGame } from './MinesGame.tsx';

interface GameModalProps {
  game: GameItem;
  user: any;
  onClose: () => void;
  onRefreshBalances: () => void;
  lang: 'en' | 'bn';
}

export const GameModal: React.FC<GameModalProps> = ({
  game,
  user,
  onClose,
  onRefreshBalances,
  lang,
}) => {
  const { notifyBetSettled } = useNotifications();
  const [mode, setMode] = useState<'demo' | 'real'>('demo');
  const [activeTab, setActiveTab] = useState<'play' | 'rules' | 'history'>('play');
  const [roundLogs, setRoundLogs] = useState<any[]>([]);

  const handleRecordRound = async (bet: number, payout: number, mult: number, summary: string) => {
    // Trigger toast notification on bet settlement
    notifyBetSettled({
      gameTitle: game.title,
      betAmount: bet,
      payoutAmount: payout,
      multiplier: mult,
      summary,
      mode,
    });

    if (!user) return;
    try {
      const res = await fetch('/api/games/record-round', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          gameId: game.id,
          mode,
          betAmount: bet,
          payoutAmount: payout,
          multiplier: mult,
          resultSummary: summary,
        }),
      });
      const data = await res.json();
      if (data.round) {
        setRoundLogs(prev => [data.round, ...prev.slice(0, 9)]);
      }
      onRefreshBalances();
    } catch (err) {
      console.error('Error recording round:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-[#0a1024] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Modal Header */}
        <div className="p-4 bg-[#070b1a] border-b border-slate-800/80 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold">
              {game.category === 'crash' ? '✈️' : game.category === 'slots' ? '🎰' : game.category === 'dice' ? '🎲' : '♠️'}
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
                {game.title}
                {game.badge && (
                  <span className="text-[10px] font-semibold text-amber-400 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded">
                    {game.badge}
                  </span>
                )}
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span>{game.provider}</span>
                <span aria-hidden="true">·</span>
                <span>RTP: {game.rtp}</span>
                <span aria-hidden="true">·</span>
                <span>Max: {game.maxMultiplier}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Mode switch */}
            <div className="flex items-center p-1 bg-slate-900 border border-slate-800 rounded-lg text-xs font-medium">
              <button
                onClick={() => setMode('demo')}
                className={`px-3 py-1 rounded transition-colors ${
                  mode === 'demo' ? 'bg-amber-500 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                Demo (৳10K)
              </button>
              <button
                onClick={() => {
                  if (!user) {
                    alert('Please log in or register to play in real money mode.');
                    return;
                  }
                  setMode('real');
                }}
                className={`px-3 py-1 rounded transition-colors ${
                  mode === 'real' ? 'bg-emerald-600 text-white font-bold shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                Real Wallet
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab navigation */}
        <div className="px-4 py-2 bg-[#080d20] border-b border-slate-800 flex items-center gap-4 text-xs font-medium shrink-0">
          <button
            onClick={() => setActiveTab('play')}
            className={`pb-1 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'play' ? 'border-amber-400 text-amber-400 font-bold' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Play className="w-3.5 h-3.5" />
            <span>Play Game</span>
          </button>
          <button
            onClick={() => setActiveTab('rules')}
            className={`pb-1 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'rules' ? 'border-amber-400 text-amber-400 font-bold' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Info className="w-3.5 h-3.5" />
            <span>Rules & Payouts</span>
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`pb-1 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'history' ? 'border-amber-400 text-amber-400 font-bold' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Round History</span>
          </button>
        </div>

        {/* Main Content Area */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1">
          {activeTab === 'play' && (
            <div className="space-y-4">
              {/* Active playable game engine */}
              {game.category === 'crash' && (
                <AviatorGame
                  userBalance={parseFloat(user?.walletBalance || '0')}
                  demoBalance={parseFloat(user?.demoBalance || '10000')}
                  mode={mode}
                  onRecordRound={handleRecordRound}
                />
              )}

              {game.category === 'slots' && (
                <SlotMachineGame
                  userBalance={parseFloat(user?.walletBalance || '0')}
                  demoBalance={parseFloat(user?.demoBalance || '10000')}
                  mode={mode}
                  onRecordRound={handleRecordRound}
                />
              )}

              {game.category === 'dice' && (
                <SicBoGame
                  userBalance={parseFloat(user?.walletBalance || '0')}
                  demoBalance={parseFloat(user?.demoBalance || '10000')}
                  mode={mode}
                  onRecordRound={handleRecordRound}
                />
              )}

              {game.category === 'cards' && (
                <BlackjackGame
                  userBalance={parseFloat(user?.walletBalance || '0')}
                  demoBalance={parseFloat(user?.demoBalance || '10000')}
                  mode={mode}
                  onRecordRound={handleRecordRound}
                />
              )}

              {game.category === 'roulette' && (
                <RouletteGame
                  userBalance={parseFloat(user?.walletBalance || '0')}
                  demoBalance={parseFloat(user?.demoBalance || '10000')}
                  mode={mode}
                  onRecordRound={handleRecordRound}
                />
              )}

              {(game.category === 'arcade' || game.category === 'original') && (
                <MinesGame
                  userBalance={parseFloat(user?.walletBalance || '0')}
                  demoBalance={parseFloat(user?.demoBalance || '10000')}
                  mode={mode}
                  onRecordRound={handleRecordRound}
                />
              )}

              {/* Regulatory Notice Banner */}
              <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-lg flex items-start gap-2.5 text-xs text-slate-400">
                <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  BIGWIN999 operates with provably fair RNG technology. Play in demo mode with virtual credits (৳10,000 standard reloadable balance). Real money gambling requires full KYC verification and compliance with applicable local regulations. 18+ only.
                </span>
              </div>
            </div>
          )}

          {activeTab === 'rules' && (
            <div className="space-y-4 max-w-2xl mx-auto">
              <div>
                <h3 className="text-base font-bold text-slate-100 mb-1">About {game.title}</h3>
                <p className="text-sm text-slate-300 leading-relaxed">{game.description}</p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-2">
                <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-800">
                  <div className="text-[11px] text-slate-400">Provider</div>
                  <div className="text-sm font-semibold text-slate-200">{game.provider}</div>
                </div>
                <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-800">
                  <div className="text-[11px] text-slate-400">Theoretical RTP</div>
                  <div className="text-sm font-semibold text-emerald-400 font-mono">{game.rtp}</div>
                </div>
                <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-800">
                  <div className="text-[11px] text-slate-400">Volatility</div>
                  <div className="text-sm font-semibold text-amber-400">{game.volatility}</div>
                </div>
                <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-800">
                  <div className="text-[11px] text-slate-400">Max Multiplier</div>
                  <div className="text-sm font-semibold text-amber-300 font-mono">{game.maxMultiplier}</div>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-200 mb-2">How to Play & Game Instructions</h4>
                <ul className="space-y-2">
                  {game.instructions.map((step, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                      <span className="w-5 h-5 rounded-full bg-slate-800 text-amber-400 font-bold flex items-center justify-center shrink-0 text-[11px]">
                        {idx + 1}
                      </span>
                      <span className="pt-0.5">{step}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-3 max-w-2xl mx-auto">
              <h3 className="text-sm font-bold text-slate-200">Your Recent Game Rounds</h3>
              {roundLogs.length === 0 ? (
                <div className="text-center py-10 text-slate-500 text-xs">
                  No rounds recorded for this session yet. Launch a game round to see round history.
                </div>
              ) : (
                <div className="divide-y divide-slate-800 border border-slate-800 rounded-lg overflow-hidden">
                  {roundLogs.map((r, i) => (
                    <div key={i} className="p-3 bg-slate-900/40 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-semibold text-slate-200">{r.resultSummary}</div>
                        <div className="text-[11px] text-slate-500">
                          {new Date(r.createdAt).toLocaleTimeString()} · Mode: {r.mode}
                        </div>
                      </div>
                      <div className="text-right font-mono">
                        <div className="text-slate-400">Bet: ৳{r.betAmount}</div>
                        <div className={`font-bold ${parseFloat(r.payoutAmount) > 0 ? 'text-emerald-400' : 'text-slate-500'}`}>
                          Win: ৳{r.payoutAmount} ({r.multiplier}x)
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
