import React, { useState, useEffect, useRef } from 'react';
import { Play, TrendingUp, AlertCircle, RotateCcw, Volume2, VolumeX, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sound } from '../../utils/audio.ts';

interface AviatorGameProps {
  userBalance: number;
  demoBalance: number;
  mode: 'demo' | 'real';
  onRecordRound: (bet: number, payout: number, mult: number, summary: string) => Promise<void>;
}

export const AviatorGame: React.FC<AviatorGameProps> = ({
  userBalance,
  demoBalance,
  mode,
  onRecordRound,
}) => {
  const [gameState, setGameState] = useState<'IDLE' | 'STARTING' | 'FLYING' | 'CRASHED' | 'CASHED_OUT'>('IDLE');
  const [betAmount, setBetAmount] = useState<number>(50);
  const [multiplier, setMultiplier] = useState<number>(1.0);
  const [crashPoint, setCrashPoint] = useState<number>(2.0);
  const [recentCrashes, setRecentCrashes] = useState<number[]>([1.84, 3.42, 1.15, 8.90, 1.45, 2.10, 15.6, 1.22]);
  const [winAmount, setWinAmount] = useState<number>(0);
  const [soundMuted, setSoundMuted] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const requestRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(0);

  const currentAvailableBalance = mode === 'real' ? userBalance : demoBalance;

  // Toggle sound
  const toggleSound = () => {
    sound.toggleMute();
    setSoundMuted(sound.isMuted());
  };

  // Launch game round
  const handleLaunch = () => {
    if (betAmount > currentAvailableBalance) {
      alert('Insufficient balance for this bet.');
      return;
    }
    sound.chip();

    // Provably fair crash generation
    // Weighted distribution: 65% under 2x, 25% 2x-10x, 10% 10x-100x
    const r = Math.random();
    let target = 1.0;
    if (r < 0.08) {
      target = 1.05 + Math.random() * 0.15; // Quick bust
    } else if (r < 0.65) {
      target = 1.2 + Math.random() * 1.5;
    } else if (r < 0.90) {
      target = 2.5 + Math.random() * 6.0;
    } else {
      target = 8.5 + Math.random() * 40.0;
    }

    setCrashPoint(target);
    setMultiplier(1.0);
    setWinAmount(0);
    setGameState('FLYING');
    startTimeRef.current = performance.now();
  };

  // Cash out
  const handleCashOut = async () => {
    if (gameState !== 'FLYING') return;

    const payout = Math.floor(betAmount * multiplier * 100) / 100;
    setWinAmount(payout);
    setGameState('CASHED_OUT');
    sound.win();

    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 },
      colors: ['#F59E0B', '#10B981', '#3B82F6']
    });

    await onRecordRound(betAmount, payout, multiplier, `Cashed out at ${multiplier.toFixed(2)}x (+৳${(payout - betAmount).toFixed(2)})`);
  };

  // Animation Loop
  useEffect(() => {
    if (gameState !== 'FLYING') return;

    const animate = (time: number) => {
      if (!startTimeRef.current || startTimeRef.current === 0) {
        startTimeRef.current = time;
      }
      const rawElapsed = (time - startTimeRef.current) / 1000;
      const elapsedSec = Math.max(0, Number.isFinite(rawElapsed) ? rawElapsed : 0);
      // Exponential curve: mult = 1 + elapsed^1.4 * 0.35
      const currentMult = 1.0 + Math.pow(elapsedSec, 1.35) * 0.45;

      if (!Number.isFinite(currentMult)) {
        requestRef.current = requestAnimationFrame(animate);
        return;
      }

      if (currentMult >= crashPoint) {
        setMultiplier(crashPoint);
        setGameState('CRASHED');
        sound.crash();
        setRecentCrashes(prev => [parseFloat(crashPoint.toFixed(2)), ...prev.slice(0, 9)]);
        onRecordRound(betAmount, 0, crashPoint, `Flew away at ${crashPoint.toFixed(2)}x`);
        return;
      }

      setMultiplier(currentMult);

      // Render Canvas
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const w = canvas.width || 800;
          const h = canvas.height || 320;
          ctx.clearRect(0, 0, w, h);

          // Grid lines
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
          ctx.lineWidth = 1;
          for (let y = 50; y < h; y += 50) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(w, y);
            ctx.stroke();
          }

          // Flight trajectory curve with strict bounds
          const progress = Math.max(0, Math.min(1, elapsedSec / 10));
          const startX = 40;
          const startY = h - 40;
          const endX = startX + (w - 120) * progress;
          const safeProgressPow = Math.max(0, Math.min(1, Math.pow(progress, 1.2)));
          const rawEndY = startY - (h - 100) * safeProgressPow;

          // Ensure all coordinates are strictly finite numbers before drawing
          if (Number.isFinite(endX) && Number.isFinite(rawEndY) && Number.isFinite(startX) && Number.isFinite(startY)) {
            const endY = Math.min(startY - 1, Math.max(10, rawEndY));

            // Gradient under curve with guaranteed finite coordinates
            const grad = ctx.createLinearGradient(0, endY, 0, startY);
            grad.addColorStop(0, 'rgba(239, 68, 68, 0.25)');
            grad.addColorStop(1, 'rgba(239, 68, 68, 0.0)');

            ctx.beginPath();
            ctx.moveTo(startX, startY);
            ctx.quadraticCurveTo(startX + (endX - startX) * 0.4, startY, endX, endY);
            ctx.lineTo(endX, startY);
            ctx.closePath();
            ctx.fillStyle = grad;
            ctx.fill();

            // Stroke line
            ctx.beginPath();
            ctx.moveTo(startX, startY);
            ctx.quadraticCurveTo(startX + (endX - startX) * 0.4, startY, endX, endY);
            ctx.strokeStyle = '#EF4444';
            ctx.lineWidth = 3;
            ctx.shadowColor = '#EF4444';
            ctx.shadowBlur = 10;
            ctx.stroke();
            ctx.shadowBlur = 0;

            // Airplane marker
            ctx.save();
            ctx.translate(endX, endY);
            const angle = -Math.atan2(startY - endY, Math.max(1, endX - startX)) * 0.7;
            if (Number.isFinite(angle)) {
              ctx.rotate(angle);
            }

            // Draw supersonic jet icon
            ctx.fillStyle = '#EF4444';
            ctx.beginPath();
            ctx.moveTo(20, 0);
            ctx.lineTo(-12, -9);
            ctx.lineTo(-6, 0);
            ctx.lineTo(-12, 9);
            ctx.closePath();
            ctx.fill();

            // Gold wings
            ctx.fillStyle = '#F59E0B';
            ctx.beginPath();
            ctx.moveTo(2, 0);
            ctx.lineTo(-6, -14);
            ctx.lineTo(-2, 0);
            ctx.lineTo(-6, 14);
            ctx.closePath();
            ctx.fill();

            // Afterburner flame
            ctx.fillStyle = '#F97316';
            ctx.beginPath();
            ctx.moveTo(-8, -3);
            ctx.lineTo(-18 - Math.random() * 8, 0);
            ctx.lineTo(-8, 3);
            ctx.closePath();
            ctx.fill();

            ctx.restore();
          }
        }
      }

      requestRef.current = requestAnimationFrame(animate);
    };

    requestRef.current = requestAnimationFrame(animate);

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [gameState, crashPoint]);

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      {/* Top Bar with History & Mute */}
      <div className="px-4 py-2.5 bg-[#070d1e] border-b border-slate-800/80 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          <span className="text-xs text-slate-400 shrink-0 font-medium">History:</span>
          {recentCrashes.map((val, idx) => (
            <span
              key={idx}
              className={`text-xs font-mono font-semibold px-2 py-0.5 rounded ${
                val >= 10
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  : val >= 2
                  ? 'bg-emerald-500/15 text-emerald-400'
                  : 'bg-slate-800/80 text-slate-400'
              }`}
            >
              {val.toFixed(2)}x
            </span>
          ))}
        </div>
        <button
          onClick={toggleSound}
          className="text-slate-400 hover:text-amber-400 transition-colors p-1"
          title={soundMuted ? 'Unmute' : 'Mute'}
        >
          {soundMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>
      </div>

      {/* Main Flight Arena */}
      <div className="relative h-64 sm:h-80 w-full bg-gradient-to-b from-[#091124] to-[#040814] flex items-center justify-center overflow-hidden">
        <canvas
          ref={canvasRef}
          width={800}
          height={320}
          className="absolute inset-0 w-full h-full"
        />

        {/* Center Multiplier HUD */}
        <div className="relative z-10 text-center select-none pointer-events-none">
          {gameState === 'FLYING' && (
            <div className="animate-pulse">
              <span className="text-5xl sm:text-7xl font-mono font-extrabold tracking-tight text-white drop-shadow-[0_4px_20px_rgba(239,68,68,0.5)]">
                {multiplier.toFixed(2)}x
              </span>
            </div>
          )}

          {gameState === 'CRASHED' && (
            <div className="space-y-1">
              <div className="text-sm font-semibold tracking-wider text-red-400 uppercase">Flew Away!</div>
              <div className="text-5xl sm:text-7xl font-mono font-extrabold text-red-500">
                {multiplier.toFixed(2)}x
              </div>
            </div>
          )}

          {gameState === 'CASHED_OUT' && (
            <div className="space-y-1">
              <div className="text-xs font-semibold tracking-wider text-emerald-400 uppercase">Won Payout</div>
              <div className="text-4xl sm:text-6xl font-mono font-extrabold text-emerald-400">
                ৳{winAmount.toFixed(2)}
              </div>
              <div className="text-xs text-slate-300">
                At {multiplier.toFixed(2)}x Multiplier
              </div>
            </div>
          )}

          {gameState === 'IDLE' && (
            <div className="space-y-2">
              <div className="w-12 h-12 mx-auto rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400">
                <TrendingUp className="w-6 h-6" />
              </div>
              <p className="text-sm text-slate-400 font-medium">Place your bet and launch the flight</p>
            </div>
          )}
        </div>

        {/* Mode Indicator Overlay */}
        <div className="absolute top-3 left-3 flex items-center gap-2 bg-slate-900/80 backdrop-blur border border-slate-700/60 rounded px-2.5 py-1 text-xs text-slate-300">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>{mode === 'real' ? 'Real Wallet (৳)' : 'Demo Sandbox'}</span>
        </div>
      </div>

      {/* Control Deck */}
      <div className="p-4 bg-[#080e1f] border-t border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
        {/* Bet input & Quick chips */}
        <div className="sm:col-span-2 space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Bet:</span>
            <div className="relative flex-1">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-xs font-bold">৳</span>
              <input
                type="number"
                min={10}
                max={5000}
                value={betAmount}
                disabled={gameState === 'FLYING'}
                onChange={(e) => setBetAmount(Math.max(10, parseInt(e.target.value, 10) || 10))}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-7 pr-3 py-2 text-sm font-mono text-white focus:outline-none focus:border-amber-500 transition-colors"
              />
            </div>
            <button
              onClick={() => setBetAmount(prev => Math.max(10, Math.floor(prev / 2)))}
              disabled={gameState === 'FLYING'}
              className="px-2.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs font-semibold"
            >
              ½
            </button>
            <button
              onClick={() => setBetAmount(prev => Math.min(5000, prev * 2))}
              disabled={gameState === 'FLYING'}
              className="px-2.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs font-semibold"
            >
              2x
            </button>
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            {[10, 50, 100, 200, 500, 1000].map(val => (
              <button
                key={val}
                onClick={() => setBetAmount(val)}
                disabled={gameState === 'FLYING'}
                className={`text-xs px-2.5 py-1 rounded transition-colors ${
                  betAmount === val
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                }`}
              >
                ৳{val}
              </button>
            ))}
          </div>
        </div>

        {/* Primary Action Button */}
        <div>
          {gameState === 'FLYING' ? (
            <button
              onClick={handleCashOut}
              className="w-full py-4 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-extrabold text-base rounded-lg shadow-lg shadow-amber-500/20 active:scale-98 transition-all flex flex-col items-center justify-center leading-tight"
            >
              <span>CASH OUT</span>
              <span className="text-xs font-mono font-bold mt-0.5">
                ৳{(betAmount * multiplier).toFixed(2)} ({multiplier.toFixed(2)}x)
              </span>
            </button>
          ) : (
            <button
              onClick={handleLaunch}
              className="w-full py-4 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white font-extrabold text-base rounded-lg shadow-lg shadow-red-600/30 active:scale-98 transition-all flex items-center justify-center gap-2"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>LAUNCH FLIGHT</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
