import React, { useState } from 'react';
import { ShieldCheck, Spade } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sound } from '../../utils/audio.ts';

interface Card {
  suit: '♠' | '♥' | '♦' | '♣';
  value: string;
  num: number;
}

interface BlackjackGameProps {
  userBalance: number;
  demoBalance: number;
  mode: 'demo' | 'real';
  onRecordRound: (bet: number, payout: number, mult: number, summary: string) => Promise<void>;
}

export const BlackjackGame: React.FC<BlackjackGameProps> = ({
  userBalance,
  demoBalance,
  mode,
  onRecordRound,
}) => {
  const [gameState, setGameState] = useState<'BETTING' | 'PLAYER_TURN' | 'DEALER_TURN' | 'FINISHED'>('BETTING');
  const [betAmount, setBetAmount] = useState<number>(50);
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [resultMsg, setResultMsg] = useState<string>('');

  const currentAvailableBalance = mode === 'real' ? userBalance : demoBalance;

  // Deck generation
  const drawCard = (): Card => {
    const suits: ('♠' | '♥' | '♦' | '♣')[] = ['♠', '♥', '♦', '♣'];
    const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    const s = suits[Math.floor(Math.random() * suits.length)];
    const v = values[Math.floor(Math.random() * values.length)];
    let n = parseInt(v, 10);
    if (v === 'A') n = 11;
    else if (['J', 'Q', 'K'].includes(v)) n = 10;
    return { suit: s, value: v, num: n };
  };

  const calculateHand = (hand: Card[]): number => {
    let sum = hand.reduce((acc, c) => acc + c.num, 0);
    let aces = hand.filter(c => c.value === 'A').length;
    while (sum > 21 && aces > 0) {
      sum -= 10;
      aces--;
    }
    return sum;
  };

  const handleDeal = () => {
    if (betAmount > currentAvailableBalance) {
      alert('Insufficient balance for bet');
      return;
    }
    sound.chip();
    const p1 = drawCard();
    const d1 = drawCard();
    const p2 = drawCard();
    const d2 = drawCard();

    const pHand = [p1, p2];
    const dHand = [d1, d2];
    setPlayerHand(pHand);
    setDealerHand(dHand);
    setResultMsg('');

    const pScore = calculateHand(pHand);
    if (pScore === 21) {
      // Natural Blackjack!
      setGameState('FINISHED');
      const payout = betAmount * 2.5;
      setResultMsg(`BLACKJACK! Natural 21 pays 3:2 (+৳${(payout - betAmount).toFixed(2)})`);
      sound.bigWin();
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      onRecordRound(betAmount, payout, 2.5, 'Natural Blackjack (3:2)');
      return;
    }

    setGameState('PLAYER_TURN');
  };

  const handleHit = async () => {
    sound.tick();
    const newCard = drawCard();
    const nextHand = [...playerHand, newCard];
    setPlayerHand(nextHand);
    const score = calculateHand(nextHand);

    if (score > 21) {
      // Bust
      setGameState('FINISHED');
      sound.crash();
      setResultMsg(`Bust (${score})! Bet lost.`);
      await onRecordRound(betAmount, 0, 0, `Player bust at ${score}`);
    }
  };

  const handleStand = async () => {
    setGameState('DEALER_TURN');
    sound.tick();

    let curDealer = [...dealerHand];
    let dScore = calculateHand(curDealer);

    // Dealer draws to 17
    while (dScore < 17) {
      curDealer.push(drawCard());
      dScore = calculateHand(curDealer);
    }

    setDealerHand(curDealer);
    setGameState('FINISHED');

    const pScore = calculateHand(playerHand);

    if (dScore > 21) {
      const payout = betAmount * 2;
      setResultMsg(`Dealer busts with ${dScore}! You win ৳${payout.toFixed(2)}`);
      sound.win();
      confetti({ particleCount: 40, spread: 50 });
      await onRecordRound(betAmount, payout, 2.0, `Dealer bust (${dScore})`);
    } else if (pScore > dScore) {
      const payout = betAmount * 2;
      setResultMsg(`You win (${pScore} vs ${dScore})! Payout: ৳${payout.toFixed(2)}`);
      sound.win();
      await onRecordRound(betAmount, payout, 2.0, `Player won (${pScore} vs ${dScore})`);
    } else if (pScore === dScore) {
      setResultMsg(`Push! Tie at ${pScore}. Bet refunded.`);
      sound.chip();
      await onRecordRound(betAmount, betAmount, 1.0, `Push at ${pScore}`);
    } else {
      setResultMsg(`Dealer wins with ${dScore} vs your ${pScore}.`);
      sound.crash();
      await onRecordRound(betAmount, 0, 0, `Dealer beat player (${dScore} vs ${pScore})`);
    }
  };

  const pTotal = calculateHand(playerHand);
  const dTotal = gameState === 'PLAYER_TURN'
    ? dealerHand[0]?.num || 0
    : calculateHand(dealerHand);

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      <div className="px-4 py-2.5 bg-[#070d1e] border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Spade className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-semibold text-slate-200">Blackjack Royale 21</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>{mode === 'real' ? 'Real Balance' : 'Demo Credits'}</span>
        </div>
      </div>

      {/* Table Felt */}
      <div className="p-4 sm:p-6 bg-gradient-to-b from-[#0b3322] to-[#061e14] border-b border-emerald-900/50">
        {/* Dealer area */}
        <div className="text-center mb-6">
          <div className="text-xs text-emerald-300 font-semibold mb-2">
            Dealer Hand {dealerHand.length > 0 && `(${gameState === 'PLAYER_TURN' ? `${dTotal}+?` : dTotal})`}
          </div>
          <div className="flex items-center justify-center gap-2">
            {dealerHand.map((c, i) => (
              <div
                key={i}
                className={`w-12 h-16 sm:w-14 sm:h-20 rounded-lg flex flex-col justify-between p-1.5 font-bold shadow-md select-none ${
                  i === 1 && gameState === 'PLAYER_TURN'
                    ? 'bg-gradient-to-br from-blue-900 to-indigo-950 border border-blue-600/40 text-blue-300 items-center justify-center text-xs'
                    : 'bg-white text-slate-900'
                }`}
              >
                {i === 1 && gameState === 'PLAYER_TURN' ? (
                  <span>?</span>
                ) : (
                  <>
                    <span className={`text-xs ${['♥', '♦'].includes(c.suit) ? 'text-red-600' : 'text-slate-950'}`}>{c.value}</span>
                    <span className={`text-base self-center ${['♥', '♦'].includes(c.suit) ? 'text-red-600' : 'text-slate-950'}`}>{c.suit}</span>
                    <span className={`text-xs self-end ${['♥', '♦'].includes(c.suit) ? 'text-red-600' : 'text-slate-950'}`}>{c.value}</span>
                  </>
                )}
              </div>
            ))}
            {dealerHand.length === 0 && <div className="text-xs text-emerald-400/60 py-4">Waiting for deal...</div>}
          </div>
        </div>

        {/* Player area */}
        <div className="text-center">
          <div className="text-xs text-emerald-300 font-semibold mb-2">
            Your Hand {playerHand.length > 0 && `(${pTotal})`}
          </div>
          <div className="flex items-center justify-center gap-2">
            {playerHand.map((c, i) => (
              <div
                key={i}
                className="w-12 h-16 sm:w-14 sm:h-20 rounded-lg bg-white text-slate-900 flex flex-col justify-between p-1.5 font-bold shadow-md select-none"
              >
                <span className={`text-xs ${['♥', '♦'].includes(c.suit) ? 'text-red-600' : 'text-slate-950'}`}>{c.value}</span>
                <span className={`text-base self-center ${['♥', '♦'].includes(c.suit) ? 'text-red-600' : 'text-slate-950'}`}>{c.suit}</span>
                <span className={`text-xs self-end ${['♥', '♦'].includes(c.suit) ? 'text-red-600' : 'text-slate-950'}`}>{c.value}</span>
              </div>
            ))}
            {playerHand.length === 0 && <div className="text-xs text-emerald-400/60 py-4">Cards appear here</div>}
          </div>
        </div>

        {resultMsg && (
          <div className="mt-4 p-2 bg-slate-950/80 rounded border border-amber-500/40 text-center text-xs font-bold text-amber-300 animate-pulse max-w-sm mx-auto">
            {resultMsg}
          </div>
        )}
      </div>

      {/* Control panel */}
      <div className="p-4 bg-[#080e1f] flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">Bet:</span>
          {[20, 50, 100, 200, 500].map(val => (
            <button
              key={val}
              onClick={() => setBetAmount(val)}
              disabled={gameState === 'PLAYER_TURN'}
              className={`text-xs px-2.5 py-1 rounded transition-colors ${
                betAmount === val ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300'
              }`}
            >
              ৳{val}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          {gameState === 'PLAYER_TURN' ? (
            <>
              <button
                onClick={handleHit}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg uppercase tracking-wider"
              >
                Hit
              </button>
              <button
                onClick={handleStand}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg uppercase tracking-wider"
              >
                Stand
              </button>
            </>
          ) : (
            <button
              onClick={handleDeal}
              className="px-6 py-2.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-extrabold text-xs rounded-lg uppercase tracking-wider shadow-md"
            >
              Deal Hand (৳{betAmount})
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
