import React, { useState } from 'react';
import { Bomb, Gem, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sound } from '../../utils/audio.ts';

interface MinesGameProps {
  userBalance: number;
  demoBalance: number;
  mode: 'demo' | 'real';
  onRecordRound: (bet: number, payout: number, mult: number, summary: string) => Promise<void>;
}

export const MinesGame: React.FC<MinesGameProps> = ({
  userBalance,
  demoBalance,
  mode,
  onRecordRound,
}) => {
  const [betAmount, setBetAmount] = useState<number>(50);
  const [mineCount, setMineCount] = useState<number>(3);
  const [gameState, setGameState] = useState<'IDLE' | 'PLAYING' | 'BUSTED' | 'CASHED_OUT'>('IDLE');
  const [minePositions, setMinePositions] = useState<number[]>([]);
  const [revealed, setRevealed] = useState<number[]>([]);
  const [currentMultiplier, setCurrentMultiplier] = useState<number>(1.0);

  const currentAvailableBalance = mode === 'real' ? userBalance : demoBalance;

  // Start round
  const handleStart = () => {
    if (betAmount > currentAvailableBalance) {
      alert('Insufficient balance.');
      return;
    }
    sound.chip();

    // Generate unique random mine positions (0 to 24)
    const positions: number[] = [];
    while (positions.length < mineCount) {
      const pos = Math.floor(Math.random() * 25);
      if (!positions.includes(pos)) {
        positions.push(pos);
      }
    }

    setMinePositions(positions);
    setRevealed([]);
    setCurrentMultiplier(1.0);
    setGameState('PLAYING');
  };

  // Click tile
  const handleTileClick = async (idx: number) => {
    if (gameState !== 'PLAYING') return;
    if (revealed.includes(idx)) return;

    if (minePositions.includes(idx)) {
      // Hitting a mine!
      sound.crash();
      setRevealed(prev => [...prev, idx]);
      setGameState('BUSTED');
      await onRecordRound(betAmount, 0, 0, `Detonated mine on tile #${idx + 1}`);
      return;
    }

    // Revealed a Gem
    sound.tick();
    const newRevealed = [...revealed, idx];
    setRevealed(newRevealed);

    // Calculate compounding multiplier based on total tiles, mines, and steps
    const safeTilesTotal = 25 - mineCount;
    const gemsFound = newRevealed.length;
    // Multiplier curve based on probability
    let mult = 1.0;
    for (let i = 0; i < gemsFound; i++) {
      mult *= (25 - i) / (safeTilesTotal - i);
    }
    // Apply house edge 0.98
    const roundedMult = Math.floor(mult * 0.98 * 100) / 100;
    setCurrentMultiplier(roundedMult);

    if (gemsFound === safeTilesTotal) {
      // Uncovered all gems!
      handleCashOut();
    }
  };

  // Cash out
  const handleCashOut = async () => {
    if (gameState !== 'PLAYING' || revealed.length === 0) return;

    const payout = Math.floor(betAmount * currentMultiplier * 100) / 100;
    setGameState('CASHED_OUT');
    sound.win();
    confetti({ particleCount: 50, spread: 60 });

    await onRecordRound(
      betAmount,
      payout,
      currentMultiplier,
      `Cashed out ${revealed.length} gems at ${currentMultiplier.toFixed(2)}x (+৳${(payout - betAmount).toFixed(2)})`
    );
  };

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      <div className="px-4 py-2.5 bg-[#070d1e] border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bomb className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-semibold text-slate-200">Minesweeper Cash Rush</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>{mode === 'real' ? 'Real Balance' : 'Demo Credits'}</span>
        </div>
      </div>

      <div className="p-4 sm:p-6 bg-gradient-to-b from-[#0e1730] to-[#080d1e]">
        {/* 5x5 Grid */}
        <div className="grid grid-cols-5 gap-2 max-w-xs mx-auto">
          {Array.from({ length: 25 }).map((_, idx) => {
            const isRevealed = revealed.includes(idx);
            const isMine = minePositions.includes(idx);
            const showAllOnBust = gameState === 'BUSTED' && isMine;

            return (
              <button
                key={idx}
                onClick={() => handleTileClick(idx)}
                disabled={gameState !== 'PLAYING' || isRevealed}
                className={`w-12 h-12 sm:w-14 sm:h-14 rounded-lg flex items-center justify-center font-bold text-lg transition-all ${
                  isRevealed && isMine
                    ? 'bg-red-600 text-white animate-pulse'
                    : isRevealed
                    ? 'bg-emerald-600/30 border border-emerald-500 text-emerald-300 shadow-sm'
                    : showAllOnBust
                    ? 'bg-red-900/60 text-red-400 border border-red-700'
                    : 'bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-400 border border-slate-700/60'
                }`}
              >
                {isRevealed && isMine ? (
                  <Bomb className="w-6 h-6 text-red-100" />
                ) : isRevealed ? (
                  <Gem className="w-6 h-6 text-emerald-400 animate-bounce" />
                ) : showAllOnBust ? (
                  <Bomb className="w-5 h-5 text-red-400" />
                ) : (
                  <div className="w-2 h-2 rounded-full bg-slate-600" />
                )}
              </button>
            );
          })}
        </div>

        {/* Status / Multiplier Banner */}
        <div className="mt-4 text-center">
          {gameState === 'PLAYING' && (
            <div className="text-xs font-mono text-slate-300">
              Gems Found: <span className="font-bold text-emerald-400">{revealed.length}</span> · Next Multiplier: <span className="font-bold text-amber-400">{currentMultiplier.toFixed(2)}x</span>
            </div>
          )}
          {gameState === 'BUSTED' && (
            <div className="text-xs font-bold text-red-400">BOOM! Hit a mine. Round ended.</div>
          )}
          {gameState === 'CASHED_OUT' && (
            <div className="text-xs font-bold text-emerald-400">
              Cashed out ৳{(betAmount * currentMultiplier).toFixed(2)} at {currentMultiplier.toFixed(2)}x!
            </div>
          )}
        </div>
      </div>

      {/* Control Strip */}
      <div className="p-4 bg-[#080e1f] border-t border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
        <div className="space-y-1">
          <label className="text-[11px] text-slate-400 font-medium">Bet Amount (৳):</label>
          <input
            type="number"
            min={10}
            max={5000}
            value={betAmount}
            disabled={gameState === 'PLAYING'}
            onChange={(e) => setBetAmount(Math.max(10, parseInt(e.target.value, 10) || 10))}
            className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs font-mono text-white"
          />
        </div>

        <div className="space-y-1">
          <label className="text-[11px] text-slate-400 font-medium">Mines Count:</label>
          <div className="flex items-center gap-1">
            {[1, 3, 5, 10, 15].map(m => (
              <button
                key={m}
                onClick={() => setMineCount(m)}
                disabled={gameState === 'PLAYING'}
                className={`flex-1 py-1.5 rounded text-xs font-mono font-bold ${
                  mineCount === m ? 'bg-red-600 text-white' : 'bg-slate-800 text-slate-300'
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        <div>
          {gameState === 'PLAYING' ? (
            <button
              onClick={handleCashOut}
              disabled={revealed.length === 0}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-emerald-400 hover:from-emerald-400 text-slate-950 font-extrabold text-xs uppercase tracking-wider rounded-lg shadow-md disabled:opacity-40"
            >
              Cash Out ৳{(betAmount * currentMultiplier).toFixed(2)} ({currentMultiplier.toFixed(2)}x)
            </button>
          ) : (
            <button
              onClick={handleStart}
              className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-extrabold text-xs uppercase tracking-wider rounded-lg shadow-md"
            >
              Start Game
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
