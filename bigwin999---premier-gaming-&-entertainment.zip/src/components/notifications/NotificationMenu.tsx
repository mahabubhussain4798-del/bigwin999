import React, { useState, useRef, useEffect } from 'react';
import {
  Bell, CheckCheck, Trash2, Trophy, Coins, Wallet,
  Sparkles, AlertCircle, X, ChevronRight, PlayCircle
} from 'lucide-react';
import { useNotifications, NotificationItem } from '../../context/NotificationContext.tsx';

export const NotificationMenu: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    clearAll,
    clearNotification,
    triggerMockBetSettled,
    triggerMockDepositApproved,
  } = useNotifications();

  const menuRef = useRef<HTMLDivElement>(null);

  // Close when clicked outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const formatTime = (isoString: string) => {
    try {
      const d = new Date(isoString);
      const diffMin = Math.floor((Date.now() - d.getTime()) / 60000);
      if (diffMin < 1) return 'Just now';
      if (diffMin < 60) return `${diffMin}m ago`;
      const diffHours = Math.floor(diffMin / 60);
      if (diffHours < 24) return `${diffHours}h ago`;
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    } catch (_) {
      return '';
    }
  };

  return (
    <div className="relative shrink-0" ref={menuRef}>
      {/* Bell Trigger */}
      <button
        onClick={() => setIsOpen(prev => !prev)}
        className="relative p-2 bg-slate-900 border border-slate-700/80 rounded-lg text-slate-300 hover:text-white hover:border-amber-400/50 transition-colors flex items-center justify-center group"
        title="Live Alerts & Notifications"
        aria-label="Notifications"
      >
        <Bell className="w-4 h-4 group-hover:rotate-12 transition-transform text-amber-400" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-amber-500 text-slate-950 font-black text-[10px] w-4 h-4 rounded-full flex items-center justify-center animate-pulse shadow-md">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-[#0a1124] border border-slate-700 rounded-2xl shadow-2xl z-50 overflow-hidden flex flex-col max-h-[85vh]">
          {/* Header */}
          <div className="p-3.5 bg-[#070d1e] border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-white text-sm">Notifications</h3>
              {unreadCount > 0 && (
                <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-full">
                  {unreadCount} new
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              {unreadCount > 0 && (
                <button
                  onClick={markAllAsRead}
                  className="px-2 py-1 hover:text-amber-400 hover:bg-slate-800/80 rounded flex items-center gap-1 transition-colors text-[11px]"
                  title="Mark all as read"
                >
                  <CheckCheck className="w-3.5 h-3.5" />
                  <span>Read all</span>
                </button>
              )}
              {notifications.length > 0 && (
                <button
                  onClick={clearAll}
                  className="p-1 hover:text-rose-400 hover:bg-slate-800/80 rounded transition-colors"
                  title="Clear all notifications"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Instant Simulator Section (User / Evaluator controls) */}
          <div className="p-2.5 bg-slate-950/70 border-b border-slate-800/80">
            <div className="flex items-center justify-between mb-1.5 px-1">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>Simulate Mock Alerts</span>
              </span>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                onClick={() => triggerMockBetSettled(true)}
                className="px-2 py-1.5 bg-emerald-950/60 hover:bg-emerald-900/70 border border-emerald-500/40 rounded-lg text-[10px] font-bold text-emerald-300 transition-all text-center flex flex-col items-center gap-0.5"
              >
                <Trophy className="w-3 h-3 text-emerald-400" />
                <span>Win Bet</span>
              </button>
              <button
                onClick={() => triggerMockBetSettled(false)}
                className="px-2 py-1.5 bg-amber-950/60 hover:bg-amber-900/70 border border-amber-500/40 rounded-lg text-[10px] font-bold text-amber-300 transition-all text-center flex flex-col items-center gap-0.5"
              >
                <Coins className="w-3 h-3 text-amber-400" />
                <span>Settle Bet</span>
              </button>
              <button
                onClick={() => triggerMockDepositApproved(1500, 'bKash')}
                className="px-2 py-1.5 bg-cyan-950/60 hover:bg-cyan-900/70 border border-cyan-500/40 rounded-lg text-[10px] font-bold text-cyan-300 transition-all text-center flex flex-col items-center gap-0.5"
              >
                <Wallet className="w-3 h-3 text-cyan-400" />
                <span>Deposit Ok</span>
              </button>
            </div>
          </div>

          {/* Notifications List */}
          <div className="overflow-y-auto flex-1 divide-y divide-slate-800/60 max-h-80">
            {notifications.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs flex flex-col items-center gap-2">
                <Bell className="w-8 h-8 text-slate-700" />
                <span>No alerts yet. Play a game or deposit to see live settlement toasts!</span>
              </div>
            ) : (
              notifications.map(item => {
                const isWon = item.type === 'bet_won';
                const isDeposit = item.type === 'deposit_approved';
                const isLoss = item.type === 'bet_lost';

                return (
                  <div
                    key={item.id}
                    onClick={() => markAsRead(item.id)}
                    className={`p-3 transition-colors hover:bg-slate-900/80 flex items-start gap-2.5 relative group ${
                      !item.read ? 'bg-[#0e172e]/60' : ''
                    }`}
                  >
                    {!item.read && (
                      <div className="absolute top-3 left-1.5 w-1.5 h-1.5 rounded-full bg-amber-400 ring-2 ring-amber-400/20" />
                    )}

                    <div
                      className={`w-7 h-7 rounded-lg shrink-0 flex items-center justify-center text-xs mt-0.5 ${
                        isWon
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : isDeposit
                          ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                          : isLoss
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {isWon ? <Trophy className="w-3.5 h-3.5" /> : isDeposit ? <Wallet className="w-3.5 h-3.5" /> : <Coins className="w-3.5 h-3.5" />}
                    </div>

                    <div className="flex-1 min-w-0 pr-2">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-xs font-bold text-white truncate">
                          {item.title}
                        </span>
                        <span className="text-[10px] text-slate-500 shrink-0">
                          {formatTime(item.timestamp)}
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-300 mt-0.5 leading-snug break-words">
                        {item.message}
                      </p>

                      {item.amount !== undefined && (
                        <div className="mt-1 text-[11px] font-mono font-bold">
                          <span className={item.amount >= 0 ? (isDeposit ? 'text-cyan-400' : 'text-emerald-400') : 'text-rose-400'}>
                            {item.amount >= 0 ? `+৳${item.amount.toFixed(2)}` : `-৳${Math.abs(item.amount).toFixed(2)}`}
                          </span>
                        </div>
                      )}
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        clearNotification(item.id);
                      }}
                      className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-rose-400 rounded transition-opacity"
                      title="Delete notification"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
