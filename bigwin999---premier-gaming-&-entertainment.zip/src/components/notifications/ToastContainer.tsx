import React, { useEffect, useState } from 'react';
import {
  Trophy, CheckCircle2, AlertCircle, X, Sparkles,
  Coins, Wallet, ArrowUpRight
} from 'lucide-react';
import { useNotifications, ToastItem, NotificationType } from '../../context/NotificationContext.tsx';

interface SingleToastProps {
  toast: ToastItem;
  onDismiss: (id: string) => void;
}

const SingleToast: React.FC<SingleToastProps> = ({ toast, onDismiss }) => {
  const { notification, durationMs, expiresAt } = toast;
  const [progress, setProgress] = useState(100);

  useEffect(() => {
    const startTime = expiresAt - durationMs;
    const interval = setInterval(() => {
      const remaining = expiresAt - Date.now();
      const pct = Math.max(0, Math.min(100, (remaining / durationMs) * 100));
      setProgress(pct);
      if (pct <= 0) {
        clearInterval(interval);
      }
    }, 40);
    return () => clearInterval(interval);
  }, [expiresAt, durationMs]);

  // Determine styling according to type
  const getTheme = (type: NotificationType) => {
    switch (type) {
      case 'bet_won':
        return {
          border: 'border-emerald-500/50 bg-[#071912]/95 shadow-emerald-950/50',
          iconBg: 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40',
          icon: <Trophy className="w-5 h-5 text-emerald-400" />,
          accentText: 'text-emerald-400',
          barColor: 'bg-emerald-500',
          badge: 'BET WON',
          badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
        };
      case 'deposit_approved':
        return {
          border: 'border-cyan-500/60 bg-[#071828]/95 shadow-cyan-950/50',
          iconBg: 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40',
          icon: <Wallet className="w-5 h-5 text-cyan-400" />,
          accentText: 'text-cyan-400',
          barColor: 'bg-cyan-500',
          badge: 'DEPOSIT CREDITED',
          badgeBg: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
        };
      case 'bet_lost':
        return {
          border: 'border-amber-500/40 bg-[#170e0a]/95 shadow-amber-950/40',
          iconBg: 'bg-amber-500/20 text-amber-400 border border-amber-500/40',
          icon: <Coins className="w-5 h-5 text-amber-400" />,
          accentText: 'text-amber-400',
          barColor: 'bg-amber-500',
          badge: 'BET SETTLED',
          badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
        };
      default:
        return {
          border: 'border-slate-700 bg-[#0c1428]/95 shadow-black/60',
          iconBg: 'bg-slate-800 text-slate-300 border border-slate-700',
          icon: <AlertCircle className="w-5 h-5 text-slate-300" />,
          accentText: 'text-slate-300',
          barColor: 'bg-slate-400',
          badge: 'NOTICE',
          badgeBg: 'bg-slate-800 text-slate-300 border-slate-700',
        };
    }
  };

  const theme = getTheme(notification.type);

  return (
    <div
      className={`pointer-events-auto relative overflow-hidden rounded-xl border ${theme.border} backdrop-blur-md shadow-2xl transition-all duration-300 animate-in slide-in-from-top-4 fade-in`}
      role="alert"
    >
      <div className="p-3.5 sm:p-4 flex items-start gap-3">
        {/* Type Icon */}
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${theme.iconBg}`}>
          {theme.icon}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0 pr-4">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className={`text-[10px] font-extrabold tracking-wider uppercase px-2 py-0.5 rounded border ${theme.badgeBg}`}>
              {theme.badge}
            </span>
            <span className="text-[11px] text-slate-400">Just now</span>
          </div>

          <h4 className="text-sm font-bold text-white tracking-tight leading-snug">
            {notification.title}
          </h4>

          <p className="text-xs text-slate-300 mt-1 leading-relaxed break-words">
            {notification.message}
          </p>

          {notification.amount !== undefined && (
            <div className="mt-2 flex items-center gap-1.5 text-xs font-mono font-bold">
              <span className="text-slate-400">Settled Amount:</span>
              <span className={`text-sm ${notification.amount >= 0 ? theme.accentText : 'text-rose-400'}`}>
                {notification.amount >= 0 ? `+৳${notification.amount.toFixed(2)}` : `-৳${Math.abs(notification.amount).toFixed(2)}`}
              </span>
            </div>
          )}
        </div>

        {/* Close Button */}
        <button
          onClick={() => onDismiss(toast.id)}
          className="shrink-0 p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors"
          aria-label="Close notification"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Progress Bar */}
      <div className="h-1 w-full bg-slate-900/60 overflow-hidden">
        <div
          className={`h-full ${theme.barColor} transition-all duration-75 ease-linear`}
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};

export const ToastContainer: React.FC = () => {
  const { activeToasts, dismissToast } = useNotifications();

  if (activeToasts.length === 0) return null;

  return (
    <aside
      aria-label="Notifications"
      className="fixed top-16 right-4 sm:right-6 z-50 pointer-events-none flex flex-col gap-2.5 max-w-[92vw] sm:max-w-md w-full"
    >
      {activeToasts.map(toast => (
        <SingleToast key={toast.id} toast={toast} onDismiss={dismissToast} />
      ))}
    </aside>
  );
};
