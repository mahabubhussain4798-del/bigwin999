import { boolean, integer, numeric, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Users table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  userId: text('user_id').notNull().unique(), // e.g. BW-102938
  name: text('name').notNull(),
  phone: text('phone').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  role: text('role').notNull().default('user'), // 'user' | 'admin' | 'superadmin'
  status: text('status').notNull().default('active'), // 'active' | 'suspended'
  referralCode: text('referral_code').notNull().unique(),
  referredBy: text('referred_by'),
  walletBalance: numeric('wallet_balance', { precision: 14, scale: 2 }).notNull().default('0.00'),
  bonusBalance: numeric('bonus_balance', { precision: 14, scale: 2 }).notNull().default('0.00'),
  demoBalance: numeric('demo_balance', { precision: 14, scale: 2 }).notNull().default('10000.00'),
  language: text('language').notNull().default('en'), // 'en' | 'bn'
  securityQuestion: text('security_question'),
  securityAnswer: text('security_answer'),
  avatarUrl: text('avatar_url'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Transactions table (Deposits, Withdrawals, Bets, Wins, Adjustments)
export const transactions = pgTable('transactions', {
  id: serial('id').primaryKey(),
  txnId: text('txn_id').notNull().unique(), // e.g. TXN-74920491
  userId: integer('user_id').references(() => users.id).notNull(),
  type: text('type').notNull(), // 'deposit' | 'withdrawal' | 'bet' | 'win' | 'bonus' | 'referral_reward' | 'adjustment'
  method: text('method').notNull(), // 'bKash' | 'Nagad' | 'Rocket' | 'Demo' | 'System'
  amount: numeric('amount', { precision: 14, scale: 2 }).notNull(),
  fee: numeric('fee', { precision: 14, scale: 2 }).notNull().default('0.00'),
  status: text('status').notNull().default('pending'), // 'pending' | 'approved' | 'rejected' | 'completed'
  accountNumber: text('account_number'), // Sender or recipient phone / account
  transactionReference: text('transaction_reference'), // e.g. bKash 8-char TrxID
  adminNote: text('admin_note'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  verifiedAt: timestamp('verified_at'),
});

// Admin payment accounts (bKash, Nagad, Rocket)
export const paymentAccounts = pgTable('payment_accounts', {
  id: serial('id').primaryKey(),
  method: text('method').notNull(), // 'bKash' | 'Nagad' | 'Rocket'
  accountNumber: text('account_number').notNull(),
  accountType: text('account_type').notNull().default('Personal'), // 'Personal' | 'Agent' | 'Merchant'
  instructions: text('instructions').notNull(),
  minDeposit: numeric('min_deposit', { precision: 10, scale: 2 }).notNull().default('100.00'),
  maxDeposit: numeric('max_deposit', { precision: 10, scale: 2 }).notNull().default('25000.00'),
  minWithdrawal: numeric('min_withdrawal', { precision: 10, scale: 2 }).notNull().default('500.00'),
  maxWithdrawal: numeric('max_withdrawal', { precision: 10, scale: 2 }).notNull().default('50000.00'),
  dailyLimit: numeric('daily_limit', { precision: 12, scale: 2 }).notNull().default('200000.00'),
  isActive: boolean('is_active').notNull().default(true),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Promotional offers
export const promotions = pgTable('promotions', {
  id: serial('id').primaryKey(),
  code: text('code').notNull().unique(),
  title: text('title').notNull(),
  titleBn: text('title_bn').notNull(),
  description: text('description').notNull(),
  descriptionBn: text('description_bn').notNull(),
  minDeposit: numeric('min_deposit', { precision: 10, scale: 2 }).notNull(),
  bonusPercent: numeric('bonus_percent', { precision: 6, scale: 2 }).notNull(),
  maxBonus: numeric('max_bonus', { precision: 10, scale: 2 }).notNull(),
  wageringRequirement: integer('wagering_requirement').notNull().default(5),
  validityDays: integer('validity_days').notNull().default(7),
  isActive: boolean('is_active').notNull().default(true),
  terms: text('terms').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Referral tracking
export const referrals = pgTable('referrals', {
  id: serial('id').primaryKey(),
  referrerId: integer('referrer_id').references(() => users.id).notNull(),
  referredUserId: integer('referred_user_id').references(() => users.id).notNull(),
  rewardAmount: numeric('reward_amount', { precision: 10, scale: 2 }).notNull().default('0.00'),
  status: text('status').notNull().default('pending'), // 'pending' | 'qualified' | 'rewarded'
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Audit and security logs
export const auditLogs = pgTable('audit_logs', {
  id: serial('id').primaryKey(),
  adminId: integer('admin_id').references(() => users.id),
  action: text('action').notNull(),
  targetType: text('target_type').notNull(), // 'user' | 'transaction' | 'payment_account' | 'promotion' | 'system'
  targetId: text('target_id'),
  details: text('details').notNull(),
  ipAddress: text('ip_address'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Game rounds history
export const gameHistory = pgTable('game_history', {
  id: serial('id').primaryKey(),
  gameId: text('game_id').notNull(),
  userId: integer('user_id').references(() => users.id).notNull(),
  mode: text('mode').notNull().default('demo'), // 'demo' | 'real'
  betAmount: numeric('bet_amount', { precision: 12, scale: 2 }).notNull(),
  payoutAmount: numeric('payout_amount', { precision: 12, scale: 2 }).notNull(),
  multiplier: numeric('multiplier', { precision: 8, scale: 2 }).notNull(),
  resultSummary: text('result_summary'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Relationships
export const usersRelations = relations(users, ({ many }) => ({
  transactions: many(transactions),
  referralsMade: many(referrals, { relationName: 'referrer' }),
  gameHistory: many(gameHistory),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
}));
