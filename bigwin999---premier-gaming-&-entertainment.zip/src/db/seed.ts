import bcrypt from 'bcryptjs';
import { db } from './index.ts';
import { users, paymentAccounts, promotions, auditLogs, transactions } from './schema.ts';
import { eq } from 'drizzle-orm';

export async function seedDatabase() {
  try {
    console.log('Seeding BIGWIN999 database...');

    // 1. Check if admin exists
    const existingAdmin = await db.select().from(users).where(eq(users.phone, '01700000000'));
    let adminId = existingAdmin[0]?.id;

    if (!existingAdmin.length) {
      const adminPassHash = await bcrypt.hash('Admin@999', 10);
      const [newAdmin] = await db.insert(users).values({
        userId: 'BW-ADMIN01',
        name: 'Chief Security Officer',
        phone: '01700000000',
        passwordHash: adminPassHash,
        role: 'admin',
        status: 'active',
        referralCode: 'ADMIN01',
        walletBalance: '50000.00',
        bonusBalance: '10000.00',
        demoBalance: '100000.00',
        language: 'en',
      }).returning();
      adminId = newAdmin.id;
      console.log('Admin user created: 01700000000 / Admin@999');
    }

    // 2. Check if demo user exists
    const existingUser = await db.select().from(users).where(eq(users.phone, '01811223344'));
    if (!existingUser.length) {
      const userPassHash = await bcrypt.hash('User@123', 10);
      const [demoUser] = await db.insert(users).values({
        userId: 'BW-718294',
        name: 'Rahim Chowdhury',
        phone: '01811223344',
        passwordHash: userPassHash,
        role: 'user',
        status: 'active',
        referralCode: 'RAHIM77',
        walletBalance: '2500.00',
        bonusBalance: '350.00',
        demoBalance: '10000.00',
        language: 'bn',
      }).returning();

      // Seed initial sample transactions
      await db.insert(transactions).values([
        {
          txnId: 'TXN-9021841',
          userId: demoUser.id,
          type: 'deposit',
          method: 'bKash',
          amount: '2000.00',
          status: 'approved',
          accountNumber: '01811223344',
          transactionReference: '8A9B2C4D',
          adminNote: 'Verified via bKash statement',
          verifiedAt: new Date(),
        },
        {
          txnId: 'TXN-9021842',
          userId: demoUser.id,
          type: 'deposit',
          method: 'Nagad',
          amount: '500.00',
          status: 'pending',
          accountNumber: '01811223344',
          transactionReference: '7H6G5F4E',
          adminNote: 'Waiting for SMS confirmation',
        },
        {
          txnId: 'TXN-9021843',
          userId: demoUser.id,
          type: 'withdrawal',
          method: 'bKash',
          amount: '1000.00',
          status: 'pending',
          accountNumber: '01811223344',
          adminNote: 'Pending administrator queue review',
        }
      ]);
      console.log('Demo user Rahim created: 01811223344 / User@123');
    }

    // 3. Payment Accounts
    const existingAccounts = await db.select().from(paymentAccounts);
    if (!existingAccounts.length) {
      await db.insert(paymentAccounts).values([
        {
          method: 'bKash',
          accountNumber: '01799887766',
          accountType: 'Personal',
          instructions: 'Go to bKash App or dial *247# -> Select "Send Money" -> Send to 01799887766 -> In reference enter your BIGWIN User ID -> Copy the 8-character Transaction ID (TrxID) and submit below.',
          minDeposit: '100.00',
          maxDeposit: '25000.00',
          minWithdrawal: '500.00',
          maxWithdrawal: '30000.00',
          dailyLimit: '200000.00',
          isActive: true,
        },
        {
          method: 'Nagad',
          accountNumber: '01822445566',
          accountType: 'Agent',
          instructions: 'Go to Nagad App or dial *167# -> Select "Cash In / Send Money" -> Send to 01822445566 -> Copy the Transaction ID from the SMS confirmation and enter here.',
          minDeposit: '100.00',
          maxDeposit: '30000.00',
          minWithdrawal: '500.00',
          maxWithdrawal: '50000.00',
          dailyLimit: '250000.00',
          isActive: true,
        },
        {
          method: 'Rocket',
          accountNumber: '019113344557',
          accountType: 'Personal',
          instructions: 'Go to Rocket App or dial *322# -> Select "Send Money" -> Send to 019113344557 (12-digit wallet) -> Enter TrxID and submit.',
          minDeposit: '200.00',
          maxDeposit: '20000.00',
          minWithdrawal: '500.00',
          maxWithdrawal: '25000.00',
          dailyLimit: '150000.00',
          isActive: true,
        },
      ]);
      console.log('Payment accounts seeded.');
    }

    // 4. Promotions
    const existingPromos = await db.select().from(promotions);
    if (!existingPromos.length) {
      await db.insert(promotions).values([
        {
          code: 'BONUS10',
          title: '৳100 Deposit — 10% Instant Bonus',
          titleBn: '৳১০০ ডিপোজিটে ১০% তাৎক্ষণিক বোনাস',
          description: 'Kickstart your gaming with 10% instant extra credits on minimum ৳100 deposit.',
          descriptionBn: 'সর্বনিম্ন ৳১০০ ডিপোজিটে ১০% অতিরিক্ত প্লেয়িং ক্রেডিট লাভ করুন।',
          minDeposit: '100.00',
          bonusPercent: '10.00',
          maxBonus: '100.00',
          wageringRequirement: 3,
          validityDays: 7,
          isActive: true,
          terms: 'Minimum deposit ৳100. Bonus valid on slots & crash games. 3x turnover required before withdrawal.',
        },
        {
          code: 'BOOST30',
          title: '৳300 Deposit — 30% Power Boost',
          titleBn: '৳৩০০ ডিপোজিটে ৩০% পাওয়ার বুস্ট',
          description: 'Triple the excitement with a 30% bonus on your ৳300+ deposit today.',
          descriptionBn: '৳৩০০ বা তার বেশি ডিপোজিটে পান ৩০% অতিরিক্ত বোনাস ক্রেডিট।',
          minDeposit: '300.00',
          bonusPercent: '30.00',
          maxBonus: '500.00',
          wageringRequirement: 5,
          validityDays: 10,
          isActive: true,
          terms: 'Valid on deposits from ৳300 to ৳1,000. 5x wagering requirement. Maximum bonus claim ৳500.',
        },
        {
          code: 'VIP50',
          title: '৳1,000 Deposit — 50% VIP Match',
          titleBn: '৳১,০০০ ডিপোজিটে ৫০% ভিআইপি ম্যাচ',
          description: 'Exclusive 50% match for serious players. Boost your bankroll to ৳1,500 instantly.',
          descriptionBn: 'অভিজ্ঞ খেলোয়াড়দের জন্য বিশেষ ৫০% বোনাস অফার। অবিলম্বে ব্যালেন্স বৃদ্ধি করুন।',
          minDeposit: '1000.00',
          bonusPercent: '50.00',
          maxBonus: '2000.00',
          wageringRequirement: 8,
          validityDays: 14,
          isActive: true,
          terms: 'Applies to deposits ৳1,000+. 8x turnover on all casino & table games. 14 days expiration.',
        },
        {
          code: 'HIGHROLLER75',
          title: '৳5,000 Deposit — 75% High Roller Exclusive',
          titleBn: '৳৫,০০০ ডিপোজিটে ৭৫% হাই রোলার স্পেশাল',
          description: 'Massive 75% bonus up to ৳10,000 for high-tier gaming enthusiasts.',
          descriptionBn: 'উচ্চ ভলিউম প্লেয়ারদের জন্য সর্বোচ্চ ৳১০,০০০ পর্যন্ত ৭৫% বোনাস।',
          minDeposit: '5000.00',
          bonusPercent: '75.00',
          maxBonus: '10000.00',
          wageringRequirement: 10,
          validityDays: 21,
          isActive: true,
          terms: 'Minimum deposit ৳5,000. Maximum bonus ৳10,000. VIP priority withdrawal queue.',
        },
        {
          code: 'MEGA100',
          title: '৳20,000 Deposit — 100% Mega Welcome Bonus',
          titleBn: '৳২০,০০০ ডিপোজিটে ১০০% মেগা বোনাস',
          description: 'The ultimate royal welcome: Double your balance up to ৳20,000 instantly!',
          descriptionBn: 'সর্বোচ্চ রাজকীয় অফার: আপনার ডিপোজিট সরাসরি দ্বিগুণ করুন ৳২০,০০০ পর্যন্ত!',
          minDeposit: '20000.00',
          bonusPercent: '100.00',
          maxBonus: '25000.00',
          wageringRequirement: 12,
          validityDays: 30,
          isActive: true,
          terms: 'Available once per player. Minimum deposit ৳20,000. Dedicated account manager included.',
        },
      ]);
      console.log('Promotions seeded.');
    }

    // 5. Initial audit log
    if (adminId) {
      await db.insert(auditLogs).values({
        adminId,
        action: 'SYSTEM_BOOTSTRAP',
        targetType: 'system',
        targetId: 'INIT',
        details: 'BIGWIN999 platform initialized with default security policies and payment rails.',
        ipAddress: '127.0.0.1',
      });
    }

    console.log('Database seeded successfully.');
  } catch (err) {
    console.error('Error during database seed:', err);
  }
}
