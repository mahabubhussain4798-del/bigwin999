import bcrypt from 'bcryptjs';
import { db } from '../src/db/index.ts';
import { users, transactions, referrals, auditLogs } from '../src/db/schema.ts';
import { eq } from 'drizzle-orm';

async function runTests() {
  console.log('--- Running BIGWIN999 Automated Platform Tests ---');
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      console.log(`✅ PASS: ${testName}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${testName}`);
      failed++;
    }
  }

  try {
    // 1. Test Password Hashing and Verification
    const password = 'SecurePassword@999';
    const hash = await bcrypt.hash(password, 10);
    const valid = await bcrypt.compare(password, hash);
    const invalid = await bcrypt.compare('WrongPassword', hash);
    assert(valid && !invalid, 'Bcrypt password hashing and validation operates securely');

    // 2. Test User Database Integrity & Queries
    const testPhone = `01799${Math.floor(100000 + Math.random() * 900000)}`;
    const [createdUser] = await db.insert(users).values({
      userId: `BW-TEST${Date.now().toString().slice(-5)}`,
      name: 'Automated Tester',
      phone: testPhone,
      passwordHash: hash,
      role: 'user',
      referralCode: `TEST${Math.floor(1000 + Math.random() * 9000)}`,
      walletBalance: '1000.00',
      demoBalance: '10000.00',
    }).returning();

    assert(Boolean(createdUser && createdUser.id), 'User registration record inserted into PostgreSQL with unique ID');

    // 3. Test Anti-Duplicate Deposit Reference Validation
    const trxId = `TEST-TRX-${Date.now()}`;
    await db.insert(transactions).values({
      txnId: `TXN-T1-${Date.now()}`,
      userId: createdUser.id,
      type: 'deposit',
      method: 'bKash',
      amount: '500.00',
      status: 'pending',
      transactionReference: trxId,
    });

    const checkDuplicate = await db.select().from(transactions).where(eq(transactions.transactionReference, trxId));
    assert(checkDuplicate.length === 1, 'Transaction reference recorded; duplicate prevention filter active');

    // 4. Test Financial Balance Deduction (Withdrawal Validation)
    const initialBal = parseFloat(createdUser.walletBalance);
    const withdrawAmt = 300.00;
    const remaining = (initialBal - withdrawAmt).toFixed(2);
    await db.update(users).set({ walletBalance: remaining }).where(eq(users.id, createdUser.id));

    const [updatedUser] = await db.select().from(users).where(eq(users.id, createdUser.id));
    assert(parseFloat(updatedUser.walletBalance) === 700.00, 'Server-side wallet deduction calculated precisely');

    // 5. Test Audit Log Invariant
    const [log] = await db.insert(auditLogs).values({
      adminId: 1,
      action: 'AUTOMATED_TEST_RUN',
      targetType: 'system',
      targetId: 'TEST-SUITE',
      details: 'Automated test suite verified wallet, transactions, and user invariants.',
      ipAddress: '127.0.0.1',
    }).returning();

    assert(Boolean(log && log.id), 'Financial audit trail log recorded successfully');

    console.log(`\nTest Summary: ${passed} Passed, ${failed} Failed.`);
    if (failed > 0) {
      process.exit(1);
    }
  } catch (err) {
    console.error('Test execution error:', err);
    process.exit(1);
  }
}

runTests();
