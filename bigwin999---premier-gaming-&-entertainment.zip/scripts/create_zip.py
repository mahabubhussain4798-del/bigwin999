import os
import zipfile

output_filename = "bigwin999-source.zip"
exclude_dirs = {"node_modules", "dist", ".git", ".cache", "__pycache__"}
exclude_extensions = {".zip", ".tar.gz", ".log"}

count = 0
total_size = 0

with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        # Modify dirs in-place to avoid traversing excluded directories
        dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
        
        for file in files:
            if file == output_filename or any(file.endswith(ext) for ext in exclude_extensions):
                continue
            
            filepath = os.path.join(root, file)
            # Normalize path for zip
            arcname = os.path.relpath(filepath, '.')
            zipf.write(filepath, arcname)
            count += 1
            total_size += os.path.getsize(filepath)

print(f"Successfully created {output_filename}: {count} files packaged, uncompressed size: {total_size / 1024:.1f} KB, zip size: {os.path.getsize(output_filename) / 1024:.1f} KB")
