# BIGWIN999 — Complete Gaming Platform & Admin Dashboard

BIGWIN999 is a full-stack, enterprise-grade online gaming web platform and administrative control center built with React 19, TypeScript, Tailwind CSS, Vite, Express, and PostgreSQL (via Drizzle ORM).

---

## ⚠️ Important Legal & Regulatory Notice
> **Responsible Gaming & Compliance Disclaimer**:
> This platform is architected exclusively with **playable demo mode and virtual credits (৳)** by default. Real-money gaming, betting, or wagering operations must **strictly not be enabled** without the requisite statutory approvals, regional gambling licenses, and independent RNG fairness certification from recognized testing laboratories (e.g., eCOGRA, iTech Labs, BMM Testlabs). Users must be at least 18 years old or of legal age in their jurisdiction.

---

## 🌟 Key Features

### 1. User Gaming Portal
- **Dark Navy & Gold Aesthetic**: Immersive styling tailored for both mobile and desktop viewports.
- **Bilingual Interface**: Seamless instant switching between **Bengali (বাংলা)** and **English**.
- **100+ Game Catalog**: Includes Aviator/Airplane crash simulator, 5-Reel Slot machines, Sic Bo dice, Roulette, Blackjack/Cards, Arcade, and custom mini-games.
- **Playable Demo Mode**: Built-in virtual credits for safe, fun gameplay with realistic client-side canvas physics and audio synthesis.
- **Financial Wallet**: bKash, Nagad, and Rocket deposit requests with automated duplicate transaction reference (TrxID) protection.
- **Refer & Earn**: Unique referral codes, tracking, and tier rewards.
- **Live Notifications**: Audio-visual toast notifications for bet settlements, wins, and deposit approvals.
- **7-Day Trend Chart**: Interactive Recharts visualization tracking personal performance.

### 2. Private Superadmin Control Center
- **Role-Based Authentication**: Dedicated `/admin` gateway with server-side PIN and credential verification.
- **30-Day Financial Trend Chart**: Visualizes daily deposit volume patterns and growth metrics.
- **11 Dashboard Metrics**: Real-time stats on registered users, daily deposits, withdrawals, pending requests, outstanding credits, and referral bonuses.
- **Financial Request Verification**: One-click approval/rejection for deposits and withdrawals with mandatory audit logging.
- **User Balance Adjustments**: Strict audit logs requiring mandatory admin explanation reasons.
- **CSV Data Export**: Instant download of financial audit trails.

---

## 🚀 Quick Start Guide

### Prerequisites
- **Node.js**: v18.0.0 or higher
- **npm**: v9.0.0 or higher
- **PostgreSQL**: v14+ (Local instance or Google Cloud SQL)

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Populate the database connection variables:
```env
PORT=3000
SQL_HOST=127.0.0.1
SQL_USER=postgres
SQL_PASSWORD=your_secure_password
SQL_DB_NAME=bigwin999_db
ADMIN_PIN=your_custom_admin_pin
APP_URL=http://localhost:3000
```
*(Note: In Google Cloud SQL or AI Studio environments, Cloud SQL socket paths and credentials are automatically injected via `process.env.SQL_HOST`, `process.env.SQL_USER`, and `process.env.SQL_DB_NAME`)*

### Step 3: Run Database Migrations / Seed
```bash
# Seed initial tables, games, payment accounts, and promotions
npx tsx -e "import('./src/db/seed.ts').then(m => m.seedDatabase())"
```

### Step 4: Run in Development Mode
```bash
npm run dev
```
The application will launch at `http://localhost:3000` with the Express API middleware running alongside the Vite frontend.

### Step 5: Run Automated Tests
```bash
npm test
```
Executes the comprehensive invariant test suite covering password hashing, user registration, anti-duplicate transaction checks, balance deduction, and audit log generation.

### Step 6: Build and Run for Production
```bash
# Compile client assets into /dist
npm run build

# Start the Node.js production server
npm start
```

---

## 📱 Android APK & Mobile App Distribution Guide

A raw `.zip` file of web source code cannot be directly installed as an `.apk` on an Android device. To deliver BIGWIN999 to Android users, choose one of the following two recommended pathways:

### Option A: Progressive Web App (PWA) — Instant & No App Store Needed (Recommended)
1. BIGWIN999 is fully responsive and supports PWA installation.
2. When users open `https://your-domain.com` in Google Chrome on Android, they can tap **"Add to Home Screen"** or **"Install App"**.
3. The app will install directly with a native app icon, standalone display (no browser address bar), and fast offline asset caching.

### Option B: Build a Native Android APK with Capacitor (Ready for Google Play)
To build a standalone `.apk` or `.aab` file:
```bash
# 1. Install Capacitor dependencies
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Initialize Capacitor project
npx cap init "BIGWIN999" "com.bigwin999.app" --web-dir dist

# 3. Build production web bundle
npm run build

# 4. Add the Android platform
npx cap add android

# 5. Sync web assets into Android project
npx cap sync android

# 6. Open in Android Studio to build APK
npx cap open android
```
In Android Studio:
- Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
- Locate the output `app-debug.apk` or sign a release `app-release.apk` for the Google Play Console.

---

## 🛡️ Security & Integrity Highlights
- **No Hardcoded Secrets**: All administrative keys and database credentials are strictly managed server-side via environment variables.
- **Sensitive Data Scrubbing**: User `passwordHash` and `securityAnswer` fields are never transmitted to the client.
- **Financial Idempotency**: Strict unique transaction constraints prevent double-crediting of bKash/Nagad/Rocket reference numbers.
- **Audit Logging**: Every administrative action, balance adjustment, and payment state change is permanently logged with IP address and timestamp.
